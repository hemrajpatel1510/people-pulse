/**
 * PeoplePulse Presentation Data Store
 * Contains word-for-word pitch script, stage bounds, ODAEA card schemas,
 * dashboard metrics, audit logs, and technical defense references.
 */

(function(root) {
  'use strict';

  const PRESENTATION_DATA = {
    meta: {
      title: "PeoplePulse — 5-Minute Pitch & Live Demo",
      event: "Tech Zephyr 4.0 | IIT Bhubaneswar — Agentic AI Hackathon",
      duration: 300.0,
      wordCount: 680,
      speakingPace: 136
    },

    // 6 Official Hackathon Stages with strict boundaries
    stages: [
      {
        id: 1,
        key: "goal",
        name: "Goal Context",
        start: 0.0,
        end: 45.0,
        color: "#3B82F6",
        badgeClass: "s-goal",
        description: "Employee burnout crisis & autonomous goal formulation",
        icon: "🎯"
      },
      {
        id: 2,
        key: "decision",
        name: "Decision Framework",
        start: 45.0,
        end: 90.0,
        color: "#8B5CF6",
        badgeClass: "s-dec",
        description: "ReAct reasoning loop via Gemini 2.0 Flash function calling",
        icon: "💡"
      },
      {
        id: 3,
        key: "action",
        name: "Action Execution",
        start: 90.0,
        end: 134.0,
        color: "#64748B",
        badgeClass: "s-act",
        description: "Live Postgres query with server-injected tenant ID",
        icon: "⚙️"
      },
      {
        id: 4,
        key: "evaluation",
        name: "Dynamic Evaluation",
        start: 134.0,
        end: 160.0,
        color: "#F59E0B",
        badgeClass: "s-eval",
        description: "Mathematical evaluation isolating 42% Support burnout",
        icon: "📋"
      },
      {
        id: 5,
        key: "adaptation",
        name: "Failure Adaptation",
        start: 160.0,
        end: 225.0,
        color: "#F97316",
        badgeClass: "s-adapt",
        description: "HTTP 503 failure interception & emergency queue reroute",
        icon: "🛡️"
      },
      {
        id: 6,
        key: "outcome",
        name: "Outcome & Governance",
        start: 225.0,
        end: 300.0,
        color: "#10B981",
        badgeClass: "s-out",
        description: "Resolution synthesis, HITL approval, audit trail & n ≥ 3 privacy",
        icon: "✅"
      }
    ],

    // Dashboard Mock Data
    dashboard: {
      organizationName: "Acme Enterprise Corp",
      plan: "Enterprise Tier",
      user: {
        name: "Alex Morgan",
        role: "HR Director",
        avatar: "AM"
      },
      kpis: [
        {
          id: "total_employees",
          label: "Total Employees",
          value: "248",
          sub: "Across 5 Teams",
          trend: "+12 this quarter",
          trendPositive: true
        },
        {
          id: "avg_engagement",
          label: "Company Wellbeing",
          value: "68%",
          sub: "Target: 75%",
          trend: "-2.4% vs last cycle",
          trendPositive: false,
          warning: true
        },
        {
          id: "weekly_participation",
          label: "Weekly Participation",
          value: "84.2%",
          sub: "209 / 248 Active Pulses",
          trend: "+4.1% completion",
          trendPositive: true
        },
        {
          id: "burnout_alert",
          label: "Burnout Risk Alert",
          value: "High Risk",
          sub: "Customer Support (42%)",
          trend: "Shift Overload Flag",
          trendPositive: false,
          critical: true
        }
      ],
      teams: [
        { name: "Customer Support", score: 42, status: "Critical", count: 38, stress: 4.6 },
        { name: "Sales & Account Execs", score: 64, status: "Moderate", count: 52, stress: 3.4 },
        { name: "Engineering", score: 82, status: "Healthy", count: 86, stress: 2.1 },
        { name: "Product Design", score: 79, status: "Healthy", count: 34, stress: 2.4 },
        { name: "Marketing & Growth", score: 73, status: "Moderate", count: 38, stress: 2.9 }
      ],
      dimensions: [
        { label: "Workload Manageability", score: 2.4, max: 5.0, status: "negative" },
        { label: "Manager Coaching & Support", score: 3.8, max: 5.0, status: "amber" },
        { label: "Cross-Team Collaboration", score: 4.1, max: 5.0, status: "positive" },
        { label: "Daily Energy & Motivation", score: 3.2, max: 5.0, status: "amber" },
        { label: "Shift Stress Balance", score: 2.2, max: 5.0, status: "negative" }
      ]
    },

    // ODAEA Event Card Stream definitions with exact timestamps
    eventStream: [
      {
        id: "ev_goal",
        time: 95.0,
        stage: 1,
        type: "goal",
        title: "Stage 1: Goal Established",
        badge: "Autonomous Goal",
        badgeClass: "badge-blue",
        summary: "Diagnose company-wide friction and deploy organizational interventions.",
        details: {
          session_id: "sess_react_9921b",
          objective: "Autonomous investigation of employee sentiment anomaly",
          target_scope: "all_departments",
          governance_mode: "semi_autonomous_with_hitl"
        }
      },
      {
        id: "ev_dec_1",
        time: 107.0,
        stage: 2,
        type: "decision",
        title: "Stage 2: Decision (Step 1)",
        badge: "Checking Company Numbers",
        badgeClass: "badge-purple",
        summary: "Rather than guessing, PulseAgent reasons over its tool registry and autonomously selects get_organization_metrics.",
        details: {
          step: 1,
          model: "Google Gemini 2.0 Flash Function Calling",
          selected_tool: "get_organization_metrics",
          reasoning: "Query baseline organization health metrics to identify departments experiencing anomalous friction or workload spikes."
        }
      },
      {
        id: "ev_act_1",
        time: 121.0,
        stage: 3,
        type: "action",
        title: "Stage 3: Action Executed — Checking Company Numbers",
        badge: "✓ Done",
        badgeClass: "badge-emerald",
        summary: "Checked 142 recent survey responses across 5 teams in PostgreSQL database.",
        callout: "organization_id server-injected from authenticated session token — LLM cannot fabricate tenant boundaries.",
        details: {
          tool: "get_organization_metrics",
          injected_parameters: {
            organization_id: "org_acme_enterprise_9921",
            time_window_days: 30,
            differential_privacy_threshold: 3
          },
          returned_payload: {
            status: "success",
            active_members: 248,
            active_teams: 5,
            recent_checkins_analyzed: 142,
            average_engagement_score: 68,
            dimension_averages: {
              workload: 2.4,
              manager_support: 3.8,
              collaboration: 4.1,
              motivation: 3.2,
              stress_level: 2.2
            },
            health_summary: "Moderate engagement — localized acute friction detected"
          }
        }
      },
      {
        id: "ev_obs_1",
        time: 134.0,
        stage: 4,
        type: "observation",
        title: "Observation: Environment Feedback",
        badge: "Live Telemetry",
        badgeClass: "badge-emerald",
        summary: "Live data returns: overall company engagement sits at 68%, but Customer Support shows a severe drop to 42% due to shift overload.",
        signals: [
          "Organization Average Engagement: 68/100",
          "Customer Support Engagement: 42/100 (Critical Alert)",
          "Stress Level Index: 4.6 / 5.0 (Shift Overload Detected)",
          "Workload Manageability: 1.9 / 5.0 (Unsustainable Sprint Overflow)"
        ],
        details: {
          total_responses: 142,
          critical_department: "Customer Support",
          anomaly_confidence: 0.94
        }
      },
      {
        id: "ev_eval_1",
        time: 148.0,
        stage: 4,
        type: "evaluation",
        title: "Stage 4: Evaluation (Step 1)",
        badge: "Data Evaluation",
        badgeClass: "badge-amber",
        summary: "The agent parses the numerical observation. It calculates that Customer Support requires an immediate targeted pulse survey and a manager 1:1 action brief.",
        details: {
          step: 1,
          severity: "HIGH",
          recommended_actions: [
            "Dispatch adaptive 60-second pulse focusing on shift scheduling fatigue",
            "Generate 3 manager coaching talking points for Customer Support lead",
            "Broadcast emergency escalation alert to department leadership"
          ]
        }
      },
      {
        id: "ev_dec_2",
        time: 165.0,
        stage: 5,
        type: "decision",
        title: "Stage 2: Decision (Step 2 — Alert Dispatch)",
        badge: "simulate_and_handle_failure",
        badgeClass: "badge-purple",
        summary: "Deciding to broadcast escalation alert to external team webhook (slack_webhook_v2).",
        details: {
          step: 2,
          model: "Google Gemini 2.0 Flash Function Calling",
          target_channel: "slack_webhook_v2",
          endpoint: "https://httpstat.us/503?sleep=1000"
        }
      },
      {
        id: "ev_fail_1",
        time: 175.0,
        stage: 5,
        type: "failure_adaptation",
        title: "Stage 5: Adaptation (Failure Interception & Self-Correction)",
        badge: "SELF-CORRECTED",
        badgeClass: "badge-orange-glow",
        isAdaptationHero: true,
        summary: "Primary webhook connection timed out with HTTP 503. Autonomous failover triggered: switching alert delivery to Supabase internal emergency escalation queue.",
        trigger: "Trigger: HTTP 503 Service Unavailable from primary webhook endpoint (slack_webhook_v2, latency: 1218ms)",
        details: {
          scenario: "Controlled Resilience Test Harness (HTTP 503 Interception)",
          error_code: 503,
          duration_ms: 1218,
          adaptation_required: true,
          autonomous_failover: true,
          suggested_fallback: "send_emergency_notification",
          zero_message_loss: true
        }
      },
      {
        id: "ev_act_2",
        time: 205.0,
        stage: 5,
        type: "action",
        title: "Stage 3: Action Executed — Emergency Queue Reroute",
        badge: "✓ DELIVERED",
        badgeClass: "badge-emerald",
        summary: "Urgent alert safely logged and delivered to admin console via backup queue (channel: emergency_in_app_queue, priority: high).",
        details: {
          tool: "send_emergency_notification",
          delivery_channel: "emergency_in_app_queue",
          status: "DELIVERED",
          message_loss: "0%",
          human_intervention_required: 0,
          payload: {
            title: "Urgent: Customer Support Shift Fatigue Alert",
            priority: "CRITICAL",
            failover: true,
            original_channel: "slack_webhook_v2"
          }
        }
      },
      {
        id: "ev_out_1",
        time: 228.0,
        stage: 6,
        type: "outcome",
        title: "Stage 6: Outcome & Final Resolution",
        badge: "Gemini 2.0 Flash",
        badgeClass: "badge-emerald",
        summary: "Autonomous multi-step investigation completed for goal: 'Diagnose company-wide friction and deploy interventions'.",
        stats: [
          { label: "Company Engagement", value: "68 / 100" },
          { label: "Active Employees", value: "248 Members" },
          { label: "Interventions", value: "2 Deployed" },
          { label: "Failover Resilience", value: "100% (Zero Loss)" }
        ],
        discoveries: [
          "Customer Support engagement dropped to 42/100 due to shift scheduling fatigue",
          "Primary notification channel failed (HTTP 503) — autonomously recovered via internal queue",
          "Interventions scheduled without exposing anonymous individual responses (n ≥ 3)"
        ],
        actionsTaken: [
          "Scheduled adaptive survey question: 'How manageable has your shift scheduling been this week?'",
          "Generated 3 manager coaching talking points for Customer Support lead",
          "Emergency alert delivered to admin escalation queue"
        ]
      }
    ],

    // Human-in-the-Loop Dialog specification
    hitlModal: {
      time: 242.0,
      title: "Human-in-the-Loop Governance Required",
      actionName: "broadcast_department_alert",
      description: "PulseAgent requested permission to broadcast an urgent shift workload alert to all 38 members of the Customer Support department.",
      parameters: {
        department: "Customer Support",
        priority: "CRITICAL",
        reason: "42% engagement & 4.6/5 chronic shift fatigue"
      },
      actions: ["Approve Action", "Deny Action"]
    },

    // Audit Trail Table Data
    auditTrail: [
      {
        id: "act_1726078800101",
        timestamp: "2026-09-11 18:20:02",
        goal: "Diagnose friction",
        tool: "get_organization_metrics",
        status: "COMPLETED",
        sanitizedInput: "{\"org_id\": \"[INJECTED]\", \"session_token\": \"[MASKED]\", \"privacy_n\": 3}",
        outcome: "Queried 142 responses across 5 teams. 68% avg score."
      },
      {
        id: "act_1726078800102",
        timestamp: "2026-09-11 18:20:04",
        goal: "Customer Support deep dive",
        tool: "diagnose_team_health",
        status: "COMPLETED",
        sanitizedInput: "{\"team\": \"Customer Support\", \"api_key\": \"[REDACTED]\"}",
        outcome: "Burnout confirmed (42/100, 4.6 stress index)."
      },
      {
        id: "act_1726078800103",
        timestamp: "2026-09-11 18:20:07",
        goal: "Broadcast escalation",
        tool: "simulate_and_handle_failure",
        status: "ADAPTED",
        sanitizedInput: "{\"endpoint\": \"https://httpstat.us/503\", \"bearer\": \"[REDACTED]\"}",
        outcome: "Caught HTTP 503 timeout (1218ms). Autonomous failover triggered."
      },
      {
        id: "act_1726078800104",
        timestamp: "2026-09-11 18:20:09",
        goal: "Failover dispatch",
        tool: "send_emergency_notification",
        status: "COMPLETED",
        sanitizedInput: "{\"channel\": \"emergency_in_app_queue\", \"priority\": \"high\"}",
        outcome: "Delivered to admin emergency queue. Zero message loss."
      },
      {
        id: "act_1726078800105",
        timestamp: "2026-09-11 18:20:12",
        goal: "Intervention deployment",
        tool: "dispatch_adaptive_survey",
        status: "COMPLETED",
        sanitizedInput: "{\"target_team\": \"Customer Support\", \"question_id\": \"q_shift_sched_44\"}",
        outcome: "Scheduled 60-second micro-pulse question into next check-in cycle."
      }
    ],

    // 7 Schema-validated registered tools
    toolsRegistry: [
      {
        name: "get_organization_metrics",
        permission: "manager+",
        risk: "read",
        description: "Returns aggregated team health and engagement metrics for the active organization with n ≥ 3 differential privacy protection."
      },
      {
        name: "diagnose_team_health",
        permission: "manager+",
        risk: "read",
        description: "Performs granular dimension burnout diagnosis (workload, stress, energy) on an identified friction team."
      },
      {
        name: "dispatch_adaptive_survey",
        permission: "manager+",
        risk: "write",
        description: "Schedules a targeted 60-second micro-pulse survey question to the specific team."
      },
      {
        name: "trigger_manager_action_brief",
        permission: "manager+",
        risk: "read",
        description: "Generates private, actionable 1:1 coaching discussion points for department managers."
      },
      {
        name: "list_teams",
        permission: "employee+",
        risk: "read",
        description: "Lists active departments and teams under the authenticated tenant organization."
      },
      {
        name: "send_emergency_notification",
        permission: "manager+",
        risk: "write",
        description: "Autonomously routes urgent alerts to internal Supabase emergency dispatch queue."
      },
      {
        name: "simulate_and_handle_failure",
        permission: "manager+",
        risk: "read",
        description: "Controlled resilience harness testing external webhook failures (HTTP 503) and self-correction."
      }
    ],

    // Developer Terminal Unit Test Output
    testResults: {
      timestamp: "2026-09-11 18:24:11",
      command: "npm run test",
      suites: [
        "PASS src/lib/agent/__tests__/toolRegistry.test.js",
        "PASS src/lib/agent/__tests__/agentPolicy.test.js",
        "PASS src/lib/agent/__tests__/privacyThreshold.test.js",
        "PASS src/lib/agent/__tests__/reactLoop.test.js"
      ],
      summary: {
        testFiles: "4 passed (4)",
        tests: "23 passed (23)",
        time: "511 ms"
      }
    },

    // Technical Q&A Defense Sheet
    qaDefense: [
      {
        question: "How do you prove this is an Agent, not just a scripted if-else flow?",
        answer: "PulseAgent runs a true ReAct loop in agentEngine.js via Gemini 2.0 Flash Function Calling. The model inspects tool signatures, decides execution steps dynamically based on memory history, and dynamically forms parameters. We removed all hardcoded completion short-circuits—the model independently evaluates observations until its goal is satisfied."
      },
      {
        question: "How do you prevent cross-tenant data leaks between companies?",
        answer: "Three-layer enforcement: 1) Policy Layer (agentPolicy.js validates active session org against target org); 2) Context Stripping (client strips organization_id from LLM parameters and server-injects it); and 3) PostgreSQL Row Level Security (Migration 039 queries tenant membership for all reads/writes)."
      },
      {
        question: "What stops a manager from identifying who submitted negative ratings?",
        answer: "We enforce an n ≥ 3 differential privacy threshold in our PostgreSQL RPC (get_org_team_comparison). If a team has fewer than 3 responses in a cycle, sentiment and score aggregations are suppressed to null at the database engine level, making individual deanonymization mathematically impossible."
      },
      {
        question: "What happens if external APIs throttle you or internet drops during live judging?",
        answer: "We engineered a dual-key failover system and a deterministic local fallback planner (geminiClient.js). If API keys fail or network disconnects, the engine seamlessly switches to the local state-machine planner with zero crashes and identical ODAEA event streaming."
      },
      {
        question: "How does failure adaptation actually work under the hood?",
        answer: "In tools.js, simulate_and_handle_failure triggers a real HTTP request to a failing endpoint (503 status). The exception is caught, returning adaptation_required: true. The engine flags an ADAPTATION event, pushes failure telemetry into prompt context, and the planner autonomously selects the in-app emergency dispatch tool."
      }
    ],
    // 27 Embedded Subtitle Cues with Token Timing for Standalone file:/// Mode
    cues: [
        {
            "id": "s1_1",
            "stageId": 1,
            "stageName": "Goal Context",
            "stageClass": "s-goal",
            "start": 0.0,
            "end": 8.0,
            "spokenDuration": 7.25,
            "text": "Respected judges, 76% of employees experience burnout before leadership even realizes there is a problem.",
            "tokens": [
                {
                    "text": "Respected",
                    "start": 0.0,
                    "end": 0.72,
                    "highlight": false
                },
                {
                    "text": "judges,",
                    "start": 0.72,
                    "end": 1.27,
                    "highlight": false
                },
                {
                    "text": "76%",
                    "start": 1.27,
                    "end": 1.51,
                    "highlight": true
                },
                {
                    "text": "of",
                    "start": 1.51,
                    "end": 1.67,
                    "highlight": false
                },
                {
                    "text": "employees",
                    "start": 1.67,
                    "end": 2.39,
                    "highlight": false
                },
                {
                    "text": "experience",
                    "start": 2.39,
                    "end": 3.19,
                    "highlight": false
                },
                {
                    "text": "burnout",
                    "start": 3.19,
                    "end": 3.74,
                    "highlight": true
                },
                {
                    "text": "before",
                    "start": 3.74,
                    "end": 4.22,
                    "highlight": false
                },
                {
                    "text": "leadership",
                    "start": 4.22,
                    "end": 5.02,
                    "highlight": true
                },
                {
                    "text": "even",
                    "start": 5.02,
                    "end": 5.34,
                    "highlight": false
                },
                {
                    "text": "realizes",
                    "start": 5.34,
                    "end": 5.97,
                    "highlight": false
                },
                {
                    "text": "there",
                    "start": 5.97,
                    "end": 6.37,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 6.37,
                    "end": 6.53,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 6.53,
                    "end": 6.61,
                    "highlight": false
                },
                {
                    "text": "problem.",
                    "start": 6.61,
                    "end": 7.25,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s1_2",
            "stageId": 1,
            "stageName": "Goal Context",
            "stageClass": "s-goal",
            "start": 8.0,
            "end": 22.0,
            "spokenDuration": 8.74,
            "text": "Traditional enterprise survey tools\u2014like annual 50-question reviews\u2014fail because of survey fatigue and devastating time lag.",
            "tokens": [
                {
                    "text": "Traditional",
                    "start": 8.0,
                    "end": 8.87,
                    "highlight": false
                },
                {
                    "text": "enterprise",
                    "start": 8.87,
                    "end": 9.67,
                    "highlight": false
                },
                {
                    "text": "survey",
                    "start": 9.67,
                    "end": 10.14,
                    "highlight": false
                },
                {
                    "text": "tools\u2014like",
                    "start": 10.14,
                    "end": 10.94,
                    "highlight": false
                },
                {
                    "text": "annual",
                    "start": 10.94,
                    "end": 11.41,
                    "highlight": false
                },
                {
                    "text": "50-question",
                    "start": 11.41,
                    "end": 12.29,
                    "highlight": true
                },
                {
                    "text": "reviews\u2014fail",
                    "start": 12.29,
                    "end": 13.24,
                    "highlight": false
                },
                {
                    "text": "because",
                    "start": 13.24,
                    "end": 13.8,
                    "highlight": false
                },
                {
                    "text": "of",
                    "start": 13.8,
                    "end": 13.96,
                    "highlight": false
                },
                {
                    "text": "survey",
                    "start": 13.96,
                    "end": 14.43,
                    "highlight": false
                },
                {
                    "text": "fatigue",
                    "start": 14.43,
                    "end": 14.99,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 14.99,
                    "end": 15.23,
                    "highlight": false
                },
                {
                    "text": "devastating",
                    "start": 15.23,
                    "end": 16.1,
                    "highlight": false
                },
                {
                    "text": "time",
                    "start": 16.1,
                    "end": 16.42,
                    "highlight": false
                },
                {
                    "text": "lag.",
                    "start": 16.42,
                    "end": 16.74,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s1_3",
            "stageId": 1,
            "stageName": "Goal Context",
            "stageClass": "s-goal",
            "start": 22.0,
            "end": 30.0,
            "spokenDuration": 5.74,
            "text": "By the time HR compiles quarterly reports, top talent has already resigned.",
            "tokens": [
                {
                    "text": "By",
                    "start": 22.0,
                    "end": 22.18,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 22.18,
                    "end": 22.45,
                    "highlight": false
                },
                {
                    "text": "time",
                    "start": 22.45,
                    "end": 22.81,
                    "highlight": false
                },
                {
                    "text": "HR",
                    "start": 22.81,
                    "end": 22.99,
                    "highlight": true
                },
                {
                    "text": "compiles",
                    "start": 22.99,
                    "end": 23.7,
                    "highlight": false
                },
                {
                    "text": "quarterly",
                    "start": 23.7,
                    "end": 24.51,
                    "highlight": false
                },
                {
                    "text": "reports,",
                    "start": 24.51,
                    "end": 25.23,
                    "highlight": false
                },
                {
                    "text": "top",
                    "start": 25.23,
                    "end": 25.5,
                    "highlight": false
                },
                {
                    "text": "talent",
                    "start": 25.5,
                    "end": 26.03,
                    "highlight": false
                },
                {
                    "text": "has",
                    "start": 26.03,
                    "end": 26.3,
                    "highlight": false
                },
                {
                    "text": "already",
                    "start": 26.3,
                    "end": 26.93,
                    "highlight": false
                },
                {
                    "text": "resigned.",
                    "start": 26.93,
                    "end": 27.74,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s1_4",
            "stageId": 1,
            "stageName": "Goal Context",
            "stageClass": "s-goal",
            "start": 30.0,
            "end": 45.0,
            "spokenDuration": 14.64,
            "text": "Enter PeoplePulse\u2014the autonomous enterprise HR intelligence platform engineered for Tech Zephyr 4.0. We replace static surveys with 60-second daily micro-pulses, backed by PulseAgent: an autonomous AI agent that doesn\u2019t just graph sentiment, but continuously reasons, diagnoses bottlenecks, and executes organizational interventions.",
            "tokens": [
                {
                    "text": "Enter",
                    "start": 30.0,
                    "end": 30.25,
                    "highlight": false
                },
                {
                    "text": "PeoplePulse\u2014the",
                    "start": 30.25,
                    "end": 31.0,
                    "highlight": true
                },
                {
                    "text": "autonomous",
                    "start": 31.0,
                    "end": 31.5,
                    "highlight": false
                },
                {
                    "text": "enterprise",
                    "start": 31.5,
                    "end": 32.0,
                    "highlight": false
                },
                {
                    "text": "HR",
                    "start": 32.0,
                    "end": 32.1,
                    "highlight": false
                },
                {
                    "text": "intelligence",
                    "start": 32.1,
                    "end": 32.7,
                    "highlight": false
                },
                {
                    "text": "platform",
                    "start": 32.7,
                    "end": 33.1,
                    "highlight": false
                },
                {
                    "text": "engineered",
                    "start": 33.1,
                    "end": 33.6,
                    "highlight": false
                },
                {
                    "text": "for",
                    "start": 33.6,
                    "end": 33.75,
                    "highlight": false
                },
                {
                    "text": "Tech",
                    "start": 33.75,
                    "end": 33.95,
                    "highlight": false
                },
                {
                    "text": "Zephyr",
                    "start": 33.95,
                    "end": 34.25,
                    "highlight": false
                },
                {
                    "text": "4.0.",
                    "start": 34.25,
                    "end": 34.45,
                    "highlight": false
                },
                {
                    "text": "We",
                    "start": 34.45,
                    "end": 34.55,
                    "highlight": false
                },
                {
                    "text": "replace",
                    "start": 34.55,
                    "end": 34.9,
                    "highlight": false
                },
                {
                    "text": "static",
                    "start": 34.9,
                    "end": 35.2,
                    "highlight": false
                },
                {
                    "text": "surveys",
                    "start": 35.2,
                    "end": 35.55,
                    "highlight": false
                },
                {
                    "text": "with",
                    "start": 35.55,
                    "end": 35.75,
                    "highlight": false
                },
                {
                    "text": "60-second",
                    "start": 35.75,
                    "end": 36.2,
                    "highlight": true
                },
                {
                    "text": "daily",
                    "start": 36.2,
                    "end": 36.45,
                    "highlight": false
                },
                {
                    "text": "micro-pulses,",
                    "start": 36.45,
                    "end": 37.1,
                    "highlight": true
                },
                {
                    "text": "backed",
                    "start": 37.1,
                    "end": 37.39,
                    "highlight": false
                },
                {
                    "text": "by",
                    "start": 37.39,
                    "end": 37.49,
                    "highlight": false
                },
                {
                    "text": "PulseAgent:",
                    "start": 37.49,
                    "end": 38.04,
                    "highlight": true
                },
                {
                    "text": "an",
                    "start": 38.04,
                    "end": 38.14,
                    "highlight": false
                },
                {
                    "text": "autonomous",
                    "start": 38.14,
                    "end": 38.64,
                    "highlight": false
                },
                {
                    "text": "AI",
                    "start": 38.64,
                    "end": 38.74,
                    "highlight": false
                },
                {
                    "text": "agent",
                    "start": 38.74,
                    "end": 38.99,
                    "highlight": false
                },
                {
                    "text": "that",
                    "start": 38.99,
                    "end": 39.19,
                    "highlight": false
                },
                {
                    "text": "doesn\u2019t",
                    "start": 39.19,
                    "end": 39.54,
                    "highlight": false
                },
                {
                    "text": "just",
                    "start": 39.54,
                    "end": 39.74,
                    "highlight": false
                },
                {
                    "text": "graph",
                    "start": 39.74,
                    "end": 39.99,
                    "highlight": false
                },
                {
                    "text": "sentiment,",
                    "start": 39.99,
                    "end": 40.49,
                    "highlight": false
                },
                {
                    "text": "but",
                    "start": 40.49,
                    "end": 40.64,
                    "highlight": false
                },
                {
                    "text": "continuously",
                    "start": 40.64,
                    "end": 41.24,
                    "highlight": false
                },
                {
                    "text": "reasons,",
                    "start": 41.24,
                    "end": 41.64,
                    "highlight": false
                },
                {
                    "text": "diagnoses",
                    "start": 41.64,
                    "end": 42.09,
                    "highlight": false
                },
                {
                    "text": "bottlenecks,",
                    "start": 42.09,
                    "end": 42.69,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 42.69,
                    "end": 42.84,
                    "highlight": false
                },
                {
                    "text": "executes",
                    "start": 42.84,
                    "end": 43.24,
                    "highlight": false
                },
                {
                    "text": "organizational",
                    "start": 43.24,
                    "end": 43.94,
                    "highlight": false
                },
                {
                    "text": "interventions.",
                    "start": 43.94,
                    "end": 44.64,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s2_1",
            "stageId": 2,
            "stageName": "Decision Framework",
            "stageClass": "s-dec",
            "start": 45.0,
            "end": 54.0,
            "spokenDuration": 5.18,
            "text": "Now, why is this an Agentic AI problem rather than a simple chatbot?",
            "tokens": [
                {
                    "text": "Now,",
                    "start": 45.0,
                    "end": 45.37,
                    "highlight": false
                },
                {
                    "text": "why",
                    "start": 45.37,
                    "end": 45.65,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 45.65,
                    "end": 45.83,
                    "highlight": false
                },
                {
                    "text": "this",
                    "start": 45.83,
                    "end": 46.2,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 46.2,
                    "end": 46.39,
                    "highlight": false
                },
                {
                    "text": "Agentic",
                    "start": 46.39,
                    "end": 47.04,
                    "highlight": false
                },
                {
                    "text": "AI",
                    "start": 47.04,
                    "end": 47.22,
                    "highlight": false
                },
                {
                    "text": "problem",
                    "start": 47.22,
                    "end": 47.87,
                    "highlight": false
                },
                {
                    "text": "rather",
                    "start": 47.87,
                    "end": 48.43,
                    "highlight": false
                },
                {
                    "text": "than",
                    "start": 48.43,
                    "end": 48.8,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 48.8,
                    "end": 48.89,
                    "highlight": false
                },
                {
                    "text": "simple",
                    "start": 48.89,
                    "end": 49.44,
                    "highlight": false
                },
                {
                    "text": "chatbot?",
                    "start": 49.44,
                    "end": 50.18,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s2_2",
            "stageId": 2,
            "stageName": "Decision Framework",
            "stageClass": "s-dec",
            "start": 54.0,
            "end": 67.0,
            "spokenDuration": 10.39,
            "text": "A chatbot merely summarizes text. It has no organizational memory, no schema-validated tools, and cannot take closed-loop actions.",
            "tokens": [
                {
                    "text": "A",
                    "start": 54.0,
                    "end": 54.09,
                    "highlight": false
                },
                {
                    "text": "chatbot",
                    "start": 54.09,
                    "end": 54.74,
                    "highlight": false
                },
                {
                    "text": "merely",
                    "start": 54.74,
                    "end": 55.29,
                    "highlight": false
                },
                {
                    "text": "summarizes",
                    "start": 55.29,
                    "end": 56.21,
                    "highlight": true
                },
                {
                    "text": "text.",
                    "start": 56.21,
                    "end": 56.67,
                    "highlight": false
                },
                {
                    "text": "It",
                    "start": 56.67,
                    "end": 56.85,
                    "highlight": false
                },
                {
                    "text": "has",
                    "start": 56.85,
                    "end": 57.13,
                    "highlight": false
                },
                {
                    "text": "no",
                    "start": 57.13,
                    "end": 57.31,
                    "highlight": false
                },
                {
                    "text": "organizational",
                    "start": 57.31,
                    "end": 58.6,
                    "highlight": false
                },
                {
                    "text": "memory,",
                    "start": 58.6,
                    "end": 59.24,
                    "highlight": false
                },
                {
                    "text": "no",
                    "start": 59.24,
                    "end": 59.43,
                    "highlight": false
                },
                {
                    "text": "schema-validated",
                    "start": 59.43,
                    "end": 60.9,
                    "highlight": false
                },
                {
                    "text": "tools,",
                    "start": 60.9,
                    "end": 61.45,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 61.45,
                    "end": 61.73,
                    "highlight": false
                },
                {
                    "text": "cannot",
                    "start": 61.73,
                    "end": 62.28,
                    "highlight": false
                },
                {
                    "text": "take",
                    "start": 62.28,
                    "end": 62.64,
                    "highlight": false
                },
                {
                    "text": "closed-loop",
                    "start": 62.64,
                    "end": 63.66,
                    "highlight": false
                },
                {
                    "text": "actions.",
                    "start": 63.66,
                    "end": 64.39,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s2_3",
            "stageId": 2,
            "stageName": "Decision Framework",
            "stageClass": "s-dec",
            "start": 67.0,
            "end": 79.0,
            "spokenDuration": 10.25,
            "text": "PulseAgent operates on a genuine ReAct (Reason + Act) loop powered by Google Gemini 2.0 Flash Function Calling, backed by our Supabase PostgreSQL architecture.",
            "tokens": [
                {
                    "text": "PulseAgent",
                    "start": 67.0,
                    "end": 67.75,
                    "highlight": true
                },
                {
                    "text": "operates",
                    "start": 67.75,
                    "end": 68.36,
                    "highlight": false
                },
                {
                    "text": "on",
                    "start": 68.36,
                    "end": 68.51,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 68.51,
                    "end": 68.58,
                    "highlight": false
                },
                {
                    "text": "genuine",
                    "start": 68.58,
                    "end": 69.11,
                    "highlight": false
                },
                {
                    "text": "ReAct",
                    "start": 69.11,
                    "end": 69.49,
                    "highlight": true
                },
                {
                    "text": "(Reason",
                    "start": 69.49,
                    "end": 70.01,
                    "highlight": false
                },
                {
                    "text": "+",
                    "start": 70.01,
                    "end": 70.09,
                    "highlight": false
                },
                {
                    "text": "Act)",
                    "start": 70.09,
                    "end": 70.39,
                    "highlight": false
                },
                {
                    "text": "loop",
                    "start": 70.39,
                    "end": 70.69,
                    "highlight": false
                },
                {
                    "text": "powered",
                    "start": 70.69,
                    "end": 71.22,
                    "highlight": false
                },
                {
                    "text": "by",
                    "start": 71.22,
                    "end": 71.37,
                    "highlight": false
                },
                {
                    "text": "Google",
                    "start": 71.37,
                    "end": 71.82,
                    "highlight": false
                },
                {
                    "text": "Gemini",
                    "start": 71.82,
                    "end": 72.27,
                    "highlight": false
                },
                {
                    "text": "2.0",
                    "start": 72.27,
                    "end": 72.5,
                    "highlight": false
                },
                {
                    "text": "Flash",
                    "start": 72.5,
                    "end": 72.88,
                    "highlight": false
                },
                {
                    "text": "Function",
                    "start": 72.88,
                    "end": 73.48,
                    "highlight": false
                },
                {
                    "text": "Calling,",
                    "start": 73.48,
                    "end": 74.08,
                    "highlight": false
                },
                {
                    "text": "backed",
                    "start": 74.08,
                    "end": 74.54,
                    "highlight": false
                },
                {
                    "text": "by",
                    "start": 74.54,
                    "end": 74.69,
                    "highlight": false
                },
                {
                    "text": "our",
                    "start": 74.69,
                    "end": 74.91,
                    "highlight": false
                },
                {
                    "text": "Supabase",
                    "start": 74.91,
                    "end": 75.51,
                    "highlight": false
                },
                {
                    "text": "PostgreSQL",
                    "start": 75.51,
                    "end": 76.27,
                    "highlight": true
                },
                {
                    "text": "architecture.",
                    "start": 76.27,
                    "end": 77.25,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s2_4",
            "stageId": 2,
            "stageName": "Decision Framework",
            "stageClass": "s-dec",
            "start": 79.0,
            "end": 85.0,
            "spokenDuration": 5.86,
            "text": "As you can see on the top breadcrumb bar, our agent enforces the strict 6-stage rubric lifecycle: Goal, Decision, Action, Evaluation, Adaptation, and Outcome.",
            "tokens": [
                {
                    "text": "As",
                    "start": 79.0,
                    "end": 79.09,
                    "highlight": false
                },
                {
                    "text": "you",
                    "start": 79.09,
                    "end": 79.22,
                    "highlight": false
                },
                {
                    "text": "can",
                    "start": 79.22,
                    "end": 79.35,
                    "highlight": false
                },
                {
                    "text": "see",
                    "start": 79.35,
                    "end": 79.48,
                    "highlight": false
                },
                {
                    "text": "on",
                    "start": 79.48,
                    "end": 79.56,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 79.56,
                    "end": 79.69,
                    "highlight": false
                },
                {
                    "text": "top",
                    "start": 79.69,
                    "end": 79.82,
                    "highlight": false
                },
                {
                    "text": "breadcrumb",
                    "start": 79.82,
                    "end": 80.26,
                    "highlight": false
                },
                {
                    "text": "bar,",
                    "start": 80.26,
                    "end": 80.43,
                    "highlight": false
                },
                {
                    "text": "our",
                    "start": 80.43,
                    "end": 80.56,
                    "highlight": false
                },
                {
                    "text": "agent",
                    "start": 80.56,
                    "end": 80.78,
                    "highlight": false
                },
                {
                    "text": "enforces",
                    "start": 80.78,
                    "end": 81.13,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 81.13,
                    "end": 81.26,
                    "highlight": false
                },
                {
                    "text": "strict",
                    "start": 81.26,
                    "end": 81.52,
                    "highlight": false
                },
                {
                    "text": "6-stage",
                    "start": 81.52,
                    "end": 81.82,
                    "highlight": false
                },
                {
                    "text": "rubric",
                    "start": 81.82,
                    "end": 82.08,
                    "highlight": false
                },
                {
                    "text": "lifecycle:",
                    "start": 82.08,
                    "end": 82.51,
                    "highlight": false
                },
                {
                    "text": "Goal,",
                    "start": 82.51,
                    "end": 82.73,
                    "highlight": true
                },
                {
                    "text": "Decision,",
                    "start": 82.73,
                    "end": 83.12,
                    "highlight": true
                },
                {
                    "text": "Action,",
                    "start": 83.12,
                    "end": 83.42,
                    "highlight": true
                },
                {
                    "text": "Evaluation,",
                    "start": 83.42,
                    "end": 83.9,
                    "highlight": true
                },
                {
                    "text": "Adaptation,",
                    "start": 83.9,
                    "end": 84.38,
                    "highlight": true
                },
                {
                    "text": "and",
                    "start": 84.38,
                    "end": 84.51,
                    "highlight": false
                },
                {
                    "text": "Outcome.",
                    "start": 84.51,
                    "end": 84.86,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s2_5",
            "stageId": 2,
            "stageName": "Decision Framework",
            "stageClass": "s-dec",
            "start": 85.0,
            "end": 90.0,
            "spokenDuration": 3.94,
            "text": "Every tool call is governed through an active RBAC policy engine with strict multi-tenant isolation.",
            "tokens": [
                {
                    "text": "Every",
                    "start": 85.0,
                    "end": 85.23,
                    "highlight": false
                },
                {
                    "text": "tool",
                    "start": 85.23,
                    "end": 85.41,
                    "highlight": false
                },
                {
                    "text": "call",
                    "start": 85.41,
                    "end": 85.59,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 85.59,
                    "end": 85.69,
                    "highlight": false
                },
                {
                    "text": "governed",
                    "start": 85.69,
                    "end": 86.05,
                    "highlight": false
                },
                {
                    "text": "through",
                    "start": 86.05,
                    "end": 86.37,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 86.37,
                    "end": 86.46,
                    "highlight": false
                },
                {
                    "text": "active",
                    "start": 86.46,
                    "end": 86.74,
                    "highlight": false
                },
                {
                    "text": "RBAC",
                    "start": 86.74,
                    "end": 86.92,
                    "highlight": true
                },
                {
                    "text": "policy",
                    "start": 86.92,
                    "end": 87.2,
                    "highlight": false
                },
                {
                    "text": "engine",
                    "start": 87.2,
                    "end": 87.47,
                    "highlight": false
                },
                {
                    "text": "with",
                    "start": 87.47,
                    "end": 87.65,
                    "highlight": false
                },
                {
                    "text": "strict",
                    "start": 87.65,
                    "end": 87.93,
                    "highlight": false
                },
                {
                    "text": "multi-tenant",
                    "start": 87.93,
                    "end": 88.48,
                    "highlight": false
                },
                {
                    "text": "isolation.",
                    "start": 88.48,
                    "end": 88.94,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s3_1",
            "stageId": 3,
            "stageName": "Action Execution",
            "stageClass": "s-act",
            "start": 90.0,
            "end": 95.0,
            "spokenDuration": 3.24,
            "text": "Let\u2019s watch PulseAgent execute live.",
            "tokens": [
                {
                    "text": "Let\u2019s",
                    "start": 90.0,
                    "end": 90.51,
                    "highlight": false
                },
                {
                    "text": "watch",
                    "start": 90.51,
                    "end": 91.01,
                    "highlight": false
                },
                {
                    "text": "PulseAgent",
                    "start": 91.01,
                    "end": 92.02,
                    "highlight": true
                },
                {
                    "text": "execute",
                    "start": 92.02,
                    "end": 92.73,
                    "highlight": false
                },
                {
                    "text": "live.",
                    "start": 92.73,
                    "end": 93.24,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s3_2",
            "stageId": 3,
            "stageName": "Action Execution",
            "stageClass": "s-act",
            "start": 95.0,
            "end": 107.0,
            "spokenDuration": 9.05,
            "text": "Stage 1: Goal Established. The objective is formulated: diagnose company-wide friction and deploy interventions.",
            "tokens": [
                {
                    "text": "Stage",
                    "start": 95.0,
                    "end": 95.46,
                    "highlight": false
                },
                {
                    "text": "1:",
                    "start": 95.46,
                    "end": 95.64,
                    "highlight": false
                },
                {
                    "text": "Goal",
                    "start": 95.64,
                    "end": 96.01,
                    "highlight": false
                },
                {
                    "text": "Established.",
                    "start": 96.01,
                    "end": 97.1,
                    "highlight": false
                },
                {
                    "text": "The",
                    "start": 97.1,
                    "end": 97.38,
                    "highlight": false
                },
                {
                    "text": "objective",
                    "start": 97.38,
                    "end": 98.2,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 98.2,
                    "end": 98.38,
                    "highlight": false
                },
                {
                    "text": "formulated:",
                    "start": 98.38,
                    "end": 99.39,
                    "highlight": false
                },
                {
                    "text": "diagnose",
                    "start": 99.39,
                    "end": 100.12,
                    "highlight": false
                },
                {
                    "text": "company-wide",
                    "start": 100.12,
                    "end": 101.21,
                    "highlight": false
                },
                {
                    "text": "friction",
                    "start": 101.21,
                    "end": 101.95,
                    "highlight": true
                },
                {
                    "text": "and",
                    "start": 101.95,
                    "end": 102.22,
                    "highlight": false
                },
                {
                    "text": "deploy",
                    "start": 102.22,
                    "end": 102.77,
                    "highlight": false
                },
                {
                    "text": "interventions.",
                    "start": 102.77,
                    "end": 104.05,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s3_3",
            "stageId": 3,
            "stageName": "Action Execution",
            "stageClass": "s-act",
            "start": 107.0,
            "end": 121.0,
            "spokenDuration": 10.82,
            "text": "Stage 2: Decision. Rather than guessing, the agent reasons over its tool registry and autonomously selects get_organization_metrics.",
            "tokens": [
                {
                    "text": "Stage",
                    "start": 107.0,
                    "end": 107.47,
                    "highlight": false
                },
                {
                    "text": "2:",
                    "start": 107.47,
                    "end": 107.65,
                    "highlight": false
                },
                {
                    "text": "Decision.",
                    "start": 107.65,
                    "end": 108.49,
                    "highlight": false
                },
                {
                    "text": "Rather",
                    "start": 108.49,
                    "end": 109.05,
                    "highlight": false
                },
                {
                    "text": "than",
                    "start": 109.05,
                    "end": 109.43,
                    "highlight": false
                },
                {
                    "text": "guessing,",
                    "start": 109.43,
                    "end": 110.27,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 110.27,
                    "end": 110.55,
                    "highlight": false
                },
                {
                    "text": "agent",
                    "start": 110.55,
                    "end": 111.01,
                    "highlight": false
                },
                {
                    "text": "reasons",
                    "start": 111.01,
                    "end": 111.67,
                    "highlight": false
                },
                {
                    "text": "over",
                    "start": 111.67,
                    "end": 112.04,
                    "highlight": false
                },
                {
                    "text": "its",
                    "start": 112.04,
                    "end": 112.32,
                    "highlight": false
                },
                {
                    "text": "tool",
                    "start": 112.32,
                    "end": 112.69,
                    "highlight": false
                },
                {
                    "text": "registry",
                    "start": 112.69,
                    "end": 113.44,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 113.44,
                    "end": 113.72,
                    "highlight": false
                },
                {
                    "text": "autonomously",
                    "start": 113.72,
                    "end": 114.84,
                    "highlight": false
                },
                {
                    "text": "selects",
                    "start": 114.84,
                    "end": 115.49,
                    "highlight": false
                },
                {
                    "text": "get_organization_metrics.",
                    "start": 115.49,
                    "end": 117.82,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s3_4",
            "stageId": 3,
            "stageName": "Action Execution",
            "stageClass": "s-act",
            "start": 121.0,
            "end": 134.0,
            "spokenDuration": 12.31,
            "text": "Stage 3: Action. It queries our live Supabase database. Notice in the parameter payload that organization_id was automatically injected from the authenticated session\u2014the LLM is never allowed to fabricate tenant boundaries.",
            "tokens": [
                {
                    "text": "Stage",
                    "start": 121.0,
                    "end": 121.32,
                    "highlight": false
                },
                {
                    "text": "3:",
                    "start": 121.32,
                    "end": 121.45,
                    "highlight": false
                },
                {
                    "text": "Action.",
                    "start": 121.45,
                    "end": 121.89,
                    "highlight": false
                },
                {
                    "text": "It",
                    "start": 121.89,
                    "end": 122.02,
                    "highlight": false
                },
                {
                    "text": "queries",
                    "start": 122.02,
                    "end": 122.47,
                    "highlight": false
                },
                {
                    "text": "our",
                    "start": 122.47,
                    "end": 122.66,
                    "highlight": false
                },
                {
                    "text": "live",
                    "start": 122.66,
                    "end": 122.91,
                    "highlight": false
                },
                {
                    "text": "Supabase",
                    "start": 122.91,
                    "end": 123.42,
                    "highlight": true
                },
                {
                    "text": "database.",
                    "start": 123.42,
                    "end": 124.0,
                    "highlight": false
                },
                {
                    "text": "Notice",
                    "start": 124.0,
                    "end": 124.38,
                    "highlight": false
                },
                {
                    "text": "in",
                    "start": 124.38,
                    "end": 124.51,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 124.51,
                    "end": 124.7,
                    "highlight": false
                },
                {
                    "text": "parameter",
                    "start": 124.7,
                    "end": 125.27,
                    "highlight": false
                },
                {
                    "text": "payload",
                    "start": 125.27,
                    "end": 125.72,
                    "highlight": false
                },
                {
                    "text": "that",
                    "start": 125.72,
                    "end": 125.98,
                    "highlight": false
                },
                {
                    "text": "organization_id",
                    "start": 125.98,
                    "end": 126.93,
                    "highlight": true
                },
                {
                    "text": "was",
                    "start": 126.93,
                    "end": 127.12,
                    "highlight": false
                },
                {
                    "text": "automatically",
                    "start": 127.12,
                    "end": 127.95,
                    "highlight": false
                },
                {
                    "text": "injected",
                    "start": 127.95,
                    "end": 128.46,
                    "highlight": false
                },
                {
                    "text": "from",
                    "start": 128.46,
                    "end": 128.72,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 128.72,
                    "end": 128.91,
                    "highlight": false
                },
                {
                    "text": "authenticated",
                    "start": 128.91,
                    "end": 129.74,
                    "highlight": false
                },
                {
                    "text": "session\u2014the",
                    "start": 129.74,
                    "end": 130.44,
                    "highlight": false
                },
                {
                    "text": "LLM",
                    "start": 130.44,
                    "end": 130.63,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 130.63,
                    "end": 130.76,
                    "highlight": false
                },
                {
                    "text": "never",
                    "start": 130.76,
                    "end": 131.08,
                    "highlight": false
                },
                {
                    "text": "allowed",
                    "start": 131.08,
                    "end": 131.53,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 131.53,
                    "end": 131.65,
                    "highlight": false
                },
                {
                    "text": "fabricate",
                    "start": 131.65,
                    "end": 132.23,
                    "highlight": false
                },
                {
                    "text": "tenant",
                    "start": 132.23,
                    "end": 132.61,
                    "highlight": false
                },
                {
                    "text": "boundaries.",
                    "start": 132.61,
                    "end": 133.31,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s3_5",
            "stageId": 4,
            "stageName": "Dynamic Evaluation",
            "stageClass": "s-eval",
            "start": 134.0,
            "end": 148.0,
            "spokenDuration": 11.38,
            "text": "Observation: Live data returns: overall company engagement sits at 68%, but Customer Support shows a severe drop to 42% due to shift overload.",
            "tokens": [
                {
                    "text": "Observation:",
                    "start": 134.0,
                    "end": 135.14,
                    "highlight": true
                },
                {
                    "text": "Live",
                    "start": 135.14,
                    "end": 135.52,
                    "highlight": false
                },
                {
                    "text": "data",
                    "start": 135.52,
                    "end": 135.9,
                    "highlight": false
                },
                {
                    "text": "returns:",
                    "start": 135.9,
                    "end": 136.65,
                    "highlight": false
                },
                {
                    "text": "overall",
                    "start": 136.65,
                    "end": 137.32,
                    "highlight": false
                },
                {
                    "text": "company",
                    "start": 137.32,
                    "end": 137.98,
                    "highlight": false
                },
                {
                    "text": "engagement",
                    "start": 137.98,
                    "end": 138.93,
                    "highlight": false
                },
                {
                    "text": "sits",
                    "start": 138.93,
                    "end": 139.31,
                    "highlight": false
                },
                {
                    "text": "at",
                    "start": 139.31,
                    "end": 139.5,
                    "highlight": false
                },
                {
                    "text": "68%,",
                    "start": 139.5,
                    "end": 139.88,
                    "highlight": true
                },
                {
                    "text": "but",
                    "start": 139.88,
                    "end": 140.16,
                    "highlight": false
                },
                {
                    "text": "Customer",
                    "start": 140.16,
                    "end": 140.92,
                    "highlight": false
                },
                {
                    "text": "Support",
                    "start": 140.92,
                    "end": 141.58,
                    "highlight": false
                },
                {
                    "text": "shows",
                    "start": 141.58,
                    "end": 142.06,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 142.06,
                    "end": 142.15,
                    "highlight": false
                },
                {
                    "text": "severe",
                    "start": 142.15,
                    "end": 142.72,
                    "highlight": false
                },
                {
                    "text": "drop",
                    "start": 142.72,
                    "end": 143.1,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 143.1,
                    "end": 143.29,
                    "highlight": false
                },
                {
                    "text": "42%",
                    "start": 143.29,
                    "end": 143.57,
                    "highlight": true
                },
                {
                    "text": "due",
                    "start": 143.57,
                    "end": 143.86,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 143.86,
                    "end": 144.05,
                    "highlight": false
                },
                {
                    "text": "shift",
                    "start": 144.05,
                    "end": 144.52,
                    "highlight": false
                },
                {
                    "text": "overload.",
                    "start": 144.52,
                    "end": 145.38,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s3_6",
            "stageId": 4,
            "stageName": "Dynamic Evaluation",
            "stageClass": "s-eval",
            "start": 148.0,
            "end": 160.0,
            "spokenDuration": 11.42,
            "text": "Stage 4: Evaluation. The agent parses the numerical observation. It calculates that Customer Support requires an immediate targeted pulse survey and a manager 1:1 action brief.",
            "tokens": [
                {
                    "text": "Stage",
                    "start": 148.0,
                    "end": 148.38,
                    "highlight": false
                },
                {
                    "text": "4:",
                    "start": 148.38,
                    "end": 148.53,
                    "highlight": false
                },
                {
                    "text": "Evaluation.",
                    "start": 148.53,
                    "end": 149.36,
                    "highlight": false
                },
                {
                    "text": "The",
                    "start": 149.36,
                    "end": 149.59,
                    "highlight": false
                },
                {
                    "text": "agent",
                    "start": 149.59,
                    "end": 149.97,
                    "highlight": false
                },
                {
                    "text": "parses",
                    "start": 149.97,
                    "end": 150.42,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 150.42,
                    "end": 150.65,
                    "highlight": false
                },
                {
                    "text": "numerical",
                    "start": 150.65,
                    "end": 151.33,
                    "highlight": false
                },
                {
                    "text": "observation.",
                    "start": 151.33,
                    "end": 152.24,
                    "highlight": false
                },
                {
                    "text": "It",
                    "start": 152.24,
                    "end": 152.39,
                    "highlight": false
                },
                {
                    "text": "calculates",
                    "start": 152.39,
                    "end": 153.14,
                    "highlight": false
                },
                {
                    "text": "that",
                    "start": 153.14,
                    "end": 153.45,
                    "highlight": false
                },
                {
                    "text": "Customer",
                    "start": 153.45,
                    "end": 154.05,
                    "highlight": false
                },
                {
                    "text": "Support",
                    "start": 154.05,
                    "end": 154.58,
                    "highlight": false
                },
                {
                    "text": "requires",
                    "start": 154.58,
                    "end": 155.19,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 155.19,
                    "end": 155.34,
                    "highlight": false
                },
                {
                    "text": "immediate",
                    "start": 155.34,
                    "end": 156.02,
                    "highlight": false
                },
                {
                    "text": "targeted",
                    "start": 156.02,
                    "end": 156.62,
                    "highlight": false
                },
                {
                    "text": "pulse",
                    "start": 156.62,
                    "end": 157.0,
                    "highlight": false
                },
                {
                    "text": "survey",
                    "start": 157.0,
                    "end": 157.46,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 157.46,
                    "end": 157.68,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 157.68,
                    "end": 157.76,
                    "highlight": false
                },
                {
                    "text": "manager",
                    "start": 157.76,
                    "end": 158.29,
                    "highlight": false
                },
                {
                    "text": "1:1",
                    "start": 158.29,
                    "end": 158.52,
                    "highlight": false
                },
                {
                    "text": "action",
                    "start": 158.52,
                    "end": 158.97,
                    "highlight": false
                },
                {
                    "text": "brief.",
                    "start": 158.97,
                    "end": 159.42,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s4_1",
            "stageId": 5,
            "stageName": "Failure Adaptation",
            "stageClass": "s-adapt",
            "start": 160.0,
            "end": 170.0,
            "spokenDuration": 6.86,
            "text": "Now, pay close attention to Stage 5: Adaptation\u2014our primary hackathon differentiator.",
            "tokens": [
                {
                    "text": "Now,",
                    "start": 160.0,
                    "end": 160.37,
                    "highlight": false
                },
                {
                    "text": "pay",
                    "start": 160.37,
                    "end": 160.64,
                    "highlight": false
                },
                {
                    "text": "close",
                    "start": 160.64,
                    "end": 161.1,
                    "highlight": false
                },
                {
                    "text": "attention",
                    "start": 161.1,
                    "end": 161.92,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 161.92,
                    "end": 162.1,
                    "highlight": false
                },
                {
                    "text": "Stage",
                    "start": 162.1,
                    "end": 162.56,
                    "highlight": false
                },
                {
                    "text": "5:",
                    "start": 162.56,
                    "end": 162.75,
                    "highlight": false
                },
                {
                    "text": "Adaptation\u2014our",
                    "start": 162.75,
                    "end": 164.03,
                    "highlight": false
                },
                {
                    "text": "primary",
                    "start": 164.03,
                    "end": 164.67,
                    "highlight": false
                },
                {
                    "text": "hackathon",
                    "start": 164.67,
                    "end": 165.49,
                    "highlight": false
                },
                {
                    "text": "differentiator.",
                    "start": 165.49,
                    "end": 166.86,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s4_2",
            "stageId": 5,
            "stageName": "Failure Adaptation",
            "stageClass": "s-adapt",
            "start": 170.0,
            "end": 188.0,
            "spokenDuration": 14.33,
            "text": "In real-world enterprise environments, external services fail. When PulseAgent attempts to broadcast an escalation alert to an external team webhook, it intercepts a real HTTP 503 service timeout.",
            "tokens": [
                {
                    "text": "In",
                    "start": 170.0,
                    "end": 170.17,
                    "highlight": false
                },
                {
                    "text": "real-world",
                    "start": 170.17,
                    "end": 171.02,
                    "highlight": false
                },
                {
                    "text": "enterprise",
                    "start": 171.02,
                    "end": 171.87,
                    "highlight": false
                },
                {
                    "text": "environments,",
                    "start": 171.87,
                    "end": 172.97,
                    "highlight": false
                },
                {
                    "text": "external",
                    "start": 172.97,
                    "end": 173.65,
                    "highlight": false
                },
                {
                    "text": "services",
                    "start": 173.65,
                    "end": 174.32,
                    "highlight": false
                },
                {
                    "text": "fail.",
                    "start": 174.32,
                    "end": 174.75,
                    "highlight": false
                },
                {
                    "text": "When",
                    "start": 174.75,
                    "end": 175.09,
                    "highlight": false
                },
                {
                    "text": "PulseAgent",
                    "start": 175.09,
                    "end": 175.93,
                    "highlight": false
                },
                {
                    "text": "attempts",
                    "start": 175.93,
                    "end": 176.61,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 176.61,
                    "end": 176.78,
                    "highlight": false
                },
                {
                    "text": "broadcast",
                    "start": 176.78,
                    "end": 177.55,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 177.55,
                    "end": 177.72,
                    "highlight": false
                },
                {
                    "text": "escalation",
                    "start": 177.72,
                    "end": 178.56,
                    "highlight": false
                },
                {
                    "text": "alert",
                    "start": 178.56,
                    "end": 178.99,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 178.99,
                    "end": 179.16,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 179.16,
                    "end": 179.33,
                    "highlight": false
                },
                {
                    "text": "external",
                    "start": 179.33,
                    "end": 180.0,
                    "highlight": false
                },
                {
                    "text": "team",
                    "start": 180.0,
                    "end": 180.34,
                    "highlight": false
                },
                {
                    "text": "webhook,",
                    "start": 180.34,
                    "end": 181.02,
                    "highlight": false
                },
                {
                    "text": "it",
                    "start": 181.02,
                    "end": 181.19,
                    "highlight": false
                },
                {
                    "text": "intercepts",
                    "start": 181.19,
                    "end": 182.04,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 182.04,
                    "end": 182.12,
                    "highlight": false
                },
                {
                    "text": "real",
                    "start": 182.12,
                    "end": 182.46,
                    "highlight": false
                },
                {
                    "text": "HTTP",
                    "start": 182.46,
                    "end": 182.8,
                    "highlight": false
                },
                {
                    "text": "503",
                    "start": 182.8,
                    "end": 183.06,
                    "highlight": false
                },
                {
                    "text": "service",
                    "start": 183.06,
                    "end": 183.65,
                    "highlight": false
                },
                {
                    "text": "timeout.",
                    "start": 183.65,
                    "end": 184.33,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s4_3",
            "stageId": 5,
            "stageName": "Failure Adaptation",
            "stageClass": "s-adapt",
            "start": 188.0,
            "end": 212.0,
            "spokenDuration": 17.33,
            "text": "A standard script would crash or silently drop the notification. PulseAgent catches the network exception, evaluates the failure context, triggers a strategy adaptation event, and autonomously reroutes the escalation to our internal Supabase emergency dispatch queue.",
            "tokens": [
                {
                    "text": "A",
                    "start": 188.0,
                    "end": 188.07,
                    "highlight": false
                },
                {
                    "text": "standard",
                    "start": 188.07,
                    "end": 188.67,
                    "highlight": false
                },
                {
                    "text": "script",
                    "start": 188.67,
                    "end": 189.12,
                    "highlight": false
                },
                {
                    "text": "would",
                    "start": 189.12,
                    "end": 189.49,
                    "highlight": false
                },
                {
                    "text": "crash",
                    "start": 189.49,
                    "end": 189.87,
                    "highlight": true
                },
                {
                    "text": "or",
                    "start": 189.87,
                    "end": 190.02,
                    "highlight": false
                },
                {
                    "text": "silently",
                    "start": 190.02,
                    "end": 190.61,
                    "highlight": false
                },
                {
                    "text": "drop",
                    "start": 190.61,
                    "end": 190.91,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 190.91,
                    "end": 191.14,
                    "highlight": false
                },
                {
                    "text": "notification.",
                    "start": 191.14,
                    "end": 192.11,
                    "highlight": false
                },
                {
                    "text": "PulseAgent",
                    "start": 192.11,
                    "end": 192.85,
                    "highlight": false
                },
                {
                    "text": "catches",
                    "start": 192.85,
                    "end": 193.38,
                    "highlight": true
                },
                {
                    "text": "the",
                    "start": 193.38,
                    "end": 193.6,
                    "highlight": false
                },
                {
                    "text": "network",
                    "start": 193.6,
                    "end": 194.12,
                    "highlight": false
                },
                {
                    "text": "exception,",
                    "start": 194.12,
                    "end": 194.87,
                    "highlight": false
                },
                {
                    "text": "evaluates",
                    "start": 194.87,
                    "end": 195.54,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 195.54,
                    "end": 195.77,
                    "highlight": false
                },
                {
                    "text": "failure",
                    "start": 195.77,
                    "end": 196.29,
                    "highlight": false
                },
                {
                    "text": "context,",
                    "start": 196.29,
                    "end": 196.89,
                    "highlight": false
                },
                {
                    "text": "triggers",
                    "start": 196.89,
                    "end": 197.49,
                    "highlight": false
                },
                {
                    "text": "a",
                    "start": 197.49,
                    "end": 197.56,
                    "highlight": false
                },
                {
                    "text": "strategy",
                    "start": 197.56,
                    "end": 198.16,
                    "highlight": false
                },
                {
                    "text": "adaptation",
                    "start": 198.16,
                    "end": 198.9,
                    "highlight": false
                },
                {
                    "text": "event,",
                    "start": 198.9,
                    "end": 199.35,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 199.35,
                    "end": 199.58,
                    "highlight": false
                },
                {
                    "text": "autonomously",
                    "start": 199.58,
                    "end": 200.47,
                    "highlight": false
                },
                {
                    "text": "reroutes",
                    "start": 200.47,
                    "end": 201.07,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 201.07,
                    "end": 201.29,
                    "highlight": false
                },
                {
                    "text": "escalation",
                    "start": 201.29,
                    "end": 202.04,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 202.04,
                    "end": 202.19,
                    "highlight": false
                },
                {
                    "text": "our",
                    "start": 202.19,
                    "end": 202.42,
                    "highlight": false
                },
                {
                    "text": "internal",
                    "start": 202.42,
                    "end": 203.01,
                    "highlight": false
                },
                {
                    "text": "Supabase",
                    "start": 203.01,
                    "end": 203.61,
                    "highlight": false
                },
                {
                    "text": "emergency",
                    "start": 203.61,
                    "end": 204.28,
                    "highlight": false
                },
                {
                    "text": "dispatch",
                    "start": 204.28,
                    "end": 204.88,
                    "highlight": false
                },
                {
                    "text": "queue.",
                    "start": 204.88,
                    "end": 205.33,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s4_4",
            "stageId": 5,
            "stageName": "Failure Adaptation",
            "stageClass": "s-adapt",
            "start": 212.0,
            "end": 225.0,
            "spokenDuration": 6.48,
            "text": "Zero message loss, zero human intervention, 100% self-healing resilience.",
            "tokens": [
                {
                    "text": "Zero",
                    "start": 212.0,
                    "end": 212.4,
                    "highlight": false
                },
                {
                    "text": "message",
                    "start": 212.4,
                    "end": 213.1,
                    "highlight": false
                },
                {
                    "text": "loss,",
                    "start": 213.1,
                    "end": 213.6,
                    "highlight": false
                },
                {
                    "text": "zero",
                    "start": 213.6,
                    "end": 213.99,
                    "highlight": false
                },
                {
                    "text": "human",
                    "start": 213.99,
                    "end": 214.49,
                    "highlight": false
                },
                {
                    "text": "intervention,",
                    "start": 214.49,
                    "end": 215.79,
                    "highlight": false
                },
                {
                    "text": "100%",
                    "start": 215.79,
                    "end": 216.19,
                    "highlight": false
                },
                {
                    "text": "self-healing",
                    "start": 216.19,
                    "end": 217.38,
                    "highlight": false
                },
                {
                    "text": "resilience.",
                    "start": 217.38,
                    "end": 218.48,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s5_1",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 225.0,
            "end": 238.0,
            "spokenDuration": 11.42,
            "text": "This brings us to Stage 6: Outcome. The agent synthesizes its discoveries, schedules the targeted questions into upcoming check-ins, and confirms execution.",
            "tokens": [
                {
                    "text": "This",
                    "start": 225.0,
                    "end": 225.34,
                    "highlight": false
                },
                {
                    "text": "brings",
                    "start": 225.34,
                    "end": 225.85,
                    "highlight": false
                },
                {
                    "text": "us",
                    "start": 225.85,
                    "end": 226.02,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 226.02,
                    "end": 226.18,
                    "highlight": false
                },
                {
                    "text": "Stage",
                    "start": 226.18,
                    "end": 226.61,
                    "highlight": false
                },
                {
                    "text": "6:",
                    "start": 226.61,
                    "end": 226.78,
                    "highlight": false
                },
                {
                    "text": "Outcome.",
                    "start": 226.78,
                    "end": 227.45,
                    "highlight": false
                },
                {
                    "text": "The",
                    "start": 227.45,
                    "end": 227.71,
                    "highlight": false
                },
                {
                    "text": "agent",
                    "start": 227.71,
                    "end": 228.13,
                    "highlight": false
                },
                {
                    "text": "synthesizes",
                    "start": 228.13,
                    "end": 229.06,
                    "highlight": true
                },
                {
                    "text": "its",
                    "start": 229.06,
                    "end": 229.32,
                    "highlight": false
                },
                {
                    "text": "discoveries,",
                    "start": 229.32,
                    "end": 230.33,
                    "highlight": false
                },
                {
                    "text": "schedules",
                    "start": 230.33,
                    "end": 231.09,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 231.09,
                    "end": 231.35,
                    "highlight": false
                },
                {
                    "text": "targeted",
                    "start": 231.35,
                    "end": 232.02,
                    "highlight": false
                },
                {
                    "text": "questions",
                    "start": 232.02,
                    "end": 232.79,
                    "highlight": false
                },
                {
                    "text": "into",
                    "start": 232.79,
                    "end": 233.12,
                    "highlight": false
                },
                {
                    "text": "upcoming",
                    "start": 233.12,
                    "end": 233.8,
                    "highlight": false
                },
                {
                    "text": "check-ins,",
                    "start": 233.8,
                    "end": 234.65,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 234.65,
                    "end": 234.9,
                    "highlight": false
                },
                {
                    "text": "confirms",
                    "start": 234.9,
                    "end": 235.58,
                    "highlight": false
                },
                {
                    "text": "execution.",
                    "start": 235.58,
                    "end": 236.42,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s5_2",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 238.0,
            "end": 251.0,
            "spokenDuration": 9.31,
            "text": "For high-risk actions\u2014like department-wide broadcast alerts\u2014our Human-in-the-Loop engine presents an interactive confirmation modal before execution.",
            "tokens": [
                {
                    "text": "For",
                    "start": 238.0,
                    "end": 238.21,
                    "highlight": false
                },
                {
                    "text": "high-risk",
                    "start": 238.21,
                    "end": 238.83,
                    "highlight": false
                },
                {
                    "text": "actions\u2014like",
                    "start": 238.83,
                    "end": 239.66,
                    "highlight": false
                },
                {
                    "text": "department-wide",
                    "start": 239.66,
                    "end": 240.69,
                    "highlight": false
                },
                {
                    "text": "broadcast",
                    "start": 240.69,
                    "end": 241.31,
                    "highlight": false
                },
                {
                    "text": "alerts\u2014our",
                    "start": 241.31,
                    "end": 242.0,
                    "highlight": false
                },
                {
                    "text": "Human-in-the-Loop",
                    "start": 242.0,
                    "end": 243.17,
                    "highlight": true
                },
                {
                    "text": "engine",
                    "start": 243.17,
                    "end": 243.59,
                    "highlight": false
                },
                {
                    "text": "presents",
                    "start": 243.59,
                    "end": 244.14,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 244.14,
                    "end": 244.28,
                    "highlight": false
                },
                {
                    "text": "interactive",
                    "start": 244.28,
                    "end": 245.04,
                    "highlight": false
                },
                {
                    "text": "confirmation",
                    "start": 245.04,
                    "end": 245.86,
                    "highlight": false
                },
                {
                    "text": "modal",
                    "start": 245.86,
                    "end": 246.21,
                    "highlight": false
                },
                {
                    "text": "before",
                    "start": 246.21,
                    "end": 246.62,
                    "highlight": false
                },
                {
                    "text": "execution.",
                    "start": 246.62,
                    "end": 247.31,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s5_3",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 251.0,
            "end": 265.0,
            "spokenDuration": 13.25,
            "text": "Furthermore, every decision, tool invocation, and adaptation is sanitized by our credential redactor and permanently written to the immutable agent_activity_logs audit table for enterprise compliance.",
            "tokens": [
                {
                    "text": "Furthermore,",
                    "start": 251.0,
                    "end": 251.9,
                    "highlight": false
                },
                {
                    "text": "every",
                    "start": 251.9,
                    "end": 252.28,
                    "highlight": false
                },
                {
                    "text": "decision,",
                    "start": 252.28,
                    "end": 252.96,
                    "highlight": false
                },
                {
                    "text": "tool",
                    "start": 252.96,
                    "end": 253.26,
                    "highlight": false
                },
                {
                    "text": "invocation,",
                    "start": 253.26,
                    "end": 254.09,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 254.09,
                    "end": 254.31,
                    "highlight": false
                },
                {
                    "text": "adaptation",
                    "start": 254.31,
                    "end": 255.06,
                    "highlight": false
                },
                {
                    "text": "is",
                    "start": 255.06,
                    "end": 255.22,
                    "highlight": false
                },
                {
                    "text": "sanitized",
                    "start": 255.22,
                    "end": 255.89,
                    "highlight": true
                },
                {
                    "text": "by",
                    "start": 255.89,
                    "end": 256.04,
                    "highlight": false
                },
                {
                    "text": "our",
                    "start": 256.04,
                    "end": 256.27,
                    "highlight": false
                },
                {
                    "text": "credential",
                    "start": 256.27,
                    "end": 257.02,
                    "highlight": false
                },
                {
                    "text": "redactor",
                    "start": 257.02,
                    "end": 257.62,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 257.62,
                    "end": 257.85,
                    "highlight": false
                },
                {
                    "text": "permanently",
                    "start": 257.85,
                    "end": 258.68,
                    "highlight": false
                },
                {
                    "text": "written",
                    "start": 258.68,
                    "end": 259.2,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 259.2,
                    "end": 259.36,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 259.36,
                    "end": 259.58,
                    "highlight": false
                },
                {
                    "text": "immutable",
                    "start": 259.58,
                    "end": 260.26,
                    "highlight": false
                },
                {
                    "text": "agent_activity_logs",
                    "start": 260.26,
                    "end": 261.69,
                    "highlight": true
                },
                {
                    "text": "audit",
                    "start": 261.69,
                    "end": 262.07,
                    "highlight": false
                },
                {
                    "text": "table",
                    "start": 262.07,
                    "end": 262.44,
                    "highlight": false
                },
                {
                    "text": "for",
                    "start": 262.44,
                    "end": 262.67,
                    "highlight": false
                },
                {
                    "text": "enterprise",
                    "start": 262.67,
                    "end": 263.42,
                    "highlight": false
                },
                {
                    "text": "compliance.",
                    "start": 263.42,
                    "end": 264.25,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s6_1",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 265.0,
            "end": 268.0,
            "spokenDuration": 1.78,
            "text": "Under the hood:",
            "tokens": [
                {
                    "text": "Under",
                    "start": 265.0,
                    "end": 265.68,
                    "highlight": false
                },
                {
                    "text": "the",
                    "start": 265.68,
                    "end": 266.09,
                    "highlight": false
                },
                {
                    "text": "hood:",
                    "start": 266.09,
                    "end": 266.78,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s6_2",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 268.0,
            "end": 277.0,
            "spokenDuration": 8.71,
            "text": "1. Zero Data Leaks: We enforce n \u2265 3 differential privacy directly in PostgreSQL, mathematically preventing individual de-anonymization.",
            "tokens": [
                {
                    "text": "1.",
                    "start": 268.0,
                    "end": 268.15,
                    "highlight": false
                },
                {
                    "text": "Zero",
                    "start": 268.15,
                    "end": 268.44,
                    "highlight": false
                },
                {
                    "text": "Data",
                    "start": 268.44,
                    "end": 268.73,
                    "highlight": false
                },
                {
                    "text": "Leaks:",
                    "start": 268.73,
                    "end": 269.17,
                    "highlight": false
                },
                {
                    "text": "We",
                    "start": 269.17,
                    "end": 269.32,
                    "highlight": false
                },
                {
                    "text": "enforce",
                    "start": 269.32,
                    "end": 269.83,
                    "highlight": false
                },
                {
                    "text": "n",
                    "start": 269.83,
                    "end": 269.9,
                    "highlight": false
                },
                {
                    "text": "\u2265",
                    "start": 269.9,
                    "end": 269.98,
                    "highlight": false
                },
                {
                    "text": "3",
                    "start": 269.98,
                    "end": 270.05,
                    "highlight": false
                },
                {
                    "text": "differential",
                    "start": 270.05,
                    "end": 270.93,
                    "highlight": false
                },
                {
                    "text": "privacy",
                    "start": 270.93,
                    "end": 271.44,
                    "highlight": false
                },
                {
                    "text": "directly",
                    "start": 271.44,
                    "end": 272.03,
                    "highlight": false
                },
                {
                    "text": "in",
                    "start": 272.03,
                    "end": 272.17,
                    "highlight": false
                },
                {
                    "text": "PostgreSQL,",
                    "start": 272.17,
                    "end": 272.98,
                    "highlight": true
                },
                {
                    "text": "mathematically",
                    "start": 272.98,
                    "end": 274.0,
                    "highlight": false
                },
                {
                    "text": "preventing",
                    "start": 274.0,
                    "end": 274.74,
                    "highlight": false
                },
                {
                    "text": "individual",
                    "start": 274.74,
                    "end": 275.47,
                    "highlight": false
                },
                {
                    "text": "de-anonymization.",
                    "start": 275.47,
                    "end": 276.71,
                    "highlight": true
                }
            ]
        },
        {
            "id": "s6_3",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 277.0,
            "end": 284.0,
            "spokenDuration": 6.22,
            "text": "2. Bulletproof Security: Row Level Security isolates every tenant, and DB triggers lock down billing columns.",
            "tokens": [
                {
                    "text": "2.",
                    "start": 277.0,
                    "end": 277.13,
                    "highlight": false
                },
                {
                    "text": "Bulletproof",
                    "start": 277.13,
                    "end": 277.86,
                    "highlight": false
                },
                {
                    "text": "Security:",
                    "start": 277.86,
                    "end": 278.45,
                    "highlight": false
                },
                {
                    "text": "Row",
                    "start": 278.45,
                    "end": 278.65,
                    "highlight": false
                },
                {
                    "text": "Level",
                    "start": 278.65,
                    "end": 278.98,
                    "highlight": false
                },
                {
                    "text": "Security",
                    "start": 278.98,
                    "end": 279.51,
                    "highlight": false
                },
                {
                    "text": "isolates",
                    "start": 279.51,
                    "end": 280.04,
                    "highlight": false
                },
                {
                    "text": "every",
                    "start": 280.04,
                    "end": 280.37,
                    "highlight": false
                },
                {
                    "text": "tenant,",
                    "start": 280.37,
                    "end": 280.84,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 280.84,
                    "end": 281.03,
                    "highlight": false
                },
                {
                    "text": "DB",
                    "start": 281.03,
                    "end": 281.17,
                    "highlight": false
                },
                {
                    "text": "triggers",
                    "start": 281.17,
                    "end": 281.7,
                    "highlight": false
                },
                {
                    "text": "lock",
                    "start": 281.7,
                    "end": 281.96,
                    "highlight": false
                },
                {
                    "text": "down",
                    "start": 281.96,
                    "end": 282.22,
                    "highlight": false
                },
                {
                    "text": "billing",
                    "start": 282.22,
                    "end": 282.69,
                    "highlight": false
                },
                {
                    "text": "columns.",
                    "start": 282.69,
                    "end": 283.22,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s6_4",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 284.0,
            "end": 291.0,
            "spokenDuration": 6.67,
            "text": "3. Production Rigor: 23 passing unit tests and an offline fallback planner guarantee zero downtime during presentations.",
            "tokens": [
                {
                    "text": "3.",
                    "start": 284.0,
                    "end": 284.13,
                    "highlight": false
                },
                {
                    "text": "Production",
                    "start": 284.13,
                    "end": 284.77,
                    "highlight": false
                },
                {
                    "text": "Rigor:",
                    "start": 284.77,
                    "end": 285.15,
                    "highlight": false
                },
                {
                    "text": "23",
                    "start": 285.15,
                    "end": 285.28,
                    "highlight": false
                },
                {
                    "text": "passing",
                    "start": 285.28,
                    "end": 285.73,
                    "highlight": false
                },
                {
                    "text": "unit",
                    "start": 285.73,
                    "end": 285.99,
                    "highlight": false
                },
                {
                    "text": "tests",
                    "start": 285.99,
                    "end": 286.31,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 286.31,
                    "end": 286.5,
                    "highlight": false
                },
                {
                    "text": "an",
                    "start": 286.5,
                    "end": 286.63,
                    "highlight": false
                },
                {
                    "text": "offline",
                    "start": 286.63,
                    "end": 287.08,
                    "highlight": false
                },
                {
                    "text": "fallback",
                    "start": 287.08,
                    "end": 287.59,
                    "highlight": false
                },
                {
                    "text": "planner",
                    "start": 287.59,
                    "end": 288.04,
                    "highlight": false
                },
                {
                    "text": "guarantee",
                    "start": 288.04,
                    "end": 288.62,
                    "highlight": false
                },
                {
                    "text": "zero",
                    "start": 288.62,
                    "end": 288.88,
                    "highlight": false
                },
                {
                    "text": "downtime",
                    "start": 288.88,
                    "end": 289.39,
                    "highlight": false
                },
                {
                    "text": "during",
                    "start": 289.39,
                    "end": 289.77,
                    "highlight": false
                },
                {
                    "text": "presentations.",
                    "start": 289.77,
                    "end": 290.67,
                    "highlight": false
                }
            ]
        },
        {
            "id": "s6_5",
            "stageId": 6,
            "stageName": "Outcome & Governance",
            "stageClass": "s-out",
            "start": 291.0,
            "end": 300.0,
            "spokenDuration": 7.03,
            "text": "PeoplePulse doesn\u2019t just watch company burnout happen\u2014it empowers autonomous intelligence to fix it in real-time. Thank you, and we look forward to your questions!",
            "tokens": [
                {
                    "text": "PeoplePulse",
                    "start": 291.0,
                    "end": 291.55,
                    "highlight": true
                },
                {
                    "text": "doesn\u2019t",
                    "start": 291.55,
                    "end": 291.9,
                    "highlight": false
                },
                {
                    "text": "just",
                    "start": 291.9,
                    "end": 292.11,
                    "highlight": false
                },
                {
                    "text": "watch",
                    "start": 292.11,
                    "end": 292.36,
                    "highlight": false
                },
                {
                    "text": "company",
                    "start": 292.36,
                    "end": 292.71,
                    "highlight": false
                },
                {
                    "text": "burnout",
                    "start": 292.71,
                    "end": 293.06,
                    "highlight": true
                },
                {
                    "text": "happen\u2014it",
                    "start": 293.06,
                    "end": 293.51,
                    "highlight": false
                },
                {
                    "text": "empowers",
                    "start": 293.51,
                    "end": 293.91,
                    "highlight": false
                },
                {
                    "text": "autonomous",
                    "start": 293.91,
                    "end": 294.42,
                    "highlight": false
                },
                {
                    "text": "intelligence",
                    "start": 294.42,
                    "end": 295.02,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 295.02,
                    "end": 295.12,
                    "highlight": false
                },
                {
                    "text": "fix",
                    "start": 295.12,
                    "end": 295.27,
                    "highlight": false
                },
                {
                    "text": "it",
                    "start": 295.27,
                    "end": 295.37,
                    "highlight": false
                },
                {
                    "text": "in",
                    "start": 295.37,
                    "end": 295.47,
                    "highlight": false
                },
                {
                    "text": "real-time.",
                    "start": 295.47,
                    "end": 295.97,
                    "highlight": false
                },
                {
                    "text": "Thank",
                    "start": 295.97,
                    "end": 296.22,
                    "highlight": false
                },
                {
                    "text": "you,",
                    "start": 296.22,
                    "end": 296.42,
                    "highlight": false
                },
                {
                    "text": "and",
                    "start": 296.42,
                    "end": 296.58,
                    "highlight": false
                },
                {
                    "text": "we",
                    "start": 296.58,
                    "end": 296.68,
                    "highlight": false
                },
                {
                    "text": "look",
                    "start": 296.68,
                    "end": 296.88,
                    "highlight": false
                },
                {
                    "text": "forward",
                    "start": 296.88,
                    "end": 297.23,
                    "highlight": false
                },
                {
                    "text": "to",
                    "start": 297.23,
                    "end": 297.33,
                    "highlight": false
                },
                {
                    "text": "your",
                    "start": 297.33,
                    "end": 297.53,
                    "highlight": false
                },
                {
                    "text": "questions!",
                    "start": 297.53,
                    "end": 298.03,
                    "highlight": false
                }
            ]
        }
    ]
  };

  root.PEOPLEPULSE_PRESENTATION_DATA = PRESENTATION_DATA;
})(typeof window !== 'undefined' ? window : globalThis);
