/**
 * PeoplePulse Interactive Presentation Player — Main Bootstrap
 * Orchestrates TimelineEngine, AudioManager, SubtitleRenderer, SceneSimulator,
 * and InteractiveController.
 */

(function(root) {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {
    // 1. Instantiate Subsystems
    const audioManager = new root.AudioManager({
      primarySrc: "assets/audio/narration_full.mp3",
      fallbackSrc: "assets/audio/narration_sapi.wav",
      volume: 1.0,
      rate: 1.0
    });

    const timelineEngine = new root.TimelineEngine({
      duration: 300.0,
      audioManager: audioManager
    });

    const subtitleRenderer = new root.SubtitleRenderer({
      containerEl: document.getElementById('subtitle-overlay'),
      textEl: document.getElementById('subtitle-text'),
      stageTagEl: document.getElementById('subtitle-stage-tag'),
      transcriptDrawerEl: document.getElementById('transcript-drawer'),
      transcriptListEl: document.getElementById('transcript-list'),
      timelineEngine: timelineEngine,
      cues: root.PEOPLEPULSE_PRESENTATION_DATA?.cues
    });

    const sceneSimulator = new root.SceneSimulator({
      containerEl: document.getElementById('scene-canvas'),
      drawerEl: document.getElementById('pulseagent-drawer'),
      eventStreamEl: document.getElementById('agent-event-stream'),
      audioManager: audioManager
    });

    const interactiveController = new root.InteractiveController({
      timelineEngine: timelineEngine,
      sceneSimulator: sceneSimulator,
      audioManager: audioManager,
      subtitleRenderer: subtitleRenderer
    });

    // 2. Wire Events
    // Frame Ticks (~60fps)
    timelineEngine.onTick((tick) => {
      // Update Subtitles
      subtitleRenderer.update(tick.currentTime);

      // Update Scene DOM
      sceneSimulator.update(tick.currentTime, tick.stage);

      // Update Transport UI
      updateTransportUI(tick);
    });

    // Stage Transitions
    timelineEngine.onStageChange(({ currentStage, stageIndex }) => {
      updateActiveStageUI(currentStage, stageIndex);
    });

    // State Transitions (PLAYING, PAUSED, COMPLETED)
    timelineEngine.onStateChange(({ state, isPlaying }) => {
      updatePlayButtonUI(isPlaying);
      if (state === "PAUSED") {
        interactiveController.onPause();
      } else if (state === "PLAYING") {
        interactiveController.onResume();
      } else if (state === "COMPLETED") {
        interactiveController.onPause();
      }
    });

    // 3. Setup Transport Controls
    const playPauseBtn = document.getElementById('btn-play-pause');
    if (playPauseBtn) {
      playPauseBtn.addEventListener('click', () => {
        timelineEngine.togglePlay();
      });
    }

    const restartBtn = document.getElementById('btn-restart');
    if (restartBtn) {
      restartBtn.addEventListener('click', () => {
        timelineEngine.restart();
      });
    }

    const speedBtn = document.getElementById('btn-speed');
    if (speedBtn) {
      speedBtn.addEventListener('click', () => {
        const nextSpeed = timelineEngine.cycleSpeed();
        speedBtn.textContent = `${nextSpeed}x`;
      });
    }

    const muteBtn = document.getElementById('btn-mute');
    if (muteBtn) {
      muteBtn.addEventListener('click', () => {
        const isMuted = audioManager.toggleMute();
        updateMuteButtonUI(isMuted);
      });
    }

    const volumeSlider = document.getElementById('volume-slider');
    if (volumeSlider) {
      volumeSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        audioManager.setVolume(val);
        updateMuteButtonUI(audioManager.muted || val === 0);
      });
    }

    const ccBtn = document.getElementById('btn-captions');
    if (ccBtn) {
      ccBtn.addEventListener('click', () => {
        const isVisible = subtitleRenderer.toggleVisibility();
        ccBtn.classList.toggle('active-control', isVisible);
      });
    }

    const fullscreenBtn = document.getElementById('btn-fullscreen');
    if (fullscreenBtn) {
      fullscreenBtn.addEventListener('click', () => {
        toggleFullScreen();
      });
    }

    // Scrubber Dragging & Seeking
    const scrubberTrack = document.getElementById('scrubber-track');
    const scrubberFill = document.getElementById('scrubber-fill');
    const scrubberHandle = document.getElementById('scrubber-handle');
    const scrubberTooltip = document.getElementById('scrubber-tooltip');
    let isDraggingScrubber = false;

    if (scrubberTrack) {
      const getTargetTimeFromEvent = (e) => {
        const rect = scrubberTrack.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        return ratio * timelineEngine.duration;
      };

      scrubberTrack.addEventListener('mousedown', (e) => {
        isDraggingScrubber = true;
        const targetSec = getTargetTimeFromEvent(e);
        timelineEngine.seek(targetSec);
      });

      scrubberTrack.addEventListener('mousemove', (e) => {
        if (!scrubberTooltip) return;
        const rect = scrubberTrack.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const hoverSec = ratio * timelineEngine.duration;
        const stageInfo = timelineEngine.getStageForTime(hoverSec);

        scrubberTooltip.style.left = `${ratio * 100}%`;
        scrubberTooltip.textContent = `${formatTime(hoverSec)} • ${stageInfo.stage.name}`;
        scrubberTooltip.classList.add('tooltip-visible');
      });

      scrubberTrack.addEventListener('mouseleave', () => {
        if (scrubberTooltip) scrubberTooltip.classList.remove('tooltip-visible');
      });

      window.addEventListener('mousemove', (e) => {
        if (isDraggingScrubber) {
          const targetSec = getTargetTimeFromEvent(e);
          timelineEngine.seek(targetSec);
        }
      });

      window.addEventListener('mouseup', () => {
        isDraggingScrubber = false;
      });
    }

    // Stage Jump Buttons
    const stageMarkers = document.querySelectorAll('.stage-jump-btn');
    stageMarkers.forEach(btn => {
      btn.addEventListener('click', () => {
        const stageId = parseInt(btn.dataset.stageId, 10);
        timelineEngine.jumpToStage(stageId - 1);
      });
    });

    // 4. Hero Presentation Splash Screen
    const heroOverlay = document.getElementById('presentation-hero-splash');
    const startPitchBtn = document.getElementById('btn-start-pitch');
    if (startPitchBtn && heroOverlay) {
      startPitchBtn.addEventListener('click', () => {
        heroOverlay.classList.add('fade-out');
        setTimeout(() => {
          heroOverlay.style.display = 'none';
        }, 500);

        timelineEngine.seek(0);
        timelineEngine.play();
      });
    }

    // Replay button on Finale slide
    const replayBtn = document.getElementById('btn-replay-presentation');
    if (replayBtn) {
      replayBtn.addEventListener('click', () => {
        const finaleOverlay = document.getElementById('grand-finale-overlay');
        if (finaleOverlay) finaleOverlay.classList.remove('overlay-visible');
        timelineEngine.restart();
      });
    }

    // 5. Global Keyboard Shortcuts
    window.addEventListener('keydown', (e) => {
      // Don't capture when typing in an input or focused on a button
      if (['INPUT', 'TEXTAREA', 'BUTTON'].includes(e.target.tagName)) return;

      switch (e.code) {
        case 'Space':
          e.preventDefault();
          timelineEngine.togglePlay();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          timelineEngine.seek(timelineEngine.currentTime - (e.shiftKey ? 15 : 5));
          break;
        case 'ArrowRight':
          e.preventDefault();
          timelineEngine.seek(timelineEngine.currentTime + (e.shiftKey ? 15 : 5));
          break;
        case 'KeyM':
          e.preventDefault();
          muteBtn && muteBtn.click();
          break;
        case 'KeyC':
          e.preventDefault();
          ccBtn && ccBtn.click();
          break;
        case 'KeyS':
          e.preventDefault();
          speedBtn && speedBtn.click();
          break;
        case 'KeyR':
          e.preventDefault();
          timelineEngine.restart();
          break;
        case 'Digit1':
        case 'Digit2':
        case 'Digit3':
        case 'Digit4':
        case 'Digit5':
        case 'Digit6':
          e.preventDefault();
          const digit = parseInt(e.code.replace('Digit', ''), 10);
          timelineEngine.jumpToStage(digit - 1);
          break;
      }
    });

    // 6. UI Update Helper Functions
    function updateTransportUI(tick) {
      // Progress Bar
      if (scrubberFill) scrubberFill.style.width = `${tick.progressPercent}%`;
      if (scrubberHandle) scrubberHandle.style.left = `${tick.progressPercent}%`;

      // Time Display
      const currentTimeLabel = document.getElementById('time-current');
      const totalTimeLabel = document.getElementById('time-total');
      if (currentTimeLabel) currentTimeLabel.textContent = formatTime(tick.currentTime);
      if (totalTimeLabel) totalTimeLabel.textContent = formatTime(tick.duration);
    }

    function updatePlayButtonUI(isPlaying) {
      const playIcon = document.getElementById('icon-play');
      const pauseIcon = document.getElementById('icon-pause');
      if (playIcon && pauseIcon) {
        if (isPlaying) {
          playIcon.style.display = 'none';
          pauseIcon.style.display = 'inline-block';
        } else {
          playIcon.style.display = 'inline-block';
          pauseIcon.style.display = 'none';
        }
      }
    }

    function updateMuteButtonUI(isMuted) {
      const volIcon = document.getElementById('icon-volume-on');
      const muteIcon = document.getElementById('icon-volume-off');
      if (volIcon && muteIcon) {
        if (isMuted) {
          volIcon.style.display = 'none';
          muteIcon.style.display = 'inline-block';
        } else {
          volIcon.style.display = 'inline-block';
          muteIcon.style.display = 'none';
        }
      }
    }

    function updateActiveStageUI(currentStage, stageIndex) {
      // Stage jump buttons beneath scrubber
      const btns = document.querySelectorAll('.stage-jump-btn');
      btns.forEach((btn, idx) => {
        if (idx === stageIndex) {
          btn.classList.add('active-stage-btn');
        } else {
          btn.classList.remove('active-stage-btn');
        }
      });
    }

    function formatTime(sec) {
      const clamped = Math.max(0, Math.floor(sec || 0));
      const mins = Math.floor(clamped / 60);
      const secs = clamped % 60;
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    function toggleFullScreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
      }
    }

    // Expose root instances for automated verification scripts and console inspection
    root.PeoplePulsePlayer = {
      timeline: timelineEngine,
      audio: audioManager,
      subtitles: subtitleRenderer,
      simulator: sceneSimulator,
      interactive: interactiveController
    };
  });
})(typeof window !== 'undefined' ? window : globalThis);
