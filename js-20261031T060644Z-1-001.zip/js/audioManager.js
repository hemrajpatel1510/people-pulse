/**
 * PeoplePulse Audio & Narration Manager
 * Manages continuous studio-grade voiceover playback with multi-tier fallback
 * (Edge-TTS MP3 -> SAPI WAV -> Web Speech) and Web Audio procedural chimes.
 */

(function(root) {
  'use strict';

  class AudioManager {
    constructor(options = {}) {
      this.primarySrc = options.primarySrc || "assets/audio/narration_full.mp3";
      this.fallbackSrc = options.fallbackSrc || "assets/audio/narration_sapi.wav";
      this.volume = (typeof options.volume === 'number') ? options.volume : 1.0;
      this.muted = !!options.muted;
      this.rate = options.rate || 1.0;

      this.audio = null;
      this.audioContext = null;
      this.isAudioLoaded = false;
      this.hasFailed = false;
      this.useSynthesizerFallback = false;

      this._initAudioElement();
      this._initWebAudioContext();
    }

    _initAudioElement() {
      this.audio = new Audio();
      this.audio.preload = "auto";
      this.audio.src = this.primarySrc;
      this.audio.preservesPitch = true;
      this.audio.playbackRate = this.rate;
      this.audio.volume = this.volume;
      this.audio.muted = this.muted;

      this.audio.addEventListener('canplaythrough', () => {
        this.isAudioLoaded = true;
        this.hasFailed = false;
      });

      this.audio.addEventListener('error', (e) => {
        console.warn("Primary audio failed to load, attempting fallback source...", e);
        if (this.audio.src !== this.fallbackSrc && !this.audio.src.endsWith(this.fallbackSrc)) {
          this.audio.src = this.fallbackSrc;
          this.audio.load();
        } else {
          console.warn("Fallback audio failed. Switching to synthetic/silent clock mode.");
          this.hasFailed = true;
          this.isAudioLoaded = false;
          this.useSynthesizerFallback = true;
        }
      });
    }

    _initWebAudioContext() {
      const AudioCtx = root.AudioContext || root.webkitAudioContext;
      if (AudioCtx) {
        try {
          this.audioContext = new AudioCtx();
        } catch (e) {
          console.warn("Web AudioContext initialization deferred:", e);
        }
      }
    }

    _ensureAudioContextRunning() {
      if (this.audioContext && this.audioContext.state === 'suspended') {
        this.audioContext.resume().catch(() => {});
      }
    }

    play() {
      this._ensureAudioContextRunning();
      if (!this.audio || this.hasFailed) return Promise.resolve();

      // Respect preservesPitch
      this.audio.preservesPitch = true;
      this.audio.playbackRate = this.rate;

      return this.audio.play().catch(err => {
        console.warn("Audio autoplay policy or playback error:", err.message);
      });
    }

    pause() {
      if (this.audio && !this.audio.paused) {
        this.audio.pause();
      }
    }

    seek(seconds) {
      if (!this.audio || isNaN(seconds)) return;
      try {
        if (isFinite(this.audio.duration)) {
          this.audio.currentTime = Math.max(0, Math.min(seconds, this.audio.duration));
        } else {
          this.audio.currentTime = Math.max(0, seconds);
        }
      } catch (e) {
        // Can throw if audio not yet seekable
      }
    }

    setRate(rate) {
      this.rate = rate;
      if (this.audio) {
        this.audio.preservesPitch = true;
        this.audio.playbackRate = rate;
      }
    }

    setVolume(vol) {
      this.volume = Math.max(0.0, Math.min(1.0, vol));
      if (this.audio) {
        this.audio.volume = this.volume;
        if (this.volume > 0 && this.audio.muted) {
          this.audio.muted = false;
          this.muted = false;
        }
      }
    }

    toggleMute() {
      this.setMuted(!this.muted);
      return this.muted;
    }

    setMuted(isMuted) {
      this.muted = !!isMuted;
      if (this.audio) {
        this.audio.muted = this.muted;
      }
    }

    getCurrentTime() {
      if (this.audio && !this.hasFailed && !this.audio.seeking && !isNaN(this.audio.currentTime)) {
        return this.audio.currentTime;
      }
      return null;
    }

    getDuration() {
      if (this.audio && !isNaN(this.audio.duration) && isFinite(this.audio.duration)) {
        return this.audio.duration;
      }
      return 300.0;
    }

    isPlaying() {
      return !!(this.audio && !this.audio.paused && !this.audio.ended && !this.audio.seeking && this.audio.readyState > 2);
    }

    isAvailable() {
      return !this.hasFailed && !!this.audio;
    }

    // Procedural Web Audio chimes for enhanced interactivity
    playAlertChime() {
      this._ensureAudioContextRunning();
      if (!this.audioContext) return;

      try {
        const ctx = this.audioContext;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(311.13, now + 0.35); // D#4 warning drop

        gain.gain.setValueAtTime(this.muted ? 0 : 0.22 * this.volume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.55);
      } catch (e) {
        // Ignore audio node errors
      }
    }

    playSuccessChime() {
      this._ensureAudioContextRunning();
      if (!this.audioContext) return;

      try {
        const ctx = this.audioContext;
        const now = ctx.currentTime;
        const freqs = [523.25, 659.25, 783.99]; // C5 Major Triad

        freqs.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const noteStart = now + idx * 0.08;

          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, noteStart);

          gain.gain.setValueAtTime(this.muted ? 0 : 0.18 * this.volume, noteStart);
          gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.7);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(noteStart);
          osc.stop(noteStart + 0.7);
        });
      } catch (e) {
        // Ignore
      }
    }

    playClickChime() {
      this._ensureAudioContextRunning();
      if (!this.audioContext) return;

      try {
        const ctx = this.audioContext;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(880, now);

        gain.gain.setValueAtTime(this.muted ? 0 : 0.05 * this.volume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.04);
      } catch (e) {
        // Ignore
      }
    }
  }

  root.AudioManager = AudioManager;
})(typeof window !== 'undefined' ? window : globalThis);
