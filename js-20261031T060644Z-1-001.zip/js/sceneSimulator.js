/**
 * PeoplePulse Dynamic Scene Visuals & Live UI Simulator
 * High-fidelity DOM simulation of PeoplePulse Admin Dashboard, sliding PulseAgent drawer,
 * streaming ODAEA event cards, radiant orange HTTP 503 adaptation card, HITL modal,
 * and test verification terminal.
 */

(function(root) {
  'use strict';

  class SceneSimulator {
    constructor(options = {}) {
      this.containerEl = options.containerEl || document.getElementById('scene-canvas');
      this.drawerEl = options.drawerEl || document.getElementById('pulseagent-drawer');
      this.eventStreamEl = options.eventStreamEl || document.getElementById('agent-event-stream');
      this.audioManager = options.audioManager || null;
      this.data = root.PEOPLEPULSE_PRESENTATION_DATA || {};

      this.currentStageId = 1;
      this.renderedEventIds = new Set();
      this.playedChimes = new Set();
      this.isDrawerOpen = false;
      this.activeTab = 'react'; // 'react', 'audit', 'tools'
      this.isPausedByUser = false;

      this.init();
    }

    setAudioManager(audioManager) {
      this.audioManager = audioManager;
    }

    init() {
      this.renderDashboard();
      this.renderAuditTrailTable();
      this.renderToolsList();
    }

    renderDashboard() {
      const db = this.data.dashboard || {};
      const kpis = db.kpis || [];
      const teams = db.teams || [];
      const dims = db.dimensions || [];

      const kpiContainer = document.getElementById('dashboard-kpi-grid');
      if (kpiContainer) {
        kpiContainer.innerHTML = kpis.map(k => `
          <div class="kpi-card ${k.critical ? 'kpi-critical' : ''} ${k.warning ? 'kpi-warning' : ''}">
            <div class="kpi-label">${k.label}</div>
            <div class="kpi-value">${k.value}</div>
            <div class="kpi-sub">${k.sub}</div>
            <div class="kpi-trend ${k.trendPositive ? 'trend-up' : 'trend-down'}">${k.trend}</div>
          </div>
        `).join('');
      }

      const teamContainer = document.getElementById('dashboard-teams-list');
      if (teamContainer) {
        teamContainer.innerHTML = teams.map(t => {
          let badgeClass = "badge-emerald";
          if (t.status === "Critical") badgeClass = "badge-coral";
          else if (t.status === "Moderate") badgeClass = "badge-amber";

          return `
            <div class="team-row-card">
              <div class="team-info">
                <span class="team-name">${t.name}</span>
                <span class="team-count">${t.count} check-ins</span>
              </div>
              <div class="team-metrics">
                <span class="team-score ${t.score < 50 ? 'score-danger' : 'score-good'}">${t.score}/100</span>
                <span class="team-badge ${badgeClass}">${t.status}</span>
              </div>
            </div>
          `;
        }).join('');
      }

      const dimContainer = document.getElementById('dashboard-dimensions-list');
      if (dimContainer) {
        dimContainer.innerHTML = dims.map(d => {
          const pct = Math.round((d.score / d.max) * 100);
          return `
            <div class="dim-row">
              <div class="dim-header">
                <span>${d.label}</span>
                <span class="dim-val">${d.score} / ${d.max}</span>
              </div>
              <div class="dim-bar-track">
                <div class="dim-bar-fill bar-${d.status}" style="width: ${pct}%"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    renderAuditTrailTable() {
      const tableBody = document.getElementById('audit-table-body');
      if (!tableBody) return;

      const records = this.data.auditTrail || [];
      tableBody.innerHTML = records.map(r => `
        <tr class="audit-row">
          <td class="audit-time">${r.timestamp.split(' ')[1]}</td>
          <td class="audit-tool"><code>${r.tool}</code></td>
          <td class="audit-status status-${r.status.toLowerCase()}">${r.status}</td>
          <td class="audit-input"><span class="code-snippet">${this._escape(r.sanitizedInput)}</span></td>
          <td class="audit-outcome">${r.outcome}</td>
        </tr>
      `).join('');
    }

    renderToolsList() {
      const toolsList = document.getElementById('tools-registry-list');
      if (!toolsList) return;

      const tools = this.data.toolsRegistry || [];
      toolsList.innerHTML = tools.map(t => `
        <div class="tool-card">
          <div class="tool-header">
            <code class="tool-name">${t.name}</code>
            <span class="tool-perm">${t.permission}</span>
          </div>
          <div class="tool-desc">${t.description}</div>
        </div>
      `).join('');
    }

    update(currentTime, currentStage) {
      this.currentStageId = currentStage ? currentStage.id : 1;

      // Update Top Stage Breadcrumb in Drawer
      this.updateStageBreadcrumbs(this.currentStageId);

      // Drawer state based on time
      // Stage 1 (0-45s): Closed initially, opens at 44s
      // Stage 2-6: Open
      if (currentTime >= 44.0) {
        this.openDrawer();
      } else {
        if (!this.isPausedByUser) {
          this.closeDrawer();
        }
      }

      // Sync active tab based on presentation timeline if not paused by user
      if (!this.isPausedByUser) {
        if (currentTime >= 255.0 && currentTime < 267.0) {
          this.switchTab('audit', false);
        } else if (currentTime < 255.0) {
          this.switchTab('react', false);
        }
      }

      // Stream ODAEA cards
      this.updateEventStream(currentTime);

      // Check special overlays
      this.updateOverlays(currentTime);
    }

    updateStageBreadcrumbs(stageId) {
      const crumbs = document.querySelectorAll('.rubric-crumb');
      crumbs.forEach(crumb => {
        const id = parseInt(crumb.dataset.stageId, 10);
        if (id === stageId) {
          crumb.classList.add('active-crumb');
          crumb.classList.remove('completed-crumb');
        } else if (id < stageId) {
          crumb.classList.add('completed-crumb');
          crumb.classList.remove('active-crumb');
        } else {
          crumb.classList.remove('active-crumb', 'completed-crumb');
        }
      });
    }

    updateEventStream(currentTime) {
      if (!this.eventStreamEl) return;

      const events = this.data.eventStream || [];
      let shouldScroll = false;

      events.forEach(ev => {
        if (currentTime >= ev.time) {
          if (!this.renderedEventIds.has(ev.id)) {
            this.renderEventCard(ev);
            this.renderedEventIds.add(ev.id);
            shouldScroll = true;

            // Trigger procedural chimes
            if (ev.isAdaptationHero && !this.playedChimes.has('alert') && this.audioManager) {
              this.audioManager.playAlertChime();
              this.playedChimes.add('alert');
            }
            if (ev.type === 'outcome' && !this.playedChimes.has('success') && this.audioManager) {
              this.audioManager.playSuccessChime();
              this.playedChimes.add('success');
            }
          }
        } else {
          // If seeking backward, remove future events
          if (this.renderedEventIds.has(ev.id)) {
            const cardEl = document.getElementById(`card-${ev.id}`);
            if (cardEl) cardEl.remove();
            this.renderedEventIds.delete(ev.id);
            if (ev.isAdaptationHero) this.playedChimes.delete('alert');
            if (ev.type === 'outcome') this.playedChimes.delete('success');
          }
        }
      });

      if (shouldScroll) {
        this.eventStreamEl.scrollTop = this.eventStreamEl.scrollHeight;
      }
    }

    renderEventCard(ev) {
      const card = document.createElement('div');
      card.id = `card-${ev.id}`;
      card.className = `event-card event-${ev.type} ${ev.isAdaptationHero ? 'card-adaptation-hero pulse-orange-border' : ''} animate-fade-in-up`;

      let innerHtml = `
        <div class="card-header">
          <div class="card-title-row">
            <span class="card-type-icon">${this._getCardIcon(ev.type)}</span>
            <span class="card-title">${ev.title}</span>
          </div>
          <span class="card-badge ${ev.badgeClass}">${ev.badge}</span>
        </div>
        <div class="card-summary">${ev.summary}</div>
      `;

      if (ev.callout) {
        innerHtml += `<div class="card-callout-banner">🔒 ${ev.callout}</div>`;
      }

      if (ev.trigger) {
        innerHtml += `<div class="card-trigger-code">${this._escape(ev.trigger)}</div>`;
      }

      if (ev.signals && ev.signals.length) {
        innerHtml += `<ul class="card-signal-list">
          ${ev.signals.map(s => `<li>${s}</li>`).join('')}
        </ul>`;
      }

      if (ev.stats && ev.stats.length) {
        innerHtml += `<div class="card-stats-grid">
          ${ev.stats.map(st => `
            <div class="stat-box">
              <span class="stat-lbl">${st.label}</span>
              <span class="stat-num">${st.value}</span>
            </div>
          `).join('')}
        </div>`;
      }

      if (ev.discoveries && ev.discoveries.length) {
        innerHtml += `<div class="card-section-title">Key Discoveries</div>
        <ul class="card-check-list">
          ${ev.discoveries.map(d => `<li><span class="check-icon">✓</span> ${d}</li>`).join('')}
        </ul>`;
      }

      if (ev.actionsTaken && ev.actionsTaken.length) {
        innerHtml += `<div class="card-section-title">Actions Executed</div>
        <ul class="card-check-list">
          ${ev.actionsTaken.map(a => `<li><span class="check-icon">✓</span> ${a}</li>`).join('')}
        </ul>`;
      }

      if (ev.details) {
        const jsonStr = JSON.stringify(ev.details, null, 2);
        innerHtml += `
          <details class="card-payload-details">
            <summary class="card-payload-summary">▸ Inspect Technical Schema & Payload</summary>
            <pre class="card-payload-json">${this._escape(jsonStr)}</pre>
          </details>
        `;
      }

      card.innerHTML = innerHtml;
      this.eventStreamEl.appendChild(card);
    }

    updateOverlays(currentTime) {
      // HITL Dialog: 242s to 254s
      const hitlModalEl = document.getElementById('hitl-confirmation-modal');
      if (hitlModalEl) {
        if (currentTime >= 242.0 && currentTime <= 254.0) {
          hitlModalEl.classList.add('modal-visible');
        } else {
          hitlModalEl.classList.remove('modal-visible');
        }
      }

      // Terminal Test View: 268s to 282s
      const terminalEl = document.getElementById('developer-terminal-overlay');
      if (terminalEl) {
        if (currentTime >= 268.0 && currentTime <= 282.0) {
          terminalEl.classList.add('overlay-visible');
        } else {
          terminalEl.classList.remove('overlay-visible');
        }
      }

      // Grand Finale Closing Slide: 292s to 300s
      const closingSlideEl = document.getElementById('grand-finale-overlay');
      if (closingSlideEl) {
        if (currentTime >= 292.0) {
          closingSlideEl.classList.add('overlay-visible');
        } else {
          closingSlideEl.classList.remove('overlay-visible');
        }
      }
    }

    openDrawer() {
      if (this.drawerEl && !this.isDrawerOpen) {
        this.drawerEl.classList.add('drawer-visible');
        this.isDrawerOpen = true;
      }
    }

    closeDrawer() {
      if (this.drawerEl && this.isDrawerOpen) {
        this.drawerEl.classList.remove('drawer-visible');
        this.isDrawerOpen = false;
      }
    }

    toggleDrawer() {
      if (this.isDrawerOpen) this.closeDrawer();
      else this.openDrawer();
    }

    switchTab(tabKey, userInitiated = true) {
      this.activeTab = tabKey;
      const tabBtns = document.querySelectorAll('.agent-tab-btn');
      const tabPanes = document.querySelectorAll('.drawer-tab-pane');

      tabBtns.forEach(btn => {
        if (btn.dataset.tab === tabKey) btn.classList.add('active-tab');
        else btn.classList.remove('active-tab');
      });

      tabPanes.forEach(pane => {
        if (pane.id === `tab-pane-${tabKey}`) pane.classList.add('active-pane');
        else pane.classList.remove('active-pane');
      });

      if (userInitiated && this.audioManager) {
        this.audioManager.playClickChime();
      }
    }

    reset() {
      this.renderedEventIds.clear();
      this.playedChimes.clear();
      if (this.eventStreamEl) this.eventStreamEl.innerHTML = "";
      this.closeDrawer();
      this.switchTab('react', false);
      this.updateOverlays(0);
    }

    _getCardIcon(type) {
      switch (type) {
        case 'goal': return '🎯';
        case 'decision': return '💡';
        case 'action': return '⚙️';
        case 'observation': return '🔍';
        case 'evaluation': return '📋';
        case 'failure_adaptation': return '🛡️';
        case 'outcome': return '✅';
        default: return '⚡';
      }
    }

    _escape(str) {
      return (str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }
  }

  root.SceneSimulator = SceneSimulator;
})(typeof window !== 'undefined' ? window : globalThis);
