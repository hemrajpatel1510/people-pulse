/**
 * PeoplePulse Presentation Timeline Engine
 * Authoritative Dual-Mode Master Clock (Audio Master + Synthetic Delta Fallback)
 * 300.0s master clock across 6 stages with micro-drift compensation.
 */

(function(root) {
  'use strict';

  class TimelineEngine {
    constructor(options = {}) {
      this.duration = options.duration || 300.0;
      this.currentTime = 0.0;
      this.speed = 1.0;
      this.isPlaying = false;
      this.isSeeking = false;
      this.isCompleted = false;

      // Stage boundaries
      this.stages = (options.stages || (root.PEOPLEPULSE_PRESENTATION_DATA && root.PEOPLEPULSE_PRESENTATION_DATA.stages) || [
        { id: 1, name: "Goal Context", start: 0.0, end: 45.0, color: "#3B82F6" },
        { id: 2, name: "Decision Framework", start: 45.0, end: 90.0, color: "#8B5CF6" },
        { id: 3, name: "Action Execution", start: 90.0, end: 134.0, color: "#64748B" },
        { id: 4, name: "Dynamic Evaluation", start: 134.0, end: 160.0, color: "#F59E0B" },
        { id: 5, name: "Failure Adaptation", start: 160.0, end: 225.0, color: "#F97316" },
        { id: 6, name: "Outcome & Governance", start: 225.0, end: 300.0, color: "#10B981" }
      ]).map(s => Object.assign({}, s));

      this.currentStageIndex = 0;
      this.audioManager = options.audioManager || null;
      this._lastSeekPerf = 0;

      // Clocks
      this.syntheticClock = {
        lastPerfTime: 0,
        accumulatedTime: 0.0
      };

      // Listeners
      this.tickListeners = [];
      this.stageChangeListeners = [];
      this.stateChangeListeners = [];

      this.rafId = null;
      this._onAnimationFrame = this._onAnimationFrame.bind(this);
    }

    setAudioManager(audioManager) {
      this.audioManager = audioManager;
    }

    getStageForTime(seconds) {
      const clamped = Math.max(0, Math.min(seconds, this.duration));
      for (let i = 0; i < this.stages.length; i++) {
        const s = this.stages[i];
        if (clamped >= s.start && (clamped < s.end || (i === this.stages.length - 1 && clamped <= s.end))) {
          return { stage: s, index: i };
        }
      }
      return { stage: this.stages[0], index: 0 };
    }

    play() {
      if (this.isCompleted) {
        this.seek(0);
      }
      if (this.isPlaying) return;

      this.isPlaying = true;
      this.syntheticClock.lastPerfTime = performance.now();

      if (this.audioManager) {
        this.audioManager.setRate(this.speed);
        this.audioManager.seek(this.currentTime);
        this.audioManager.play();
      }

      this._emitStateChange("PLAYING");
      this._startLoop();
    }

    pause() {
      if (!this.isPlaying) return;

      this.isPlaying = false;
      if (this.audioManager) {
        this.audioManager.pause();
      }

      this._emitStateChange("PAUSED");
      this._stopLoop();
      this._broadcastTick();
    }

    togglePlay() {
      if (this.isPlaying) {
        this.pause();
      } else {
        this.play();
      }
    }

    restart() {
      this.seek(0);
      this.play();
    }

    seek(targetSeconds) {
      if (typeof targetSeconds !== 'number' || !Number.isFinite(targetSeconds)) return;
      const clamped = Math.max(0.0, Math.min(targetSeconds, this.duration));
      this.currentTime = clamped;
      this.syntheticClock.accumulatedTime = clamped;
      this.syntheticClock.lastPerfTime = performance.now();
      this._lastSeekPerf = performance.now();
      this.isCompleted = (this.currentTime >= this.duration);

      if (this.audioManager) {
        this.audioManager.seek(this.currentTime);
      }

      this._updateStage(true);
      this._broadcastTick();
    }

    setSpeed(speedMultiplier) {
      const valid = [1.0, 1.25, 1.5];
      const target = valid.includes(speedMultiplier) ? speedMultiplier : 1.0;
      this.speed = target;

      if (this.audioManager) {
        this.audioManager.setRate(this.speed);
      }

      this.syntheticClock.lastPerfTime = performance.now();
      this._emitStateChange("SPEED_CHANGE");
      this._broadcastTick();
    }

    cycleSpeed() {
      const speeds = [1.0, 1.25, 1.5];
      const nextIdx = (speeds.indexOf(this.speed) + 1) % speeds.length;
      this.setSpeed(speeds[nextIdx]);
      return this.speed;
    }

    jumpToStage(indexOrKey) {
      let targetIdx = 0;
      if (typeof indexOrKey === 'number') {
        targetIdx = Math.max(0, Math.min(indexOrKey, this.stages.length - 1));
      } else if (typeof indexOrKey === 'string') {
        const found = this.stages.findIndex(s => s.key === indexOrKey || String(s.id) === indexOrKey);
        if (found !== -1) targetIdx = found;
      }
      const stage = this.stages[targetIdx];
      if (stage) {
        this.seek(stage.start + 0.05);
      }
    }

    onTick(fn) {
      if (typeof fn === 'function') this.tickListeners.push(fn);
      return () => {
        this.tickListeners = this.tickListeners.filter(l => l !== fn);
      };
    }

    onStageChange(fn) {
      if (typeof fn === 'function') this.stageChangeListeners.push(fn);
      return () => {
        this.stageChangeListeners = this.stageChangeListeners.filter(l => l !== fn);
      };
    }

    onStateChange(fn) {
      if (typeof fn === 'function') this.stateChangeListeners.push(fn);
      return () => {
        this.stateChangeListeners = this.stateChangeListeners.filter(l => l !== fn);
      };
    }

    _startLoop() {
      if (this.rafId) cancelAnimationFrame(this.rafId);
      this.syntheticClock.lastPerfTime = performance.now();
      this.rafId = requestAnimationFrame(this._onAnimationFrame);
    }

    _stopLoop() {
      if (this.rafId) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
    }

    _onAnimationFrame(now) {
      if (!this.isPlaying) return;

      const deltaMs = now - this.syntheticClock.lastPerfTime;
      this.syntheticClock.lastPerfTime = now;
      const deltaSec = (deltaMs / 1000.0) * this.speed;

      // Check audio master time with seek settling guard
      let masterTime = null;
      const justSeeked = (now - this._lastSeekPerf < 500);
      if (!justSeeked && this.audioManager && this.audioManager.isAvailable() && this.audioManager.isPlaying()) {
        masterTime = this.audioManager.getCurrentTime();
      }

      if (masterTime !== null && typeof masterTime === 'number' && !isNaN(masterTime)) {
        // Continuous exponential drift compensation
        const drift = masterTime - this.currentTime;
        if (Math.abs(drift) > 0.3) {
          // Hard sync on large frame hitch
          this.currentTime = masterTime;
        } else if (Math.abs(drift) > 0.04) {
          // Soft sync
          this.currentTime += (deltaSec + drift * 0.15);
        } else {
          this.currentTime += deltaSec;
        }
      } else {
        // Fallback: Pure synthetic high-res performance clock
        this.currentTime += deltaSec;
      }

      // Check end boundary
      if (this.currentTime >= this.duration) {
        this.currentTime = this.duration;
        this.isPlaying = false;
        this.isCompleted = true;
        if (this.audioManager) {
          this.audioManager.pause();
        }
        this._stopLoop();
        this._updateStage(true);
        this._emitStateChange("COMPLETED");
        this._broadcastTick();
        return;
      }

      this._updateStage(false);
      this._broadcastTick();

      if (this.isPlaying) {
        this.rafId = requestAnimationFrame(this._onAnimationFrame);
      }
    }

    _updateStage(forceNotify) {
      const { stage, index } = this.getStageForTime(this.currentTime);
      if (forceNotify || index !== this.currentStageIndex) {
        const prevIndex = this.currentStageIndex;
        this.currentStageIndex = index;
        this.stageChangeListeners.forEach(cb => {
          try {
            cb({
              currentStage: stage,
              stageIndex: index,
              prevStageIndex: prevIndex,
              currentTime: this.currentTime
            });
          } catch (e) {
            console.error("Error in stageChange listener:", e);
          }
        });
      }
    }

    _broadcastTick() {
      const currentStage = this.stages[this.currentStageIndex] || this.stages[0];
      const payload = {
        currentTime: this.currentTime,
        duration: this.duration,
        progressPercent: Math.min(100, (this.currentTime / this.duration) * 100),
        stage: currentStage,
        stageIndex: this.currentStageIndex,
        isPlaying: this.isPlaying,
        isPaused: !this.isPlaying,
        isCompleted: this.isCompleted,
        speed: this.speed
      };

      for (let i = 0; i < this.tickListeners.length; i++) {
        try {
          this.tickListeners[i](payload);
        } catch (e) {
          console.error("Error in tick listener:", e);
        }
      }
    }

    _emitStateChange(state) {
      const currentStage = this.stages[this.currentStageIndex] || this.stages[0];
      const payload = {
        state: state,
        currentTime: this.currentTime,
        isPlaying: this.isPlaying,
        speed: this.speed,
        stage: currentStage
      };
      this.stateChangeListeners.forEach(cb => {
        try {
          cb(payload);
        } catch (e) {
          console.error("Error in stateChange listener:", e);
        }
      });
    }
  }

  root.TimelineEngine = TimelineEngine;
})(typeof window !== 'undefined' ? window : globalThis);
