/**
 * PeoplePulse Interactive Controller
 * Decouples automated presentation timeline from live sandbox UI.
 * Enables live-pause exploration (tabs, JSON inspector, audit log, HITL modal)
 * and guarantees smooth resynchronization upon resuming.
 */

(function(root) {
  'use strict';

  class InteractiveController {
    constructor(options = {}) {
      this.timelineEngine = options.timelineEngine || null;
      this.sceneSimulator = options.sceneSimulator || null;
      this.audioManager = options.audioManager || null;
      this.subtitleRenderer = options.subtitleRenderer || null;

      this.isSandboxActive = false;
      this.expandedCardDetails = new Set();
      this.userAuditFilter = "";

      this.init();
    }

    init() {
      this._bindUserInteractionEvents();
    }

    setDependencies({ timelineEngine, sceneSimulator, audioManager, subtitleRenderer }) {
      if (timelineEngine) this.timelineEngine = timelineEngine;
      if (sceneSimulator) this.sceneSimulator = sceneSimulator;
      if (audioManager) this.audioManager = audioManager;
      if (subtitleRenderer) this.subtitleRenderer = subtitleRenderer;
    }

    onPause() {
      this.isSandboxActive = true;
      if (this.sceneSimulator) {
        this.sceneSimulator.isPausedByUser = true;
      }
      this._showSandboxStatusBadge(true);
    }

    onResume() {
      this.isSandboxActive = false;
      if (this.sceneSimulator) {
        this.sceneSimulator.isPausedByUser = false;
        // Resynchronize tab if necessary based on currentTime
        if (this.timelineEngine) {
          const t = this.timelineEngine.currentTime;
          if (t >= 255.0 && t < 267.0) {
            this.sceneSimulator.switchTab('audit', false);
          } else {
            this.sceneSimulator.switchTab('react', false);
          }
        }
      }
      this._showSandboxStatusBadge(false);
    }

    _showSandboxStatusBadge(isActive) {
      const badge = document.getElementById('sandbox-mode-indicator');
      if (badge) {
        if (isActive) {
          badge.classList.add('visible');
          badge.innerHTML = `<span class="pulse-dot"></span> Interactive Sandbox Mode Unlocked (Paused)`;
        } else {
          badge.classList.remove('visible');
        }
      }
    }

    _bindUserInteractionEvents() {
      // PulseAgent floating button toggle
      const copilotBtn = document.getElementById('floating-copilot-btn');
      if (copilotBtn) {
        copilotBtn.addEventListener('click', () => {
          if (this.sceneSimulator) {
            this.sceneSimulator.toggleDrawer();
          }
        });
      }

      // Drawer close button
      const closeBtn = document.getElementById('close-drawer-btn');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          if (this.sceneSimulator) {
            this.sceneSimulator.closeDrawer();
          }
        });
      }

      // Drawer tab buttons
      const tabBtns = document.querySelectorAll('.agent-tab-btn');
      tabBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
          const tabKey = btn.dataset.tab;
          if (this.sceneSimulator && tabKey) {
            this.sceneSimulator.switchTab(tabKey, true);
          }
        });
      });

      // Quick Preset button
      const presetBtn = document.getElementById('quick-preset-btn');
      if (presetBtn) {
        presetBtn.addEventListener('click', () => {
          if (this.timelineEngine) {
            // Jump to preset start (90.0s)
            this.timelineEngine.seek(90.0);
            if (!this.timelineEngine.isPlaying) {
              this.timelineEngine.play();
            }
          }
        });
      }

      // Rubric breadcrumbs click-to-seek
      const crumbs = document.querySelectorAll('.rubric-crumb');
      crumbs.forEach(crumb => {
        crumb.addEventListener('click', () => {
          const stageId = parseInt(crumb.dataset.stageId, 10);
          if (this.timelineEngine && !isNaN(stageId)) {
            const stages = this.timelineEngine.stages;
            const target = stages.find(s => s.id === stageId);
            if (target) {
              this.timelineEngine.seek(target.start + 0.1);
            }
          }
        });
      });

      // HITL Confirmation modal buttons
      const approveBtn = document.getElementById('hitl-approve-btn');
      const denyBtn = document.getElementById('hitl-deny-btn');
      const hitlModal = document.getElementById('hitl-confirmation-modal');

      if (approveBtn && hitlModal) {
        approveBtn.addEventListener('click', () => {
          this._showToast("Action APPROVED: Manager alert broadcast authorized.", "success");
          hitlModal.classList.remove('modal-visible');
        });
      }

      if (denyBtn && hitlModal) {
        denyBtn.addEventListener('click', () => {
          this._showToast("Action DENIED: Broadcast halted safely by administrator.", "warning");
          hitlModal.classList.remove('modal-visible');
        });
      }

      // Technical Defense Modal Trigger
      const qaBtn = document.getElementById('btn-open-defense');
      if (qaBtn) {
        qaBtn.addEventListener('click', () => this.openDefenseModal());
      }
      const closeQaBtn = document.getElementById('close-defense-modal-btn');
      if (closeQaBtn) {
        closeQaBtn.addEventListener('click', () => this.closeDefenseModal());
      }

      // Transcript Toggle Trigger
      const transcriptBtn = document.getElementById('btn-toggle-transcript');
      if (transcriptBtn) {
        transcriptBtn.addEventListener('click', () => {
          if (this.subtitleRenderer) {
            this.subtitleRenderer.toggleTranscript();
          }
        });
      }
      const closeTranscriptBtn = document.getElementById('close-transcript-btn');
      if (closeTranscriptBtn) {
        closeTranscriptBtn.addEventListener('click', () => {
          if (this.subtitleRenderer) {
            this.subtitleRenderer.closeTranscript();
          }
        });
      }
    }

    openDefenseModal() {
      const modal = document.getElementById('technical-defense-modal');
      const list = document.getElementById('defense-qa-list');
      if (modal && list) {
        const qaData = (root.PEOPLEPULSE_PRESENTATION_DATA && root.PEOPLEPULSE_PRESENTATION_DATA.qaDefense) || [];
        list.innerHTML = qaData.map((item, idx) => `
          <div class="defense-qa-card">
            <div class="defense-q">Q${idx + 1}: ${item.question}</div>
            <div class="defense-a">${item.answer}</div>
          </div>
        `).join('');
        modal.classList.add('modal-visible');
      }
    }

    closeDefenseModal() {
      const modal = document.getElementById('technical-defense-modal');
      if (modal) modal.classList.remove('modal-visible');
    }

    _showToast(msg, type = "info") {
      let toast = document.getElementById('player-toast');
      if (!toast) {
        toast = document.createElement('div');
        toast.id = 'player-toast';
        document.body.appendChild(toast);
      }
      toast.className = `player-toast toast-${type} toast-show`;
      toast.textContent = msg;

      setTimeout(() => {
        toast.classList.remove('toast-show');
      }, 3500);
    }
  }

  root.InteractiveController = InteractiveController;
})(typeof window !== 'undefined' ? window : globalThis);
