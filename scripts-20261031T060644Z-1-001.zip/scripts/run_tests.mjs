#!/usr/bin/env node

/**
 * PeoplePulse E2E Test Suite Runner
 * Executes the complete 4-tier test architecture:
 *   - Tier 1: Feature Coverage (120 tests across 24 features)
 *   - Tier 2: Boundary & Corner Cases (120 tests across 24 features)
 *   - Tier 3: Cross-Feature Combinations (24 pairwise interaction tests)
 *   - Tier 4: Real-World Application Scenarios (12 end-to-end scenarios)
 * Total: 276 test cases (Minimum required: 276)
 *
 * Usage:
 *   node demo_video_player/scripts/run_tests.mjs [options]
 *
 * Options:
 *   --tier=<1|2|3|4>   Run only specified tier
 *   --filter=<pattern> Run tests matching pattern
 *   --tap              Output Test Anything Protocol (TAP) format
 *   --json             Output JSON report
 *   --verbose          Print all individual test names
 */

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { TestRunner } from '../tests/harness.mjs';
import { registerTier1Tests } from '../tests/tier1_feature_coverage.test.mjs';
import { registerTier2Tests } from '../tests/tier2_boundary_corner.test.mjs';
import { registerTier3Tests } from '../tests/tier3_cross_feature.test.mjs';
import { registerTier4Tests } from '../tests/tier4_real_world_scenarios.test.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ANSI color helpers
const colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
  blue: '\x1b[34m',
  gray: '\x1b[90m'
};

async function main() {
  const args = process.argv.slice(2);
  const options = {
    tier: null,
    filter: null,
    tap: false,
    json: false,
    verbose: false
  };

  for (const arg of args) {
    if (arg.startsWith('--tier=')) {
      options.tier = parseInt(arg.split('=')[1], 10);
    } else if (arg.startsWith('--filter=')) {
      options.filter = arg.split('=')[1];
    } else if (arg === '--tap') {
      options.tap = true;
    } else if (arg === '--json') {
      options.json = true;
    } else if (arg === '--verbose' || arg === '-v') {
      options.verbose = true;
    }
  }

  const runner = new TestRunner('PeoplePulse E2E Test Suite');

  // Register tiers according to options
  if (!options.tier || options.tier === 1) {
    registerTier1Tests(runner);
  }
  if (!options.tier || options.tier === 2) {
    registerTier2Tests(runner);
  }
  if (!options.tier || options.tier === 3) {
    registerTier3Tests(runner);
  }
  if (!options.tier || options.tier === 4) {
    registerTier4Tests(runner);
  }

  if (!options.tap && !options.json) {
    console.log(`${colors.bold}${colors.cyan}========================================================================${colors.reset}`);
    console.log(`${colors.bold}${colors.cyan} PeoplePulse Presentation Player & Simulator — E2E Test Suite${colors.reset}`);
    console.log(`${colors.dim} 4-Tier Verification Architecture (Tiers 1-4) | Target: >=276 Tests${colors.reset}`);
    console.log(`${colors.bold}${colors.cyan}========================================================================${colors.reset}\n`);
  }

  const filterOptions = options.filter ? { pattern: options.filter } : {};
  const report = await runner.run(filterOptions);

  if (options.json) {
    console.log(JSON.stringify(report, null, 2));
    process.exit(report.failed > 0 ? 1 : 0);
  }

  if (options.tap) {
    console.log('TAP version 13');
    let testNum = 0;
    for (const suite of report.suites) {
      for (const t of suite.tests) {
        testNum++;
        if (t.passed) {
          console.log(`ok ${testNum} - ${t.name} (${t.durationMs}ms)`);
        } else {
          console.log(`not ok ${testNum} - ${t.name} (${t.durationMs}ms)`);
          if (t.error) {
            console.log(`  ---`);
            console.log(`  message: ${t.error.split('\n')[0]}`);
            console.log(`  ...`);
          }
        }
      }
    }
    console.log(`1..${testNum}`);
    process.exit(report.failed > 0 ? 1 : 0);
  }

  // Standard Console Output
  for (const suite of report.suites) {
    console.log(`${colors.bold}${colors.blue}▶ Suite: ${suite.suiteName}${colors.reset}`);
    let suitePass = 0;
    let suiteFail = 0;

    for (const t of suite.tests) {
      if (t.passed) {
        suitePass++;
        if (options.verbose) {
          console.log(`  ${colors.green}✔${colors.reset} ${colors.gray}${t.name}${colors.reset} ${colors.dim}(${t.durationMs}ms)${colors.reset}`);
        }
      } else {
        suiteFail++;
        console.log(`  ${colors.bold}${colors.red}✖ ${t.name}${colors.reset} ${colors.dim}(${t.durationMs}ms)${colors.reset}`);
        if (t.error) {
          console.log(`    ${colors.red}${t.error.split('\n').join('\n    ')}${colors.reset}`);
        }
      }
    }

    const suiteColor = suiteFail === 0 ? colors.green : colors.red;
    console.log(`  ${suiteColor}Result: ${suitePass} passed, ${suiteFail} failed (${suite.durationMs}ms)${colors.reset}\n`);
  }

  // Summary Table
  console.log(`${colors.bold}${colors.cyan}------------------------------------------------------------------------${colors.reset}`);
  console.log(`${colors.bold} Verification Summary Table${colors.reset}`);
  console.log(`${colors.bold}${colors.cyan}------------------------------------------------------------------------${colors.reset}`);
  console.log(` ${colors.bold}Tier${' '.repeat(34)}Tests${' '.repeat(4)}Passed${' '.repeat(4)}Status${colors.reset}`);
  console.log(` ${'-'.repeat(58)}`);

  let tierIdx = 1;
  for (const suite of report.suites) {
    const passedCount = suite.tests.filter(t => t.passed).length;
    const totalCount = suite.tests.length;
    const isOk = passedCount === totalCount && totalCount > 0;
    const statusText = isOk ? `${colors.green}PASS${colors.reset}` : `${colors.red}FAIL${colors.reset}`;
    const suiteLabel = suite.suiteName.length > 35 ? suite.suiteName.slice(0, 35) : suite.suiteName.padEnd(35, ' ');
    console.log(` ${suiteLabel}  ${String(totalCount).padStart(3, ' ')}     ${String(passedCount).padStart(3, ' ')}      ${statusText}`);
    tierIdx++;
  }

  console.log(` ${'-'.repeat(58)}`);
  console.log(` ${colors.bold}Total Test Cases:${colors.reset}                ${colors.bold}${report.total}${colors.reset}     ${colors.bold}${colors.green}${report.passed}${colors.reset}      ${report.failed === 0 ? `${colors.bold}${colors.green}ALL PASSED${colors.reset}` : `${colors.bold}${colors.red}FAILURES${colors.reset}`}`);
  console.log(` ${colors.bold}Execution Duration:${colors.reset}              ${(report.durationMs / 1000).toFixed(2)}s`);
  console.log(`${colors.bold}${colors.cyan}========================================================================${colors.reset}\n`);

  if (report.failed > 0) {
    console.error(`${colors.bold}${colors.red}❌ Test suite finished with ${report.failed} failure(s).${colors.reset}\n`);
    process.exit(1);
  } else {
    console.log(`${colors.bold}${colors.green}✅ 100% E2E tests passing! All 4 tiers verified cleanly.${colors.reset}\n`);
    process.exit(0);
  }
}

main().catch(err => {
  console.error(`${colors.bold}${colors.red}Fatal Runner Error:${colors.reset}`, err);
  process.exit(1);
});
