#!/usr/bin/env node
/**
 * PeoplePulse Automated Headless Verification Harness (Edge CDP)
 * Node >= 22 (built-in WebSocket).
 * Verifies:
 *   1. Page Load & Initialization
 *   2. Zero Console Errors / Runtime Exceptions
 *   3. Audio Asset Integrity (300s duration, valid files)
 *   4. Subtitle Karaoke Alignment
 *   5. Timeline Continuity & Monotonic Clock Advance
 *   6. 6-Stage Rubric Jump Navigation & Card Streaming
 *   7. Glowing Orange HTTP 503 Failure Adaptation Card
 *   8. Interactive Live-Pause Sandbox (Tabs, JSON expansion, Resumption)
 */

import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CDP_PORT = 9226;
const HTTP_PORT = 8089;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

let server;
let edgeProc;
let ws;
let msgId = 0;
const pending = new Map();
const consoleErrors = [];
const runtimeExceptions = [];

// Lightweight In-Process HTTP Server to serve demo_video_player
function startStaticServer() {
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.vtt': 'text/vtt',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.png': 'image/png',
    '.svg': 'image/svg+xml'
  };

  return new Promise((resolve) => {
    server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent(req.url.split('?')[0]);
      if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
      const filePath = path.join(ROOT_DIR, reqPath);

      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('Not Found: ' + reqPath);
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        const contentType = mimeTypes[ext] || 'application/octet-stream';
        res.writeHead(200, {
          'Content-Type': contentType,
          'Access-Control-Allow-Origin': '*'
        });
        res.end(data);
      });
    });

    server.listen(HTTP_PORT, () => {
      console.log(`[Static Server] Serving demo_video_player on http://localhost:${HTTP_PORT}`);
      resolve();
    });
  });
}

function launchHeadlessEdge() {
  const args = [
    '--headless=new',
    `--remote-debugging-port=${CDP_PORT}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-background-networking',
    '--disable-gpu',
    '--autoplay-policy=no-user-gesture-required',
    `--user-data-dir=${path.join(process.env.TEMP || 'C:\\temp', 'edge_pp_test_profile_' + Date.now())}`,
    `http://localhost:${HTTP_PORT}`
  ];

  edgeProc = spawn(EDGE_PATH, args, { stdio: 'ignore' });
  edgeProc.on('error', (err) => {
    console.error('Failed to spawn Edge:', err);
  });
}

async function connectCDP() {
  let wsUrl = null;
  for (let i = 0; i < 30; i++) {
    try {
      const res = await fetch(`http://localhost:${CDP_PORT}/json`);
      if (res.ok) {
        const pages = await res.json();
        const target = pages.find(p => p.type === 'page' && p.url.includes(String(HTTP_PORT)));
        if (target && target.webSocketDebuggerUrl) {
          wsUrl = target.webSocketDebuggerUrl;
          break;
        }
      }
    } catch (e) {}
    await sleep(250);
  }

  if (!wsUrl) throw new Error('Could not connect to Edge DevTools Protocol endpoint.');

  return new Promise((resolve, reject) => {
    ws = new WebSocket(wsUrl);
    ws.onopen = () => resolve();
    ws.onerror = (e) => reject(new Error('WebSocket connection error: ' + e.message));
    ws.onmessage = (raw) => {
      const data = JSON.parse(raw.data);
      if (data.id && pending.has(data.id)) {
        const { resolve, reject } = pending.get(data.id);
        pending.delete(data.id);
        if (data.error) reject(new Error(data.error.message));
        else resolve(data.result);
      } else if (data.method === 'Runtime.consoleAPICalled') {
        const type = data.params.type;
        const text = (data.params.args || []).map(a => a.value ?? a.description ?? '').join(' ');
        if (type === 'error') {
          consoleErrors.push(text);
        }
      } else if (data.method === 'Runtime.exceptionThrown') {
        const text = data.params.exceptionDetails?.text + ' ' + (data.params.exceptionDetails?.exception?.description || '');
        runtimeExceptions.push(text);
      }
    };
  });
}

function cdp(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function evalExpr(expression) {
  const safeWrapped = `(async function(){
    try {
      const __val = await (${expression});
      if (__val === undefined) return '__UNDEFINED__';
      return JSON.stringify(__val);
    } catch(err) {
      return JSON.stringify({ __eval_error: String(err && err.message ? err.message : err) });
    }
  })()`;

  const res = await cdp('Runtime.evaluate', {
    expression: safeWrapped,
    returnByValue: true,
    awaitPromise: true
  });

  if (res.exceptionDetails) {
    return { error: res.exceptionDetails.text };
  }
  const raw = res.result?.value;
  if (raw === '__UNDEFINED__') return { value: undefined };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.__eval_error) {
      return { error: parsed.__eval_error };
    }
    return { value: parsed };
  } catch {
    return { value: raw };
  }
}

async function runVerification() {
  console.log('================================================================');
  console.log('  PEOPLEPULSE PLAYER & SIMULATOR HEADLESS VERIFICATION HARNESS  ');
  console.log('================================================================');

  let passedTests = 0;
  let totalTests = 0;

  function assert(name, condition, extraInfo = '') {
    totalTests++;
    if (condition) {
      passedTests++;
      console.log(`  ✓ PASS: ${name} ${extraInfo ? '(' + extraInfo + ')' : ''}`);
    } else {
      console.error(`  ✗ FAIL: ${name} ${extraInfo ? '(' + extraInfo + ')' : ''}`);
      throw new Error(`Assertion failed: ${name}`);
    }
  }

  try {
    await startStaticServer();
    launchHeadlessEdge();
    await connectCDP();

    await cdp('Runtime.enable');
    await cdp('Page.enable');

    console.log('\n[1/7] Testing Page Initialization & DOM Ready...');
    await sleep(1500);

    const readyState = (await evalExpr('document.readyState')).value;
    assert('DOM readyState is complete', readyState === 'complete', readyState);

    const hasPlayer = (await evalExpr('typeof window.PeoplePulsePlayer === "object"')).value;
    assert('window.PeoplePulsePlayer is exposed', hasPlayer === true);

    const stagesCount = (await evalExpr('window.PeoplePulsePlayer.timeline.stages.length')).value;
    assert('Timeline contains exactly 6 official stages', stagesCount === 6, `found ${stagesCount}`);

    console.log('\n[2/7] Testing Audio Asset Validity...');
    const mp3Exists = fs.existsSync(path.join(ROOT_DIR, 'assets', 'audio', 'narration_full.mp3'));
    assert('narration_full.mp3 asset exists on filesystem', mp3Exists);

    const wavExists = fs.existsSync(path.join(ROOT_DIR, 'assets', 'audio', 'narration_sapi.wav'));
    assert('narration_sapi.wav fallback asset exists on filesystem', wavExists);

    const audioDuration = (await evalExpr('window.PeoplePulsePlayer.audio.getDuration()')).value;
    assert('Audio duration is 300.0s (>= 295s)', audioDuration >= 295.0, `${audioDuration}s`);

    console.log('\n[3/7] Testing Hero Splash Start & Playback Initialization...');
    // Click Start button
    await evalExpr('document.getElementById("btn-start-pitch").click()');
    await sleep(600);

    const isPlaying = (await evalExpr('window.PeoplePulsePlayer.timeline.isPlaying')).value;
    assert('Player enters PLAYING state after clicking start', isPlaying === true);

    await sleep(1000);
    const timeT1 = (await evalExpr('window.PeoplePulsePlayer.timeline.currentTime')).value;
    assert('Timeline clock advances monotonically', timeT1 > 0.4, `${timeT1.toFixed(2)}s`);

    console.log('\n[4/7] Testing Stage Jump Navigation Across All 6 Stages...');
    const testCheckpoints = [
      { id: 1, name: 'Goal Context', seek: 5.0, expectedStageId: 1 },
      { id: 2, name: 'Decision Framework', seek: 48.0, expectedStageId: 2 },
      { id: 3, name: 'Action Execution', seek: 95.0, expectedStageId: 3 },
      { id: 4, name: 'Dynamic Evaluation', seek: 138.0, expectedStageId: 4 },
      { id: 5, name: 'Failure Adaptation', seek: 165.0, expectedStageId: 5 },
      { id: 6, name: 'Outcome & Governance', seek: 230.0, expectedStageId: 6 }
    ];

    for (const cp of testCheckpoints) {
      await evalExpr(`window.PeoplePulsePlayer.timeline.seek(${cp.seek})`);
      await sleep(200);
      const curStage = (await evalExpr('window.PeoplePulsePlayer.timeline.currentStageIndex + 1')).value;
      assert(`Seek to ${cp.seek}s activates Stage ${cp.id} (${cp.name})`, curStage === cp.expectedStageId, `active stage: ${curStage}`);
    }

    console.log('\n[5/7] Testing Glowing Orange HTTP 503 Failure Adaptation Card...');
    // Seek to 180s where Adaptation card is active
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(180.0)');
    await sleep(300);

    const hasHeroCard = (await evalExpr('document.querySelector(".card-adaptation-hero") !== null')).value;
    assert('Prominent glowing orange adaptation card is rendered at 180s', hasHeroCard === true);

    const triggerText = (await evalExpr('document.querySelector(".card-trigger-code")?.textContent || ""')).value;
    assert('Adaptation card displays HTTP 503 interception trigger', triggerText.includes('HTTP 503'), triggerText);

    console.log('\n[6/7] Testing Interactive Live-Pause Sandbox Mode...');
    // Pause playback
    await evalExpr('window.PeoplePulsePlayer.timeline.pause()');
    await sleep(300);

    const isPaused = (await evalExpr('!window.PeoplePulsePlayer.timeline.isPlaying')).value;
    assert('Player successfully pauses', isPaused === true);

    const isSandboxUnlocked = (await evalExpr('document.getElementById("sandbox-mode-indicator").classList.contains("visible")')).value;
    assert('Sandbox mode indicator is unlocked and visible', isSandboxUnlocked === true);

    // Switch tab to Audit Trail
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"audit\\"]").click()');
    await sleep(200);
    const activeTab = (await evalExpr('window.PeoplePulsePlayer.simulator.activeTab')).value;
    assert('Drawer switches to Audit Trail tab in sandbox mode', activeTab === 'audit');

    const auditRowsCount = (await evalExpr('document.querySelectorAll("#audit-table-body tr").length')).value;
    assert('Audit trail table renders sanitized activity logs', auditRowsCount >= 4, `${auditRowsCount} rows`);

    // Switch back to ReAct tab and inspect payload details
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"react\\"]").click()');
    await sleep(200);

    // Expand details
    const detailsExpanded = (await evalExpr('(() => { const d = document.querySelector(".card-payload-details"); if (d) { d.open = true; return true; } return false; })()')).value;
    assert('User can expand raw JSON payload schema in sandbox', detailsExpanded === true);

    // Resume playback smoothly
    await evalExpr('window.PeoplePulsePlayer.timeline.play()');
    await sleep(300);
    const isResumed = (await evalExpr('window.PeoplePulsePlayer.timeline.isPlaying')).value;
    assert('Playback resumes smoothly without desynchronization', isResumed === true);

    console.log('\n[7/7] Testing Real-Time Subtitles & Console Error Purity...');
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(2.0)');
    await sleep(250);
    const captionText = (await evalExpr('document.getElementById("subtitle-text").textContent')).value;
    assert('Subtitle text matches pitch script at t=2.0s', captionText.includes('76%') && captionText.includes('burnout'), captionText.slice(0, 60));

    // Console errors and exception purity
    assert('Zero browser console errors detected', consoleErrors.length === 0, consoleErrors.join('; '));
    assert('Zero unhandled runtime exceptions thrown', runtimeExceptions.length === 0, runtimeExceptions.join('; '));

    console.log('\n================================================================');
    console.log(`  VERIFICATION PASSED: ${passedTests} / ${totalTests} TESTS PASSED (100%)`);
    console.log('================================================================\n');

    process.exitCode = 0;
  } catch (err) {
    console.error('\nVerification halted with error:', err.message);
    process.exitCode = 1;
  } finally {
    if (ws) ws.close();
    if (edgeProc) edgeProc.kill();
    if (server) server.close();
  }
}

runVerification();
