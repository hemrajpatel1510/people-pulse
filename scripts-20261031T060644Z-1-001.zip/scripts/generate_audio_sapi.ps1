# PeoplePulse Offline SAPI Voiceover Generator (PowerShell + System.Speech)
# Generates offline Windows SAPI fallback audio: assets/audio/narration_sapi.wav (300.0s)
# Synthesizes discrete cue WAVs aligned to cue start offsets via adelay + amix

param(
    [string]$OutputPath = "$PSScriptRoot\..\assets\audio\narration_sapi.wav"
)

$ErrorActionPreference = "Stop"

Write-Host "Initializing Windows SAPI SpeechSynthesizer..."
Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer

# Ensure output directory exists
$outputDir = Split-Path -Path $OutputPath -Parent
if (-not (Test-Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
}

$subtitlesPath = Join-Path $PSScriptRoot "..\assets\subtitles\subtitles.json"
if (Test-Path $subtitlesPath) {
    $subData = Get-Content -Raw -Encoding UTF8 $subtitlesPath | ConvertFrom-Json
    $cues = $subData.cues
} else {
    Write-Error "subtitles.json not found at $subtitlesPath"
    exit 1
}

$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("sapi_sync_" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

$filterParts = @()
$inputs = @("-f", "lavfi", "-t", "300.0", "-i", "anullsrc=r=22050:cl=mono")
$mixInputs = @("[0:a]")
$tempFiles = @()

try {
    for ($i = 0; $i -lt $cues.Count; $i++) {
        $cue = $cues[$i]
        $cueWav = Join-Path $tempDir ("cue_{0:D2}.wav" -f $i)
        $tempFiles += $cueWav

        Write-Host ("[{0:D2}/{1:D2}] Synthesizing {2} ({3}s -> {4}s)..." -f ($i+1), $cues.Count, $cue.id, $cue.start, $cue.end)

        $synth.SetOutputToWaveFile($cueWav)
        $cleanText = $cue.text.Replace([string][char]0x2014, ", ").Replace([string][char]0x2013, ", ")
        $synth.Speak($cleanText)
        $synth.SetOutputToNull()

        # Probe duration
        $durStr = & ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $cueWav
        $actualDur = [double]$durStr.Trim()
        $maxAlloc = ($cue.end - $cue.start) - 0.10

        # Atempo conform if SAPI duration exceeds window
        if ($actualDur -gt $maxAlloc) {
            $tempo = [math]::Round(($actualDur / $maxAlloc), 4)
            $conformedWav = Join-Path $tempDir ("cue_{0:D2}_conformed.wav" -f $i)
            $tempFiles += $conformedWav
            & ffmpeg -y -i $cueWav -filter:a "atempo=$tempo" $conformedWav
            $cueWav = $conformedWav
        }

        $delayMs = [int][math]::Round($cue.start * 1000)
        $inpIdx = $i + 1
        $inputs += "-i"
        $inputs += $cueWav
        $filterParts += ("[{0}:a]adelay={1}|{1},volume=1.0[a{0}]" -f $inpIdx, $delayMs)
        $mixInputs += ("[a{0}]" -f $inpIdx)
    }

    $mixStr = ($mixInputs -join "") + "amix=inputs=$($cues.Count + 1):duration=first:dropout_transition=0[outa]"
    $filterParts += $mixStr
    $fullFilter = $filterParts -join ";"

    Write-Host "Assembling synchronized SAPI narration with FFmpeg..."
    & ffmpeg -y @inputs -filter_complex $fullFilter -map "[outa]" -t 300.0 -c:a pcm_s16le $OutputPath
    Write-Host "SAPI narration successfully generated: $OutputPath"
}
finally {
    $synth.Dispose()
    foreach ($f in $tempFiles) {
        if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue }
    }
    if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
}
