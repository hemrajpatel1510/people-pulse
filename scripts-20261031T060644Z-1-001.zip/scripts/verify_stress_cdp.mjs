#!/usr/bin/env node
/**
 * Challenger 1: Live Headless Edge CDP Real-Browser Transport & Timeline Stress Harness
 * Node >= 22 (built-in WebSocket & fetch).
 *
 * Stresses the presentation player engine inside real Microsoft Edge browser:
 *   1. 200 Rapid Random Seeks in live DOM
 *   2. 100 Rapid Play/Pause toggles
 *   3. Boundary Seeks (0.0s, 300.0s, -20s, 400s)
 *   4. Live Speed Multiplier Toggling (1.0x, 1.25x, 1.5x)
 *   5. Scrubber & Rubric DOM Breadcrumb Synchronization Under Chaos
 *   6. Global Keyboard Shortcut Event Stress (Space, Arrow keys, 1-6, S, M, R)
 *   7. Absolute Browser Console Purity (Zero Errors, Zero Runtime Exceptions)
 */

import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CDP_PORT = 9228;
const HTTP_PORT = 8092;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

let server;
let edgeProc;
let ws;
let msgId = 0;
const pending = new Map();
const consoleErrors = [];
const runtimeExceptions = [];

function startStaticServer() {
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.vtt': 'text/vtt',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.png': 'image/png',
    '.svg': 'image/svg+xml'
  };

  return new Promise((resolve) => {
    server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent(req.url.split('?')[0]);
      if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
      const filePath = path.join(ROOT_DIR, reqPath);

      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('Not Found: ' + reqPath);
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        const contentType = mimeTypes[ext] || 'application/octet-stream';
        res.writeHead(200, {
          'Content-Type': contentType,
          'Access-Control-Allow-Origin': '*'
        });
        res.end(data);
      });
    });

    server.listen(HTTP_PORT, () => {
      console.log(`[Static Server] Serving demo_video_player on http://localhost:${HTTP_PORT}`);
      resolve();
    });
  });
}

function launchHeadlessEdge() {
  const args = [
    '--headless=new',
    `--remote-debugging-port=${CDP_PORT}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-background-networking',
    '--disable-gpu',
    '--autoplay-policy=no-user-gesture-required',
    `--user-data-dir=${path.join(process.env.TEMP || 'C:\\temp', 'edge_stress_profile_' + Date.now())}`,
    `http://localhost:${HTTP_PORT}`
  ];

  edgeProc = spawn(EDGE_PATH, args, { stdio: 'ignore' });
  edgeProc.on('error', (err) => {
    console.error('Failed to spawn Edge:', err);
  });
}

async function connectCDP() {
  let wsUrl = null;
  for (let i = 0; i < 30; i++) {
    try {
      const res = await fetch(`http://localhost:${CDP_PORT}/json`);
      if (res.ok) {
        const pages = await res.json();
        const target = pages.find(p => p.type === 'page' && p.url.includes(String(HTTP_PORT)));
        if (target && target.webSocketDebuggerUrl) {
          wsUrl = target.webSocketDebuggerUrl;
          break;
        }
      }
    } catch (e) {}
    await sleep(250);
  }

  if (!wsUrl) throw new Error('Could not connect to Edge DevTools Protocol endpoint.');

  return new Promise((resolve, reject) => {
    ws = new WebSocket(wsUrl);
    ws.onopen = () => resolve();
    ws.onerror = (e) => reject(new Error('WebSocket connection error: ' + e.message));
    ws.onmessage = (raw) => {
      const data = JSON.parse(raw.data);
      if (data.id && pending.has(data.id)) {
        const { resolve, reject } = pending.get(data.id);
        pending.delete(data.id);
        if (data.error) reject(new Error(data.error.message));
        else resolve(data.result);
      } else if (data.method === 'Runtime.consoleAPICalled') {
        const type = data.params.type;
        const text = (data.params.args || []).map(a => a.value ?? a.description ?? '').join(' ');
        if (type === 'error') {
          consoleErrors.push(text);
        }
      } else if (data.method === 'Runtime.exceptionThrown') {
        const text = data.params.exceptionDetails?.text + ' ' + (data.params.exceptionDetails?.exception?.description || '');
        runtimeExceptions.push(text);
      }
    };
  });
}

function cdp(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function evalExpr(expression) {
  const safeWrapped = `(async function(){
    try {
      const __val = await (${expression});
      if (__val === undefined) return '__UNDEFINED__';
      return JSON.stringify(__val);
    } catch(err) {
      return JSON.stringify({ __eval_error: String(err && err.message ? err.message : err) });
    }
  })()`;

  const res = await cdp('Runtime.evaluate', {
    expression: safeWrapped,
    returnByValue: true,
    awaitPromise: true
  });

  if (res.exceptionDetails) {
    return { error: res.exceptionDetails.text };
  }
  const raw = res.result?.value;
  if (raw === '__UNDEFINED__') return { value: undefined };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.__eval_error) {
      return { error: parsed.__eval_error };
    }
    return { value: parsed };
  } catch {
    return { value: raw };
  }
}

async function runBrowserStress() {
  console.log('========================================================================');
  console.log(' CHALLENGER 1: REAL-BROWSER EDGE CDP EMPIRICAL STRESS HARNESS');
  console.log('========================================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(name, condition, extraInfo = '') {
    totalTests++;
    if (condition) {
      passedTests++;
      console.log(`  ✓ PASS: ${name} ${extraInfo ? '(' + extraInfo + ')' : ''}`);
    } else {
      console.error(`  ✗ FAIL: ${name} ${extraInfo ? '(' + extraInfo + ')' : ''}`);
      throw new Error(`Assertion failed: ${name}`);
    }
  }

  try {
    await startStaticServer();
    launchHeadlessEdge();
    await connectCDP();

    await cdp('Runtime.enable');
    await cdp('Page.enable');

    console.log('[Phase 1/7] Initializing Page & Verifying Hero Splash Dismissal...');
    await sleep(1500);

    // Click start presentation button to dismiss splash
    const dismissed = (await evalExpr(`(() => {
      const btn = document.getElementById('btn-start-pitch');
      if (btn) { btn.click(); return true; }
      return false;
    })()`)).value;
    assert('Hero start button clicked and presentation started', dismissed === true);
    await sleep(500);

    const isPlaying = (await evalExpr('window.PeoplePulsePlayer.timeline.isPlaying')).value;
    assert('Player is active and playing in live browser', isPlaying === true);

    // ------------------------------------------------------------------------
    // Stress 1: 200 Rapid Random Seeks in Live Edge Browser
    // ------------------------------------------------------------------------
    console.log('\n[Phase 2/7] Executing 200 Rapid Random Seeks in Live Edge Browser...');
    const seekResults = (await evalExpr(`(() => {
      const player = window.PeoplePulsePlayer;
      const timeline = player.timeline;
      let errors = 0;
      let clampedCount = 0;

      for (let i = 0; i < 200; i++) {
        const target = (Math.random() * 340.0) - 20.0;
        timeline.seek(target);

        if (timeline.currentTime < 0 || timeline.currentTime > 300) {
          errors++;
        }
        if (target < 0 && timeline.currentTime === 0) clampedCount++;
        if (target > 300 && timeline.currentTime === 300) clampedCount++;

        const stage = timeline.getStageForTime(timeline.currentTime);
        if (timeline.currentStageIndex !== stage.index) {
          errors++;
        }
      }
      return { errors, clampedCount, finalTime: timeline.currentTime, finalStage: timeline.currentStageIndex };
    })()`)).value;

    assert('200 random seeks completed with zero out-of-bound errors', seekResults.errors === 0, `errors: ${seekResults.errors}`);
    assert('Out-of-bounds seeks correctly clamped to 0s and 300s', seekResults.clampedCount > 10, `clamped: ${seekResults.clampedCount}`);

    // ------------------------------------------------------------------------
    // Stress 2: 100 Rapid Play/Pause Toggles in Live Browser
    // ------------------------------------------------------------------------
    console.log('\n[Phase 3/7] Executing 100 Rapid Play/Pause Toggles in Live Browser...');
    const toggleResults = (await evalExpr(`(() => {
      const player = window.PeoplePulsePlayer;
      const timeline = player.timeline;
      const playBtn = document.getElementById('btn-play-pause');
      let playIconErrors = 0;

      for (let i = 0; i < 100; i++) {
        playBtn.click();
        const playIcon = document.getElementById('icon-play');
        const pauseIcon = document.getElementById('icon-pause');

        if (timeline.isPlaying) {
          if (playIcon.style.display !== 'none' || pauseIcon.style.display !== 'inline-block') {
            playIconErrors++;
          }
        } else {
          if (playIcon.style.display !== 'inline-block' || pauseIcon.style.display !== 'none') {
            playIconErrors++;
          }
        }
      }
      return { playIconErrors, finalPlaying: timeline.isPlaying };
    })()`)).value;

    assert('100 rapid play/pause toggles updated play/pause icons with 0 errors', toggleResults.playIconErrors === 0);

    // ------------------------------------------------------------------------
    // Stress 3: Boundary Seeks (0.0s, 300.0s) & End Overlay Trigger
    // ------------------------------------------------------------------------
    console.log('\n[Phase 4/7] Testing Boundary Seeks (0.0s, 300.0s) & Finale Overlay...');
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(0.0)');
    const t0 = (await evalExpr('window.PeoplePulsePlayer.timeline.currentTime')).value;
    const stage0 = (await evalExpr('window.PeoplePulsePlayer.timeline.currentStageIndex')).value;
    assert('Seek to 0.0s sets currentTime to 0.0s', t0 === 0);
    assert('Seek to 0.0s sets stage to Stage 1 (Goal Context)', stage0 === 0);

    // Seek to 300.0s
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(300.0)');
    const t300 = (await evalExpr('window.PeoplePulsePlayer.timeline.currentTime')).value;
    const isComp = (await evalExpr('window.PeoplePulsePlayer.timeline.isCompleted')).value;
    const stage5 = (await evalExpr('window.PeoplePulsePlayer.timeline.currentStageIndex')).value;
    assert('Seek to 300.0s sets currentTime to 300.0s', t300 === 300);
    assert('Seek to 300.0s marks isCompleted true', isComp === true);
    assert('Seek to 300.0s stays in Stage 6 (Outcome & Governance)', stage5 === 5);

    // ------------------------------------------------------------------------
    // Stress 4: Speed Controls Toggling (1.0x, 1.25x, 1.5x)
    // ------------------------------------------------------------------------
    console.log('\n[Phase 5/7] Testing Live Speed Multiplier Toggling & Pitch Preservation...');
    const speedResults = (await evalExpr(`(() => {
      const player = window.PeoplePulsePlayer;
      const speedBtn = document.getElementById('btn-speed');
      const sequence = [];

      for (let i = 0; i < 6; i++) {
        speedBtn.click();
        sequence.push({
          speed: player.timeline.speed,
          btnText: speedBtn.textContent,
          audioRate: player.audio.audio ? player.audio.audio.playbackRate : 1.0,
          preservesPitch: player.audio.audio ? player.audio.audio.preservesPitch : true
        });
      }
      return sequence;
    })()`)).value;

    assert('Speed button cycles sequentially: 1.25x -> 1.5x -> 1.0x -> 1.25x -> 1.5x -> 1.0x',
      speedResults[0].speed === 1.25 &&
      speedResults[1].speed === 1.5 &&
      speedResults[2].speed === 1.0 &&
      speedResults[3].speed === 1.25,
      JSON.stringify(speedResults.map(s => s.speed))
    );
    assert('Audio element preserves pitch across all speed multiplier changes',
      speedResults.every(s => s.preservesPitch === true)
    );

    // ------------------------------------------------------------------------
    // Stress 5: Stage Jump Buttons & Drawer Breadcrumb Integrity in Live DOM
    // ------------------------------------------------------------------------
    console.log('\n[Phase 6/7] Testing Live DOM Stage Buttons & Rubric Crumbs...');
    const crumbChecks = (await evalExpr(`(() => {
      const stages = [1, 2, 3, 4, 5, 6];
      const results = [];

      for (const sId of stages) {
        const btn = document.querySelector(\`.stage-jump-btn[data-stage-id="\${sId}"]\`);
        if (btn) btn.click();

        const activeBtn = document.querySelector('.stage-jump-btn.active-stage-btn');
        const activeCrumb = document.querySelector('.rubric-crumb.active-crumb');
        const completedCrumbs = Array.from(document.querySelectorAll('.rubric-crumb.completed-crumb'))
          .map(c => parseInt(c.dataset.stageId, 10));

        results.push({
          sId,
          activeBtnId: activeBtn ? parseInt(activeBtn.dataset.stageId, 10) : null,
          activeCrumbId: activeCrumb ? parseInt(activeCrumb.dataset.stageId, 10) : null,
          completedCount: completedCrumbs.length,
          allCompletedPrior: completedCrumbs.every(id => id < sId)
        });
      }
      return results;
    })()`)).value;

    assert('All 6 stage buttons activated exact matching stage buttons',
      crumbChecks.every(c => c.activeBtnId === c.sId)
    );
    assert('All 6 stage buttons illuminated exact matching active rubric crumbs',
      crumbChecks.every(c => c.activeCrumbId === c.sId)
    );
    assert('Prior rubric crumbs are accurately marked completed without gaps',
      crumbChecks.every(c => c.completedCount === (c.sId - 1) && c.allCompletedPrior)
    );

    // ------------------------------------------------------------------------
    // Stress 6: Rapid Keyboard Shortcuts Stress
    // ------------------------------------------------------------------------
    console.log('\n[Phase 7/7] Dispatching Rapid Global Keyboard Shortcut Events...');
    const keyResults = (await evalExpr(`(() => {
      const timeline = window.PeoplePulsePlayer.timeline;
      timeline.seek(50.0);

      // Dispatch ArrowRight (seek +5s)
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'ArrowRight', bubbles: true }));
      const tAfterRight = timeline.currentTime;

      // Dispatch Shift+ArrowRight (seek +15s)
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'ArrowRight', shiftKey: true, bubbles: true }));
      const tAfterShiftRight = timeline.currentTime;

      // Dispatch ArrowLeft (seek -5s)
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'ArrowLeft', bubbles: true }));
      const tAfterLeft = timeline.currentTime;

      // Dispatch Space (toggle play)
      const prevPlay = timeline.isPlaying;
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space', bubbles: true }));
      const afterSpace = timeline.isPlaying;

      // Dispatch Digit5 (jump to Adaptation stage)
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Digit5', bubbles: true }));
      const stageAfterDigit5 = timeline.currentStageIndex;

      return {
        tAfterRight,
        tAfterShiftRight,
        tAfterLeft,
        spaceToggled: (prevPlay !== afterSpace),
        stageAfterDigit5
      };
    })()`)).value;

    assert('ArrowRight advances timeline by +5s (50s -> 55s)', keyResults.tAfterRight === 55.0);
    assert('Shift+ArrowRight advances timeline by +15s (55s -> 70s)', keyResults.tAfterShiftRight === 70.0);
    assert('ArrowLeft rewinds timeline by -5s (70s -> 65s)', keyResults.tAfterLeft === 65.0);
    assert('Space key toggles playback state', keyResults.spaceToggled === true);
    assert('Digit5 shortcut jumps directly to Stage 5 (Failure Adaptation)', keyResults.stageAfterDigit5 === 4);

    // Final check: console errors and runtime exceptions
    console.log('\n========================================================================');
    console.log(' BROWSER RUNTIME CONSOLE & EXCEPTION AUDIT');
    console.log('========================================================================');
    console.log(` Console Errors Detected:     ${consoleErrors.length}`);
    console.log(` Runtime Exceptions Thrown:   ${runtimeExceptions.length}`);

    if (consoleErrors.length > 0) {
      console.error('Console Errors:', consoleErrors);
    }
    if (runtimeExceptions.length > 0) {
      console.error('Runtime Exceptions:', runtimeExceptions);
    }

    assert('Browser console is 100% clean (zero console errors)', consoleErrors.length === 0);
    assert('Browser runtime is 100% clean (zero uncaught exceptions)', runtimeExceptions.length === 0);

    console.log('\n========================================================================');
    console.log(` REAL-BROWSER STRESS VERIFICATION: ${passedTests} / ${totalTests} TESTS PASSED (100%)`);
    console.log('========================================================================\n');

  } finally {
    if (ws) {
      try { ws.close(); } catch (e) {}
    }
    if (edgeProc) {
      try { edgeProc.kill(); } catch (e) {}
    }
    if (server) {
      try { server.close(); } catch (e) {}
    }
  }
}

runBrowserStress().catch(err => {
  console.error('Fatal Edge CDP error:', err);
  process.exit(1);
});
