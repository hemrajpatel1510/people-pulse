import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const ART_DIR = 'C:\\Users\\User\\.gemini\\antigravity\\brain\\b614a9e2-d8dc-4d78-acf2-d08de59eae0a';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CDP_PORT = 9227;
const HTTP_PORT = 8091;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

let server;
let edgeProc;
let ws;
let msgId = 0;
const pending = new Map();

function startStaticServer() {
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.vtt': 'text/vtt',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.png': 'image/png',
    '.svg': 'image/svg+xml'
  };

  return new Promise((resolve) => {
    server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent(req.url.split('?')[0]);
      if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
      const filePath = path.join(ROOT_DIR, reqPath);

      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end('Not Found');
          return;
        }
        const ext = path.extname(filePath);
        res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
        res.end(data);
      });
    });

    server.listen(HTTP_PORT, () => {
      resolve();
    });
  });
}

function launchHeadlessEdge() {
  const edgeArgs = [
    `--remote-debugging-port=${CDP_PORT}`,
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--window-size=1440,900',
    `--user-data-dir=${path.join(ROOT_DIR, '.edge-shot-profile')}`,
    `http://localhost:${HTTP_PORT}/index.html`
  ];
  edgeProc = spawn(EDGE_PATH, edgeArgs, { stdio: 'ignore' });
}

async function connectCDP() {
  const maxRetries = 25;
  for (let i = 0; i < maxRetries; i++) {
    try {
      const res = await fetch(`http://localhost:${CDP_PORT}/json/list`);
      const tabs = await res.json();
      const pageTab = tabs.find(t => t.type === 'page' && t.webSocketDebuggerUrl);
      if (pageTab) {
        ws = new WebSocket(pageTab.webSocketDebuggerUrl);
        await new Promise((resWs, rejWs) => {
          ws.onopen = resWs;
          ws.onerror = rejWs;
          ws.onmessage = (evt) => {
            const msg = JSON.parse(evt.data);
            if (msg.id && pending.has(msg.id)) {
              const { resolve, reject } = pending.get(msg.id);
              pending.delete(msg.id);
              if (msg.error) reject(new Error(msg.error.message));
              else resolve(msg.result);
            }
          };
        });
        return;
      }
    } catch (e) {
      await sleep(200);
    }
  }
  throw new Error('Could not connect to Edge CDP');
}

function cdp(method, params = {}) {
  const id = ++msgId;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function evalExpr(expr) {
  const res = await cdp('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  return res.result;
}

async function takeScreenshot(filename) {
  const res = await cdp('Page.captureScreenshot', { format: 'png' });
  const buf = Buffer.from(res.data, 'base64');
  const outPath = path.join(ART_DIR, filename);
  fs.writeFileSync(outPath, buf);
  console.log(`Saved screenshot: ${outPath}`);
}

async function run() {
  try {
    await startStaticServer();
    launchHeadlessEdge();
    await connectCDP();

    await cdp('Runtime.enable');
    await cdp('Page.enable');
    await sleep(2000);

    // Dismiss splash
    await evalExpr('document.getElementById("btn-start-pitch")?.click()');
    await sleep(500);

    // Shot 1: Stage 1 Dashboard
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(15.0)');
    await sleep(400);
    await takeScreenshot('player_stage1_dashboard.png');

    // Shot 2: Stage 3 Action & Drawer Open
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(100.0)');
    await sleep(400);
    await takeScreenshot('player_stage3_react.png');

    // Shot 3: Stage 5 Adaptation Hero Card
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(180.0)');
    await sleep(400);
    await takeScreenshot('player_stage5_adaptation.png');

    console.log('All screenshots captured successfully!');
  } finally {
    if (ws) ws.close();
    if (edgeProc) edgeProc.kill();
    if (server) server.close();
  }
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
