#!/usr/bin/env python3
"""
PeoplePulse Pitch Narration Generator (Edge-TTS + FFmpeg)
Generates:
  1. assets/audio/narration_full.mp3 (300.0 seconds exact master narration)
  2. assets/subtitles/subtitles.json (Sentence and token-level karaoke metadata)
  3. assets/subtitles/subtitles.vtt (Standard WebVTT subtitle track)
"""

import asyncio
import json
import math
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

# Voice model and default rate
VOICE = "en-US-ChristopherNeural"
RATE = "+0%"

# Empirical minimum speech rate boosts for dense sentences to conform within window
MIN_RATES = {
    "s1_4": 55,
    "s2_4": 105,
    "s2_5": 45,
    "s3_4": 35,
    "s3_6": 20,
    "s6_2": 30,
    "s6_3": 20,
    "s6_4": 40,
    "s6_5": 25,
}

SCRIPT_DATA = [
    # Stage 1: Goal Context (0:00 - 0:45)
    {
        "id": "s1_1",
        "stageId": 1,
        "stageName": "Goal Context",
        "stageClass": "s-goal",
        "start": 0.0,
        "target_end": 8.0,
        "text": "Respected judges, 76% of employees experience burnout before leadership even realizes there is a problem.",
        "key_terms": ["76%", "burnout", "leadership"]
    },
    {
        "id": "s1_2",
        "stageId": 1,
        "stageName": "Goal Context",
        "stageClass": "s-goal",
        "start": 8.0,
        "target_end": 22.0,
        "text": "Traditional enterprise survey tools—like annual 50-question reviews—fail because of survey fatigue and devastating time lag.",
        "key_terms": ["50-question", "survey fatigue", "time lag"]
    },
    {
        "id": "s1_3",
        "stageId": 1,
        "stageName": "Goal Context",
        "stageClass": "s-goal",
        "start": 22.0,
        "target_end": 30.0,
        "text": "By the time HR compiles quarterly reports, top talent has already resigned.",
        "key_terms": ["HR", "quarterly reports", "resigned"]
    },
    {
        "id": "s1_4",
        "stageId": 1,
        "stageName": "Goal Context",
        "stageClass": "s-goal",
        "start": 30.0,
        "target_end": 45.0,
        "text": "Enter PeoplePulse—the autonomous enterprise HR intelligence platform engineered for Tech Zephyr 4.0. We replace static surveys with 60-second daily micro-pulses, backed by PulseAgent: an autonomous AI agent that doesn’t just graph sentiment, but continuously reasons, diagnoses bottlenecks, and executes organizational interventions.",
        "key_terms": ["PeoplePulse", "Tech Zephyr 4.0", "60-second", "micro-pulses", "PulseAgent", "interventions"]
    },

    # Stage 2: Decision Framework (0:45 - 1:30)
    {
        "id": "s2_1",
        "stageId": 2,
        "stageName": "Decision Framework",
        "stageClass": "s-dec",
        "start": 45.0,
        "target_end": 54.0,
        "text": "Now, why is this an Agentic AI problem rather than a simple chatbot?",
        "key_terms": ["Agentic AI", "chatbot"]
    },
    {
        "id": "s2_2",
        "stageId": 2,
        "stageName": "Decision Framework",
        "stageClass": "s-dec",
        "start": 54.0,
        "target_end": 67.0,
        "text": "A chatbot merely summarizes text. It has no organizational memory, no schema-validated tools, and cannot take closed-loop actions.",
        "key_terms": ["summarizes", "organizational memory", "closed-loop actions"]
    },
    {
        "id": "s2_3",
        "stageId": 2,
        "stageName": "Decision Framework",
        "stageClass": "s-dec",
        "start": 67.0,
        "target_end": 79.0,
        "text": "PulseAgent operates on a genuine ReAct (Reason + Act) loop powered by Google Gemini 2.0 Flash Function Calling, backed by our Supabase PostgreSQL architecture.",
        "key_terms": ["PulseAgent", "ReAct", "Gemini 2.0 Flash", "Function Calling", "PostgreSQL"]
    },
    {
        "id": "s2_4",
        "stageId": 2,
        "stageName": "Decision Framework",
        "stageClass": "s-dec",
        "start": 79.0,
        "target_end": 85.0,
        "text": "As you can see on the top breadcrumb bar, our agent enforces the strict 6-stage rubric lifecycle: Goal, Decision, Action, Evaluation, Adaptation, and Outcome.",
        "key_terms": ["6-stage rubric", "Goal", "Decision", "Action", "Evaluation", "Adaptation", "Outcome"]
    },
    {
        "id": "s2_5",
        "stageId": 2,
        "stageName": "Decision Framework",
        "stageClass": "s-dec",
        "start": 85.0,
        "target_end": 90.0,
        "text": "Every tool call is governed through an active RBAC policy engine with strict multi-tenant isolation.",
        "key_terms": ["RBAC", "policy engine", "multi-tenant isolation"]
    },

    # Stage 3: Action (1:30 - 2:14 / 90s - 134s)
    {
        "id": "s3_1",
        "stageId": 3,
        "stageName": "Action Execution",
        "stageClass": "s-act",
        "start": 90.0,
        "target_end": 95.0,
        "text": "Let’s watch PulseAgent execute live.",
        "key_terms": ["PulseAgent", "execute live"]
    },
    {
        "id": "s3_2",
        "stageId": 3,
        "stageName": "Action Execution",
        "stageClass": "s-act",
        "start": 95.0,
        "target_end": 107.0,
        "text": "Stage 1: Goal Established. The objective is formulated: diagnose company-wide friction and deploy interventions.",
        "key_terms": ["Stage 1: Goal", "friction", "interventions"]
    },
    {
        "id": "s3_3",
        "stageId": 3,
        "stageName": "Action Execution",
        "stageClass": "s-act",
        "start": 107.0,
        "target_end": 121.0,
        "text": "Stage 2: Decision. Rather than guessing, the agent reasons over its tool registry and autonomously selects get_organization_metrics.",
        "key_terms": ["Stage 2: Decision", "tool registry", "get_organization_metrics"]
    },
    {
        "id": "s3_4",
        "stageId": 3,
        "stageName": "Action Execution",
        "stageClass": "s-act",
        "start": 121.0,
        "target_end": 134.0,
        "text": "Stage 3: Action. It queries our live Supabase database. Notice in the parameter payload that organization_id was automatically injected from the authenticated session—the LLM is never allowed to fabricate tenant boundaries.",
        "key_terms": ["Stage 3: Action", "Supabase", "organization_id", "server-injected", "tenant boundaries"]
    },

    # Stage 4: Evaluation (2:14 - 2:40 / 134s - 160s)
    {
        "id": "s3_5",
        "stageId": 4,
        "stageName": "Dynamic Evaluation",
        "stageClass": "s-eval",
        "start": 134.0,
        "target_end": 148.0,
        "text": "Observation: Live data returns: overall company engagement sits at 68%, but Customer Support shows a severe drop to 42% due to shift overload.",
        "key_terms": ["Observation", "68%", "Customer Support", "42%", "shift overload"]
    },
    {
        "id": "s3_6",
        "stageId": 4,
        "stageName": "Dynamic Evaluation",
        "stageClass": "s-eval",
        "start": 148.0,
        "target_end": 160.0,
        "text": "Stage 4: Evaluation. The agent parses the numerical observation. It calculates that Customer Support requires an immediate targeted pulse survey and a manager 1:1 action brief.",
        "key_terms": ["Stage 4: Evaluation", "numerical observation", "targeted pulse", "action brief"]
    },

    # Stage 5: Adaptation (2:40 - 3:45 / 160s - 225s)
    {
        "id": "s4_1",
        "stageId": 5,
        "stageName": "Failure Adaptation",
        "stageClass": "s-adapt",
        "start": 160.0,
        "target_end": 170.0,
        "text": "Now, pay close attention to Stage 5: Adaptation—our primary hackathon differentiator.",
        "key_terms": ["Stage 5: Adaptation", "differentiator"]
    },
    {
        "id": "s4_2",
        "stageId": 5,
        "stageName": "Failure Adaptation",
        "stageClass": "s-adapt",
        "start": 170.0,
        "target_end": 188.0,
        "text": "In real-world enterprise environments, external services fail. When PulseAgent attempts to broadcast an escalation alert to an external team webhook, it intercepts a real HTTP 503 service timeout.",
        "key_terms": ["external services", "HTTP 503", "service timeout"]
    },
    {
        "id": "s4_3",
        "stageId": 5,
        "stageName": "Failure Adaptation",
        "stageClass": "s-adapt",
        "start": 188.0,
        "target_end": 212.0,
        "text": "A standard script would crash or silently drop the notification. PulseAgent catches the network exception, evaluates the failure context, triggers a strategy adaptation event, and autonomously reroutes the escalation to our internal Supabase emergency dispatch queue.",
        "key_terms": ["crash", "catches", "adaptation event", "emergency dispatch queue"]
    },
    {
        "id": "s4_4",
        "stageId": 5,
        "stageName": "Failure Adaptation",
        "stageClass": "s-adapt",
        "start": 212.0,
        "target_end": 225.0,
        "text": "Zero message loss, zero human intervention, 100% self-healing resilience.",
        "key_terms": ["Zero message loss", "zero human intervention", "100% self-healing"]
    },

    # Stage 6: Outcome - Part A (3:45 - 4:25 / 225s - 265s)
    {
        "id": "s5_1",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 225.0,
        "target_end": 238.0,
        "text": "This brings us to Stage 6: Outcome. The agent synthesizes its discoveries, schedules the targeted questions into upcoming check-ins, and confirms execution.",
        "key_terms": ["Stage 6: Outcome", "synthesizes", "execution"]
    },
    {
        "id": "s5_2",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 238.0,
        "target_end": 251.0,
        "text": "For high-risk actions—like department-wide broadcast alerts—our Human-in-the-Loop engine presents an interactive confirmation modal before execution.",
        "key_terms": ["Human-in-the-Loop", "confirmation modal"]
    },
    {
        "id": "s5_3",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 251.0,
        "target_end": 265.0,
        "text": "Furthermore, every decision, tool invocation, and adaptation is sanitized by our credential redactor and permanently written to the immutable agent_activity_logs audit table for enterprise compliance.",
        "key_terms": ["sanitized", "credential redactor", "agent_activity_logs", "compliance"]
    },

    # Stage 6: Outcome - Part B Wrap-up (4:25 - 5:00 / 265s - 300s)
    {
        "id": "s6_1",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 265.0,
        "target_end": 268.0,
        "text": "Under the hood:",
        "key_terms": ["Under the hood"]
    },
    {
        "id": "s6_2",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 268.0,
        "target_end": 277.0,
        "text": "1. Zero Data Leaks: We enforce n ≥ 3 differential privacy directly in PostgreSQL, mathematically preventing individual de-anonymization.",
        "key_terms": ["n ≥ 3", "differential privacy", "PostgreSQL", "de-anonymization"]
    },
    {
        "id": "s6_3",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 277.0,
        "target_end": 284.0,
        "text": "2. Bulletproof Security: Row Level Security isolates every tenant, and DB triggers lock down billing columns.",
        "key_terms": ["Row Level Security", "RLS", "tenant isolation"]
    },
    {
        "id": "s6_4",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 284.0,
        "target_end": 291.0,
        "text": "3. Production Rigor: 23 passing unit tests and an offline fallback planner guarantee zero downtime during presentations.",
        "key_terms": ["23 passing unit tests", "offline fallback planner", "zero downtime"]
    },
    {
        "id": "s6_5",
        "stageId": 6,
        "stageName": "Outcome & Governance",
        "stageClass": "s-out",
        "start": 291.0,
        "target_end": 300.0,
        "text": "PeoplePulse doesn’t just watch company burnout happen—it empowers autonomous intelligence to fix it in real-time. Thank you, and we look forward to your questions!",
        "key_terms": ["PeoplePulse", "burnout", "autonomous intelligence", "Q&A"]
    }
]


def format_vtt_timestamp(seconds: float) -> str:
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int(round((seconds - int(seconds)) * 1000))
    return f"{hrs:02d}:{mins:02d}:{secs:02d}.{millis:03d}"


def update_presentation_data_js(presentation_js_path: Path, cues_data: list):
    content = presentation_js_path.read_text(encoding="utf-8")
    cues_json_str = json.dumps(cues_data, indent=4)
    indented_cues = "\n    // 27 Embedded Subtitle Cues with Token Timing for Standalone file:/// Mode\n    cues: " + cues_json_str.replace("\n", "\n    ")

    if "cues:" in content:
        pattern = re.compile(r'(?:\/\/[^\n]*\n\s*)?cues:\s*\[[\s\S]*?\](?=\s*\n\s*\};)', re.MULTILINE)
        new_content = pattern.sub(indented_cues.strip(), content)
    else:
        target = "    ]\n  };\n\n  root.PEOPLEPULSE_PRESENTATION_DATA"
        replacement = f"    ],{indented_cues}\n  }};\n\n  root.PEOPLEPULSE_PRESENTATION_DATA"
        new_content = content.replace(target, replacement)

    presentation_js_path.write_text(new_content, encoding="utf-8")
    print(f"Updated presentationData.js with {len(cues_data)} cues: {presentation_js_path}")


async def synthesize_all(output_mp3_path: Path, output_json_path: Path, output_vtt_path: Path, presentation_js_path: Path = None):
    import edge_tts

    print("Synthesizing speech segments via edge-tts with dynamic tempo conforming...")
    temp_dir = Path(tempfile.mkdtemp(prefix="pp_narration_"))

    segment_files = []
    cues_data = []

    for idx, item in enumerate(SCRIPT_DATA):
        seg_mp3 = temp_dir / f"seg_{idx:02d}.mp3"
        w_alloc = item["target_end"] - item["start"]
        words = item["text"].split()
        num_words = len(words)

        # Tier 1: Predictive Speech Rate Calculation
        est_dur = num_words * 0.55
        target_dur = w_alloc - 0.20
        calc_rate = int(math.ceil(((est_dur / target_dur) - 1.0) * 100)) if (target_dur > 0 and est_dur > target_dur) else 0
        rate_pct = max(calc_rate, MIN_RATES.get(item["id"], 0))
        clip_rate_str = f"+{rate_pct}%"

        print(f"[{idx+1}/{len(SCRIPT_DATA)}] Synthesizing {item['id']} ({item['start']}s -> {item['target_end']}s, window={w_alloc:.1f}s, rate={clip_rate_str})...")

        # Clean text of SSML artifacts if any
        clean_text = item["text"].replace("—", ", ").replace("–", ", ")
        communicate = edge_tts.Communicate(clean_text, voice=VOICE, rate=clip_rate_str)
        await communicate.save(str(seg_mp3))

        # Probe initial duration using ffprobe
        probe_cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(seg_mp3)
        ]
        dur_res = subprocess.run(probe_cmd, capture_output=True, text=True, check=True)
        actual_dur = float(dur_res.stdout.strip())
        print(f"   Initial synthesized duration: {actual_dur:.2f}s (window: {w_alloc:.2f}s)")

        # Tier 2: Deterministic FFmpeg atempo Conformance Guard
        # Clip MUST finish at least 100ms before window end: actual_dur <= w_alloc - 0.10s
        target_max_dur = w_alloc - 0.15  # Target 150ms buffer to safely guarantee >= 100ms margin
        if actual_dur > target_max_dur:
            tempo = actual_dur / target_max_dur
            print(f"   --> Conforming tempo via FFmpeg atempo={tempo:.4f}...")
            conformed_mp3 = temp_dir / f"seg_{idx:02d}_conformed.mp3"

            if tempo <= 2.0:
                filter_str = f"atempo={tempo:.4f}"
            else:
                filter_str = f"atempo=2.0,atempo={(tempo/2.0):.4f}"

            ffmpeg_cmd = [
                "ffmpeg", "-y", "-i", str(seg_mp3),
                "-filter:a", filter_str,
                "-b:a", "192k",
                str(conformed_mp3)
            ]
            subprocess.run(ffmpeg_cmd, capture_output=True, check=True)
            seg_mp3 = conformed_mp3

            dur_res = subprocess.run(probe_cmd, capture_output=True, text=True, check=True)
            actual_dur = float(dur_res.stdout.strip())
            print(f"   Conformed duration: {actual_dur:.2f}s (limit: {w_alloc - 0.10:.2f}s)")

        # Secondary strict safety check
        if actual_dur > (w_alloc - 0.10):
            tempo2 = actual_dur / (w_alloc - 0.15)
            conformed2_mp3 = temp_dir / f"seg_{idx:02d}_conformed2.mp3"
            ffmpeg_cmd = [
                "ffmpeg", "-y", "-i", str(seg_mp3),
                "-filter:a", f"atempo={tempo2:.4f}",
                "-b:a", "192k",
                str(conformed2_mp3)
            ]
            subprocess.run(ffmpeg_cmd, capture_output=True, check=True)
            seg_mp3 = conformed2_mp3
            dur_res = subprocess.run(probe_cmd, capture_output=True, text=True, check=True)
            actual_dur = float(dur_res.stdout.strip())
            print(f"   Secondary conformed duration: {actual_dur:.2f}s")

        assert actual_dur <= (w_alloc - 0.10), f"Error: {item['id']} duration {actual_dur} exceeds window {w_alloc - 0.10}"

        # Generate character-weighted proportional token boundaries
        char_lengths = [max(1, len(w)) for w in words]
        total_chars = sum(char_lengths)
        tokens = []
        w_curr = item["start"]

        for w, clen in zip(words, char_lengths):
            word_dur = actual_dur * (clen / total_chars)
            w_start = round(w_curr, 2)
            w_end = round(w_curr + word_dur, 2)

            if w_end <= w_start:
                w_end = round(w_start + 0.05, 2)

            if w_end > item["target_end"]:
                w_end = round(item["target_end"], 2)
                if w_start >= w_end:
                    w_start = round(max(item["start"], w_end - 0.05), 2)

            is_highlight = any(k.lower() in w.lower() for k in item.get("key_terms", []))
            tokens.append({
                "text": w,
                "start": w_start,
                "end": w_end,
                "highlight": is_highlight
            })
            w_curr += word_dur

        # Ensure strict monotonicity for every token
        for t in tokens:
            if t["end"] <= t["start"]:
                t["end"] = round(t["start"] + 0.05, 2)
            if t["end"] > item["target_end"]:
                t["end"] = round(item["target_end"], 2)
                if t["start"] >= t["end"]:
                    t["start"] = round(max(item["start"], t["end"] - 0.05), 2)

        cue_record = {
            "id": item["id"],
            "stageId": item["stageId"],
            "stageName": item["stageName"],
            "stageClass": item["stageClass"],
            "start": item["start"],
            "end": item["target_end"],
            "spokenDuration": round(actual_dur, 2),
            "text": item["text"],
            "tokens": tokens
        }
        cues_data.append(cue_record)
        segment_files.append((item["start"], seg_mp3, actual_dur))

    # Assemble master 300.0-second audio track using FFmpeg
    print("\nAssembling master 300.0s timeline with FFmpeg...")
    filter_parts = []
    inputs = ["-f", "lavfi", "-t", "300.0", "-i", "anullsrc=r=44100:cl=stereo"]
    mix_inputs = ["[0:a]"]

    for i, (start_sec, seg_path, _) in enumerate(segment_files):
        inputs.extend(["-i", str(seg_path)])
        delay_ms = int(round(start_sec * 1000))
        inp_idx = i + 1
        filter_parts.append(f"[{inp_idx}:a]adelay={delay_ms}|{delay_ms},volume=1.0[a{inp_idx}]")
        mix_inputs.append(f"[a{inp_idx}]")

    mix_str = "".join(mix_inputs) + f"amix=inputs={len(segment_files) + 1}:duration=first:dropout_transition=0[outa]"
    filter_parts.append(mix_str)
    full_filter = ";".join(filter_parts)

    output_mp3_path.parent.mkdir(parents=True, exist_ok=True)

    ffmpeg_cmd = [
        "ffmpeg", "-y", *inputs,
        "-filter_complex", full_filter,
        "-map", "[outa]",
        "-t", "300.0",
        "-b:a", "192k",
        str(output_mp3_path)
    ]
    subprocess.run(ffmpeg_cmd, check=True)
    print(f"Master audio narration successfully created: {output_mp3_path}")

    # Verify duration of output mp3
    probe_cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(output_mp3_path)
    ]
    master_dur = float(subprocess.run(probe_cmd, capture_output=True, text=True, check=True).stdout.strip())
    print(f"Verified output duration: {master_dur:.3f}s")

    # Save subtitles.json
    output_json_path.parent.mkdir(parents=True, exist_ok=True)
    subtitle_payload = {
        "version": "1.0",
        "totalDuration": 300.0,
        "stages": [
            {"id": 1, "name": "Goal Context", "start": 0.0, "end": 45.0, "class": "s-goal"},
            {"id": 2, "name": "Decision Framework", "start": 45.0, "end": 90.0, "class": "s-dec"},
            {"id": 3, "name": "Action Execution", "start": 90.0, "end": 134.0, "class": "s-act"},
            {"id": 4, "name": "Dynamic Evaluation", "start": 134.0, "end": 160.0, "class": "s-eval"},
            {"id": 5, "name": "Failure Adaptation", "start": 160.0, "end": 225.0, "class": "s-adapt"},
            {"id": 6, "name": "Outcome & Governance", "start": 225.0, "end": 300.0, "class": "s-out"}
        ],
        "cues": cues_data
    }
    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(subtitle_payload, f, indent=2)
    print(f"Saved JSON subtitles: {output_json_path}")

    # Save subtitles.vtt
    output_vtt_path.parent.mkdir(parents=True, exist_ok=True)
    vtt_lines = ["WEBVTT", "Kind: captions", "Language: en", ""]
    for cue in cues_data:
        vtt_lines.append(cue["id"])
        vtt_lines.append(f"{format_vtt_timestamp(cue['start'])} --> {format_vtt_timestamp(cue['end'])}")
        vtt_lines.append(cue["text"])
        vtt_lines.append("")

    with open(output_vtt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(vtt_lines))
    print(f"Saved WebVTT subtitles: {output_vtt_path}")

    # Embed cues directly into presentationData.js if path provided
    if presentation_js_path and presentation_js_path.exists():
        update_presentation_data_js(presentation_js_path, cues_data)

    # Cleanup temp directory
    for _, path, _ in segment_files:
        try:
            path.unlink()
        except Exception:
            pass
    for cf in temp_dir.glob("*.mp3"):
        try:
            cf.unlink()
        except Exception:
            pass
    try:
        temp_dir.rmdir()
    except Exception:
        pass


def main():
    root_dir = Path(__file__).resolve().parent.parent
    mp3_path = root_dir / "assets" / "audio" / "narration_full.mp3"
    json_path = root_dir / "assets" / "subtitles" / "subtitles.json"
    vtt_path = root_dir / "assets" / "subtitles" / "subtitles.vtt"
    presentation_js = root_dir / "js" / "presentationData.js"

    asyncio.run(synthesize_all(mp3_path, json_path, vtt_path, presentation_js))


if __name__ == "__main__":
    main()
