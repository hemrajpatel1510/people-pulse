#!/usr/bin/env node
/**
 * Challenger 2: Headless Edge CDP Interactive Stress Harness
 * Empirically stress-tests:
 *  1. Live-pause sandbox mode during Stage 5 Adaptation (t=160s-225s, HTTP 503 & Emergency Reroute)
 *  2. Drawer tab switching (react, audit, tools)
 *  3. Expand / collapse raw JSON technical schemas & payloads
 *  4. Postgres Audit Trail regex credential redaction
 *  5. HITL governance modal approval / denial / toast
 *  6. Playback resumption continuity and timeline preservation
 *  7. Console error & runtime exception purity
 */

import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CDP_PORT = 9339;
const HTTP_PORT = 8192;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

let server;
let edgeProc;
let ws;
let msgId = 0;
const pending = new Map();
const consoleErrors = [];
const runtimeExceptions = [];

function startStaticServer() {
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.vtt': 'text/vtt',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.png': 'image/png',
    '.svg': 'image/svg+xml'
  };

  return new Promise((resolve) => {
    server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent(req.url.split('?')[0]);
      if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
      const filePath = path.join(ROOT_DIR, reqPath);

      if (!fs.existsSync(filePath)) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found: ' + reqPath);
        return;
      }

      const stat = fs.statSync(filePath);
      const ext = path.extname(filePath).toLowerCase();
      const contentType = mimeTypes[ext] || 'application/octet-stream';
      const range = req.headers.range;

      // Full HTTP 206 Partial Content support for audio streaming & seeking
      if (range && (ext === '.mp3' || ext === '.wav')) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
        const chunksize = (end - start) + 1;
        const fileStream = fs.createReadStream(filePath, { start, end });

        res.writeHead(206, {
          'Content-Range': `bytes ${start}-${end}/${stat.size}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': contentType,
          'Access-Control-Allow-Origin': '*'
        });
        fileStream.pipe(res);
      } else {
        res.writeHead(200, {
          'Content-Length': stat.size,
          'Content-Type': contentType,
          'Accept-Ranges': 'bytes',
          'Access-Control-Allow-Origin': '*'
        });
        fs.createReadStream(filePath).pipe(res);
      }
    });

    server.listen(HTTP_PORT, () => {
      console.log(`[Static Server] Serving demo_video_player (with Range 206) on http://localhost:${HTTP_PORT}`);
      resolve();
    });
  });
}

function launchHeadlessEdge() {
  const args = [
    '--headless=new',
    `--remote-debugging-port=${CDP_PORT}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-background-networking',
    '--disable-gpu',
    '--autoplay-policy=no-user-gesture-required',
    `--user-data-dir=${path.join(process.env.TEMP || 'C:\\temp', 'edge_ch2_profile_' + Date.now())}`,
    `http://localhost:${HTTP_PORT}`
  ];

  edgeProc = spawn(EDGE_PATH, args, { stdio: 'ignore' });
  edgeProc.on('error', (err) => {
    console.error('Failed to spawn Edge:', err);
  });
}

async function connectCDP() {
  let wsUrl = null;
  for (let i = 0; i < 30; i++) {
    try {
      const res = await fetch(`http://localhost:${CDP_PORT}/json`);
      if (res.ok) {
        const pages = await res.json();
        const target = pages.find(p => p.type === 'page' && p.url.includes(String(HTTP_PORT)));
        if (target && target.webSocketDebuggerUrl) {
          wsUrl = target.webSocketDebuggerUrl;
          break;
        }
      }
    } catch (e) {}
    await sleep(250);
  }

  if (!wsUrl) throw new Error('Could not connect to Edge DevTools Protocol endpoint.');

  return new Promise((resolve, reject) => {
    ws = new WebSocket(wsUrl);
    ws.onopen = () => resolve();
    ws.onerror = (e) => reject(new Error('WebSocket connection error: ' + e.message));
    ws.onmessage = (raw) => {
      const data = JSON.parse(raw.data);
      if (data.id && pending.has(data.id)) {
        const { resolve, reject } = pending.get(data.id);
        pending.delete(data.id);
        if (data.error) reject(new Error(data.error.message));
        else resolve(data.result);
      } else if (data.method === 'Runtime.consoleAPICalled') {
        const type = data.params.type;
        const text = (data.params.args || []).map(a => a.value ?? a.description ?? '').join(' ');
        if (type === 'error') {
          consoleErrors.push(text);
        }
      } else if (data.method === 'Runtime.exceptionThrown') {
        const text = data.params.exceptionDetails?.text + ' ' + (data.params.exceptionDetails?.exception?.description || '');
        runtimeExceptions.push(text);
      }
    };
  });
}

function cdp(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function evalExpr(expression) {
  const safeWrapped = `(async function(){
    try {
      const __val = await (${expression});
      if (__val === undefined) return '__UNDEFINED__';
      return JSON.stringify(__val);
    } catch(err) {
      return JSON.stringify({ __eval_error: String(err && err.message ? err.message : err) });
    }
  })()`;

  const res = await cdp('Runtime.evaluate', {
    expression: safeWrapped,
    returnByValue: true,
    awaitPromise: true
  });

  if (res.exceptionDetails) {
    return { error: res.exceptionDetails.text };
  }
  const raw = res.result?.value;
  if (raw === '__UNDEFINED__') return { value: undefined };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.__eval_error) {
      return { error: parsed.__eval_error };
    }
    return { value: parsed };
  } catch {
    return { value: raw };
  }
}

async function runChallengerStress() {
  console.log('================================================================');
  console.log('  CHALLENGER 2: EDGE CDP INTERACTIVE LIVE-PAUSE STRESS SUITE     ');
  console.log('================================================================');

  let passed = 0;
  let total = 0;
  const criticalFindings = [];

  function check(name, condition, info = '') {
    total++;
    if (condition) {
      passed++;
      console.log(`  ✓ PASS: ${name} ${info ? '(' + info + ')' : ''}`);
    } else {
      console.error(`  ✗ FAIL: ${name} ${info ? '(' + info + ')' : ''}`);
      criticalFindings.push({ name, info });
    }
  }

  try {
    await startStaticServer();
    launchHeadlessEdge();
    await connectCDP();

    await cdp('Runtime.enable');
    await cdp('Page.enable');

    console.log('\n[Phase 1] Initialization & Hero Start...');
    await sleep(1500);

    const readyState = (await evalExpr('document.readyState')).value;
    check('Page loaded completely', readyState === 'complete');

    // Click hero start
    await evalExpr('document.getElementById("btn-start-pitch").click()');
    await sleep(600);

    const isPlayingInit = (await evalExpr('window.PeoplePulsePlayer.timeline.isPlaying')).value;
    check('Playback started successfully', isPlayingInit === true);

    // ========================================================================
    // [Phase 2] Stage 5 Adaptation Critical Live-Pause & Inspection
    // ========================================================================
    console.log('\n[Phase 2] Stage 5 Adaptation (HTTP 503 Failure) Live-Pause...');
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(175.0)');
    await sleep(400);

    // Pause player during HTTP 503 interception
    await evalExpr('window.PeoplePulsePlayer.timeline.pause()');
    await sleep(200);

    const isPaused503 = (await evalExpr('!window.PeoplePulsePlayer.timeline.isPlaying')).value;
    check('Player is paused at t=175.0s during HTTP 503 failure', isPaused503 === true);

    const sandboxActive = (await evalExpr('document.getElementById("sandbox-mode-indicator").classList.contains("visible")')).value;
    check('Sandbox mode indicator is unlocked and visible', sandboxActive === true);

    // Check Hero Card
    const heroCardExists = (await evalExpr('document.getElementById("card-ev_fail_1") !== null')).value;
    check('Hero HTTP 503 failure adaptation card is rendered', heroCardExists === true);

    const hasOrangeHeroClass = (await evalExpr('document.getElementById("card-ev_fail_1").classList.contains("card-adaptation-hero")')).value;
    check('Hero card has card-adaptation-hero class', hasOrangeHeroClass === true);

    const hasPulseOrangeBorder = (await evalExpr('document.getElementById("card-ev_fail_1").classList.contains("pulse-orange-border")')).value;
    check('Hero card has glowing pulse-orange-border class', hasPulseOrangeBorder === true);

    const triggerSnippet = (await evalExpr('document.querySelector("#card-ev_fail_1 .card-trigger-code")?.textContent || ""')).value;
    check('Trigger code specifies HTTP 503 failure and latency',
      triggerSnippet.includes('HTTP 503') && triggerSnippet.includes('1218ms'),
      triggerSnippet);

    const badgeText = (await evalExpr('document.querySelector("#card-ev_fail_1 .card-badge")?.textContent || ""')).value;
    check('Failure card displays SELF-CORRECTED badge', badgeText.includes('SELF-CORRECTED'), badgeText);

    // ========================================================================
    // [Phase 3] JSON Payload Inspector (Expand / Collapse / Syntax Validation)
    // ========================================================================
    console.log('\n[Phase 3] JSON Technical Schema & Payload Expansion...');
    const detailsExists = (await evalExpr('document.querySelector("#card-ev_fail_1 .card-payload-details") !== null')).value;
    check('JSON payload details element exists on failure card', detailsExists === true);

    // Click summary to expand
    await evalExpr('document.querySelector("#card-ev_fail_1 .card-payload-summary").click()');
    await sleep(150);

    const isDetailsOpen = (await evalExpr('document.querySelector("#card-ev_fail_1 .card-payload-details").open')).value;
    check('Clicking summary expands details (open = true)', isDetailsOpen === true);

    // Read and parse JSON content
    const jsonContent = (await evalExpr('document.querySelector("#card-ev_fail_1 .card-payload-json").textContent')).value;
    let parsedFailPayload = null;
    try {
      parsedFailPayload = JSON.parse(jsonContent);
    } catch (e) {}

    check('Payload text is valid JSON', parsedFailPayload !== null);
    check('Payload contains error_code: 503', parsedFailPayload?.error_code === 503);
    check('Payload contains adaptation_required: true', parsedFailPayload?.adaptation_required === true);
    check('Payload suggests send_emergency_notification fallback', parsedFailPayload?.suggested_fallback === 'send_emergency_notification');

    // Click summary again to collapse
    await evalExpr('document.querySelector("#card-ev_fail_1 .card-payload-summary").click()');
    await sleep(150);

    const isDetailsClosed = (await evalExpr('!document.querySelector("#card-ev_fail_1 .card-payload-details").open')).value;
    check('Clicking summary again collapses details (open = false)', isDetailsClosed === true);

    // ========================================================================
    // [Phase 4] Emergency Queue Reroute Verification at 205s
    // ========================================================================
    console.log('\n[Phase 4] Emergency Queue Reroute Action Card Inspection...');
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(205.0)');
    await sleep(350);

    const rerouteCardExists = (await evalExpr('document.getElementById("card-ev_act_2") !== null')).value;
    check('Emergency Queue Reroute card renders at 205s', rerouteCardExists === true);

    const rerouteBadge = (await evalExpr('document.querySelector("#card-ev_act_2 .card-badge")?.textContent || ""')).value;
    check('Reroute card displays DELIVERED badge', rerouteBadge.includes('DELIVERED'), rerouteBadge);

    const rerouteJson = (await evalExpr('document.querySelector("#card-ev_act_2 .card-payload-json")?.textContent || ""')).value;
    let parsedReroute = null;
    try {
      parsedReroute = JSON.parse(rerouteJson);
    } catch (e) {}

    check('Reroute JSON specifies emergency_in_app_queue channel', parsedReroute?.delivery_channel === 'emergency_in_app_queue');
    check('Reroute JSON specifies 0% message loss', parsedReroute?.message_loss === '0%');

    // ========================================================================
    // [Phase 5] Drawer Tabs Switching & Redaction Audit in Pause
    // ========================================================================
    console.log('\n[Phase 5] Drawer Tabs Switching & Credential Redaction Audit...');
    // Click Audit Trail tab
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"audit\\"]").click()');
    await sleep(200);

    const activeTab1 = (await evalExpr('window.PeoplePulsePlayer.simulator.activeTab')).value;
    check('Simulator activeTab is audit', activeTab1 === 'audit');

    const auditPaneActive = (await evalExpr('document.getElementById("tab-pane-audit").classList.contains("active-pane")')).value;
    check('Audit tab pane has active-pane class', auditPaneActive === true);

    const auditRowCount = (await evalExpr('document.querySelectorAll("#audit-table-body tr").length')).value;
    check('Audit table renders at least 5 audit log rows', auditRowCount >= 5, `${auditRowCount} rows`);

    // Extract all audit cell texts for regex redaction scan
    const auditData = (await evalExpr('Array.from(document.querySelectorAll("#audit-table-body tr")).map(r => r.innerText)')).value;
    const credentialPatterns = [
      { name: 'Google API Key', regex: 'AIza[0-9A-Za-z-_]{35}' },
      { name: 'OpenAI Secret Key', regex: 'sk-[a-zA-Z0-9]{20,}' },
      { name: 'Raw Bearer Token', regex: 'Bearer\\s+eyJ' },
      { name: 'Unmasked UUID Token', regex: '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' }
    ];

    let leakedSecret = null;
    for (const rowText of auditData) {
      for (const pat of credentialPatterns) {
        if (new RegExp(pat.regex, 'i').test(rowText)) {
          leakedSecret = `${pat.name} matched in row: ${rowText}`;
        }
      }
    }

    check('Zero leaked credentials found in audit trail cells', leakedSecret === null, leakedSecret || 'all sanitized');

    const hasRedactionMasks = (await evalExpr('(() => {' +
      'const h = document.getElementById("audit-table-body").innerHTML;' +
      'return h.includes("[INJECTED]") && h.includes("[MASKED]") && h.includes("[REDACTED]");' +
    '})()')).value;
    check('Sanitization placeholders [INJECTED], [MASKED], and [REDACTED] present', hasRedactionMasks === true);

    // Click Tools tab
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"tools\\"]").click()');
    await sleep(200);

    const activeTab2 = (await evalExpr('window.PeoplePulsePlayer.simulator.activeTab')).value;
    check('Simulator activeTab is tools', activeTab2 === 'tools');

    const toolCardsCount = (await evalExpr('document.querySelectorAll("#tools-registry-list .tool-card").length')).value;
    check('Tools registry renders exactly 7 registered tools', toolCardsCount === 7, `${toolCardsCount} tools`);

    // Click back to ReAct tab
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"react\\"]").click()');
    await sleep(200);

    const activeTab3 = (await evalExpr('window.PeoplePulsePlayer.simulator.activeTab')).value;
    check('Simulator activeTab restored to react', activeTab3 === 'react');

    // Drawer toggle test
    await evalExpr('document.getElementById("close-drawer-btn").click()');
    await sleep(150);
    const isClosed = (await evalExpr('!document.getElementById("pulseagent-drawer").classList.contains("drawer-visible")')).value;
    check('Drawer closes upon clicking close button', isClosed === true);

    await evalExpr('document.getElementById("floating-copilot-btn").click()');
    await sleep(150);
    const isReopened = (await evalExpr('document.getElementById("pulseagent-drawer").classList.contains("drawer-visible")')).value;
    check('Drawer re-opens upon clicking floating copilot button', isReopened === true);

    // ========================================================================
    // [Phase 6] Human-In-The-Loop Modal & Playback Resumption
    // ========================================================================
    console.log('\n[Phase 6] Human-In-The-Loop Governance Modal & Resumption...');
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(245.0)');
    await sleep(400);

    const hitlVisible = (await evalExpr('document.getElementById("hitl-confirmation-modal").classList.contains("modal-visible")')).value;
    check('HITL modal is displayed at t=245.0s', hitlVisible === true);

    // Click Approve Action
    await evalExpr('document.getElementById("hitl-approve-btn").click()');
    await sleep(200);

    const hitlDismissed = (await evalExpr('!document.getElementById("hitl-confirmation-modal").classList.contains("modal-visible")')).value;
    check('Clicking Approve Action dismisses HITL modal', hitlDismissed === true);

    const toastVisible = (await evalExpr('document.getElementById("player-toast")?.classList.contains("toast-show") || false')).value;
    check('Action APPROVED confirmation toast is displayed', toastVisible === true);

    // ========================================================================
    // [Phase 7] Resumption Timeline Integrity & Clock Preservation
    // ========================================================================
    console.log('\n[Phase 7] Timeline Resumption Continuity Verification...');
    // Resume playback from pause at 180s
    await evalExpr('window.PeoplePulsePlayer.timeline.seek(180.0)');
    await sleep(400);
    await evalExpr('window.PeoplePulsePlayer.timeline.pause()');
    await sleep(200);

    const timeAtPause = (await evalExpr('window.PeoplePulsePlayer.timeline.currentTime')).value;
    check('Player paused at 180s', Math.abs(timeAtPause - 180.0) < 0.5, `${timeAtPause}s`);

    // Perform intensive tab toggling while paused
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"audit\\"]").click()');
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"tools\\"]").click()');
    await evalExpr('document.querySelector(".agent-tab-btn[data-tab=\\"react\\"]").click()');

    // Resume playback
    await evalExpr('window.PeoplePulsePlayer.timeline.play()');
    await sleep(1200);

    const isPlayingAfterResume = (await evalExpr('window.PeoplePulsePlayer.timeline.isPlaying')).value;
    check('Player is playing after resumption', isPlayingAfterResume === true);

    const timeAfterResume = (await evalExpr('window.PeoplePulsePlayer.timeline.currentTime')).value;
    check('Timeline advanced monotonically without backward jump or reset',
      timeAfterResume > 180.5 && timeAfterResume < 185.0,
      `${timeAfterResume.toFixed(2)}s`);

    const stageAfterResume = (await evalExpr('window.PeoplePulsePlayer.timeline.currentStageIndex + 1')).value;
    check('Active stage remains Stage 5 (Adaptation)', stageAfterResume === 5, `stage: ${stageAfterResume}`);

    const cardCountIntact = (await evalExpr('document.querySelectorAll("#agent-event-stream .event-card").length')).value;
    check('Event stream is intact with all chronological cards', cardCountIntact >= 5, `${cardCountIntact} cards`);

    // Check console error and unhandled exception purity
    check('Browser console contains ZERO errors', consoleErrors.length === 0, consoleErrors.join('; '));
    check('Page threw ZERO runtime exceptions', runtimeExceptions.length === 0, runtimeExceptions.join('; '));

    console.log('\n================================================================');
    console.log(`  CHALLENGER 2 SUMMARY: ${passed} / ${total} CHECKS PASSED (${Math.round((passed / total) * 100)}%)`);
    console.log('================================================================\n');

    if (criticalFindings.length > 0) {
      console.error('Failure Details:');
      criticalFindings.forEach(f => console.error(`  - ${f.name}: ${f.info}`));
      process.exitCode = 1;
    } else {
      process.exitCode = 0;
    }
  } catch (err) {
    console.error('\nChallenger run error:', err);
    process.exitCode = 1;
  } finally {
    if (ws) ws.close();
    if (edgeProc) edgeProc.kill();
    if (server) server.close();
  }
}

runChallengerStress();
