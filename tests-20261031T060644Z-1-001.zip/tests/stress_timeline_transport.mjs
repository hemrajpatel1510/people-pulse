// Empirical Stress Testing Suite for Presentation Player Timeline & Transport Engine
// Challenger 1: Timeline & Transport Stress Verifier
// Tests Suites 1-6: High-frequency random seeking, play/pause toggling, boundary seeks,
// speed cycling, clock drift measurement over prolonged cycles, and DOM stage breadcrumbs.

import path from 'node:path';
import fs from 'node:fs';
import {
  assert,
  assertEqual,
  assertApprox,
  createMockEnvironment,
  loadPlayerModule,
  MockElement,
  PLAYER_ROOT
} from './harness.mjs';

// Polyfill ChildNode.remove on MockElement if missing to match standard DOM Level 4
if (!MockElement.prototype.remove) {
  MockElement.prototype.remove = function() {
    if (this.parentElement && typeof this.parentElement.removeChild === 'function') {
      this.parentElement.removeChild(this);
    }
  };
}

export async function runTimelineTransportStressTests() {
  console.log('========================================================================');
  console.log(' CHALLENGER 1: TIMELINE & TRANSPORT EMPIRICAL STRESS TEST HARNESS');
  console.log('========================================================================\n');

  const results = [];
  let totalAssertions = 0;

  async function testCase(name, fn) {
    const start = Date.now();
    try {
      const assertions = await fn();
      const elapsed = Date.now() - start;
      const assertCount = assertions || 1;
      totalAssertions += assertCount;
      console.log(`  ✓ PASS [${elapsed}ms | ${assertCount} assertions]: ${name}`);
      results.push({ name, passed: true, elapsed, assertCount });
    } catch (err) {
      const elapsed = Date.now() - start;
      console.error(`  ✗ FAIL [${elapsed}ms]: ${name}`);
      console.error(`    Error: ${err.message}\n    Stack: ${err.stack}`);
      results.push({ name, passed: false, elapsed, error: err.message });
    }
  }

  // Helper to boot fully wired environment
  async function bootApp(options = {}) {
    const env = createMockEnvironment();
    // Ensure remove() exists on any instantiated MockElement
    if (!env.window.HTMLElement.prototype.remove) {
      env.window.HTMLElement.prototype.remove = function() {
        if (this.parentElement) this.parentElement.removeChild(this);
      };
    }

    const dataMod = await loadPlayerModule('js/presentationData.js', env);
    const audioMod = await loadPlayerModule('js/audioManager.js', env);
    const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
    const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
    const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
    const interMod = await loadPlayerModule('js/interactiveController.js', env);

    const AudioManager = audioMod?.AudioManager || env.window.AudioManager;
    const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
    const SceneSimulator = sceneMod?.SceneSimulator || env.window.SceneSimulator;
    const SubtitleRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
    const InteractiveController = interMod?.InteractiveController || env.window.InteractiveController;

    let audioManager = null;
    if (options.withAudio !== false) {
      audioManager = new AudioManager();
    }

    const timeline = new TimelineEngine({
      duration: 300.0,
      audioManager: audioManager
    });

    return {
      env,
      timeline,
      audioManager,
      TimelineEngine,
      AudioManager,
      SceneSimulator,
      SubtitleRenderer,
      InteractiveController,
      data: env.window.PEOPLEPULSE_PRESENTATION_DATA
    };
  }

  // --------------------------------------------------------------------------
  // SUITE 1: High-Frequency Random Seeking Stress (10,000 operations)
  // --------------------------------------------------------------------------
  console.log('▶ [Suite 1/6] High-Frequency Random Seeking Stress (10,000 operations)...');

  await testCase('S1.1: 10,000 random seeks across [-10s, 310s] maintain clamping and valid stage bounds', async () => {
    const { timeline, audioManager } = await bootApp();
    const ITERATIONS = 10000;
    let assertions = 0;

    for (let i = 0; i < ITERATIONS; i++) {
      // Uniform random seek including out-of-bounds negative and overflow
      const targetSec = (Math.random() * 320.0) - 10.0;
      timeline.seek(targetSec);

      // Invariants:
      // 1. Clamped strictly to [0.0, 300.0]
      assert(timeline.currentTime >= 0.0, `currentTime ${timeline.currentTime} must be >= 0.0`);
      assert(timeline.currentTime <= 300.0, `currentTime ${timeline.currentTime} must be <= 300.0`);
      assert(!isNaN(timeline.currentTime), `currentTime must not be NaN`);
      assert(isFinite(timeline.currentTime), `currentTime must be finite`);

      // 2. Stage mapping consistency
      const stageInfo = timeline.getStageForTime(timeline.currentTime);
      assertEqual(timeline.currentStageIndex, stageInfo.index, `currentStageIndex mismatch at t=${timeline.currentTime}`);

      // 3. Stage boundary mathematical integrity
      const s = stageInfo.stage;
      assert(timeline.currentTime >= s.start, `t=${timeline.currentTime} must be >= stage.start=${s.start}`);
      if (stageInfo.index < 5) {
        assert(timeline.currentTime < s.end, `t=${timeline.currentTime} must be < stage.end=${s.end}`);
      } else {
        assert(timeline.currentTime <= s.end, `t=${timeline.currentTime} must be <= stage.end=${s.end} for final stage`);
      }

      // 4. Audio manager sync
      assertEqual(audioManager.audio.currentTime, timeline.currentTime, `Audio currentTime must match timeline`);

      // 5. Completion flag
      if (timeline.currentTime >= 300.0) {
        assertEqual(timeline.isCompleted, true, `isCompleted must be true at 300s`);
      } else {
        assertEqual(timeline.isCompleted, false, `isCompleted must be false before 300s`);
      }

      assertions += 6;
    }

    return assertions;
  });

  await testCase('S1.2: Alternating extreme seeks (0s <-> 300s <-> 150s) 1,000 times without desync', async () => {
    const { timeline, audioManager } = await bootApp();
    const extrema = [0.0, 300.0, 0.0001, 299.9999, 150.0, 45.0, 225.0];
    let assertions = 0;

    for (let i = 0; i < 1000; i++) {
      const target = extrema[i % extrema.length];
      timeline.seek(target);
      assertEqual(timeline.currentTime, target, `Extreme seek to ${target}`);
      assertEqual(audioManager.audio.currentTime, target, `Audio sync at extreme target`);
      assertions += 2;
    }
    return assertions;
  });

  await testCase('S1.3: Micro-seeking stress (±0.001s floating deltas over 2,000 steps)', async () => {
    const { timeline } = await bootApp();
    timeline.seek(100.0);
    let assertions = 0;

    for (let i = 0; i < 2000; i++) {
      const delta = (Math.random() - 0.5) * 0.002;
      const nextTime = timeline.currentTime + delta;
      timeline.seek(nextTime);
      assert(!isNaN(timeline.currentTime), `Micro-seek produced NaN`);
      assert(timeline.currentTime >= 0 && timeline.currentTime <= 300, `Micro-seek out of bounds`);
      assertions += 2;
    }
    return assertions;
  });

  // --------------------------------------------------------------------------
  // SUITE 2: Rapid Play / Pause & State Machine Invariants (5,000 operations)
  // --------------------------------------------------------------------------
  console.log('\n▶ [Suite 2/6] Rapid Play / Pause & State Machine Invariants (5,000 operations)...');

  await testCase('S2.1: 5,000 rapid togglePlay() and play/pause calls maintain RAF loop integrity', async () => {
    const { timeline, audioManager, env } = await bootApp();
    let assertions = 0;
    let stateChanges = 0;
    timeline.onStateChange(() => { stateChanges++; });

    for (let i = 0; i < 5000; i++) {
      const action = i % 3;
      if (action === 0) timeline.togglePlay();
      else if (action === 1) timeline.play();
      else timeline.pause();

      // State machine invariant:
      if (timeline.isPlaying) {
        assert(timeline.rafId !== null, `RAF ID must be active when isPlaying is true`);
        assertEqual(audioManager.audio.paused, false, `Audio must not be paused when playing`);
      } else {
        assertEqual(timeline.rafId, null, `RAF ID must be null when isPlaying is false`);
        assertEqual(audioManager.audio.paused, true, `Audio must be paused when not playing`);
      }

      // Step frames occasionally and advance simulated audio alongside
      if (i % 10 === 0 && timeline.isPlaying) {
        audioManager.audio.currentTime += 0.01667;
        env.window.stepFrames(1, 16.67);
      }
      assertions += 2;
    }

    assert(stateChanges > 1000, `State change listener must have fired (got ${stateChanges})`);
    assertions += 1;
    return assertions;
  });

  await testCase('S2.2: Interleaved play, seek, pause, seek under active RAF clock cycles', async () => {
    const { timeline, audioManager, env } = await bootApp();
    let assertions = 0;

    for (let i = 0; i < 500; i++) {
      timeline.play();
      audioManager.audio.currentTime = timeline.currentTime;
      env.window.stepFrames(2, 16.67);
      const preSeek = timeline.currentTime;
      assert(preSeek >= 0, `Clock must be valid`);

      const randTime = Math.random() * 250;
      timeline.seek(randTime);
      audioManager.audio.currentTime = timeline.currentTime;
      assertEqual(timeline.isPlaying, true, `Seeking while playing must preserve isPlaying state`);

      env.window.stepFrames(2, 16.67);
      timeline.pause();
      assertEqual(timeline.isPlaying, false, `Pause must set isPlaying false`);

      const pausedTime = timeline.currentTime;
      env.window.stepFrames(5, 16.67);
      assertEqual(timeline.currentTime, pausedTime, `Clock must not advance while paused`);

      assertions += 4;
    }
    return assertions;
  });

  await testCase('S2.3: Replay invariant: Calling play() when isCompleted=true rewinds to 0.0s', async () => {
    const { timeline } = await bootApp();
    let assertions = 0;

    for (let i = 0; i < 50; i++) {
      timeline.seek(300.0);
      assertEqual(timeline.isCompleted, true, `Must be completed at 300s`);
      assertEqual(timeline.currentTime, 300.0, `Current time must be 300s`);

      timeline.play();
      assertEqual(timeline.currentTime, 0.0, `play() when completed must auto-rewind to 0.0s`);
      assertEqual(timeline.isCompleted, false, `isCompleted must reset to false upon replay`);
      assertEqual(timeline.isPlaying, true, `Player must be playing upon replay`);

      timeline.pause();
      assertions += 5;
    }
    return assertions;
  });

  // --------------------------------------------------------------------------
  // SUITE 3: Boundary Seeking & Adversarial Input Stress
  // --------------------------------------------------------------------------
  console.log('\n▶ [Suite 3/6] Boundary Seeking & Adversarial Input Stress...');

  await testCase('S3.1: Exact stage boundary checks [0, 45, 90, 134, 160, 225, 300]', async () => {
    const { timeline } = await bootApp();
    const boundaries = [
      { t: 0.0, expectedIdx: 0, name: 'Goal Context' },
      { t: 45.0, expectedIdx: 1, name: 'Decision Framework' },
      { t: 90.0, expectedIdx: 2, name: 'Action Execution' },
      { t: 134.0, expectedIdx: 3, name: 'Dynamic Evaluation' },
      { t: 160.0, expectedIdx: 4, name: 'Failure Adaptation' },
      { t: 225.0, expectedIdx: 5, name: 'Outcome & Governance' },
      { t: 300.0, expectedIdx: 5, name: 'Outcome & Governance' }
    ];

    let assertions = 0;
    for (const b of boundaries) {
      timeline.seek(b.t);
      assertEqual(timeline.currentStageIndex, b.expectedIdx, `Stage index at boundary ${b.t}s`);
      const stage = timeline.stages[timeline.currentStageIndex];
      assertEqual(stage.name, b.name, `Stage name at boundary ${b.t}s`);
      assertions += 2;
    }
    return assertions;
  });

  await testCase('S3.2: Epsilon boundary transitions (t ± 1e-6s)', async () => {
    const { timeline } = await bootApp();
    const tests = [
      { t: 45.0 - 1e-6, expectedIdx: 0 },
      { t: 45.0 + 1e-6, expectedIdx: 1 },
      { t: 90.0 - 1e-6, expectedIdx: 1 },
      { t: 90.0 + 1e-6, expectedIdx: 2 },
      { t: 134.0 - 1e-6, expectedIdx: 2 },
      { t: 134.0 + 1e-6, expectedIdx: 3 },
      { t: 160.0 - 1e-6, expectedIdx: 3 },
      { t: 160.0 + 1e-6, expectedIdx: 4 },
      { t: 225.0 - 1e-6, expectedIdx: 4 },
      { t: 225.0 + 1e-6, expectedIdx: 5 },
      { t: 300.0 - 1e-6, expectedIdx: 5 }
    ];

    let assertions = 0;
    for (const item of tests) {
      timeline.seek(item.t);
      assertEqual(timeline.currentStageIndex, item.expectedIdx, `Epsilon boundary at t=${item.t}`);
      assertions++;
    }
    return assertions;
  });

  await testCase('S3.3: Adversarial input clamping (-Infinity, +Infinity, strings, null)', async () => {
    const { timeline } = await bootApp();
    let assertions = 0;

    timeline.seek(-Infinity);
    assertEqual(timeline.currentTime, 0.0, `-Infinity seek must clamp to 0.0s`);

    timeline.seek(Infinity);
    assertEqual(timeline.currentTime, 300.0, `+Infinity seek must clamp to 300.0s`);

    timeline.seek("150.5");
    assertEqual(timeline.currentTime, 150.5, `Numeric string seek "150.5" resolves to 150.5s`);

    timeline.seek(null);
    assertEqual(timeline.currentTime, 0.0, `null seek resolves to 0.0s`);

    assertions += 4;
    return assertions;
  });

  await testCase('S3.4: Frame-stepping naturally across 300.0s end boundary stops clock cleanly', async () => {
    const { timeline, env } = await bootApp({ withAudio: false });
    let completedFired = false;
    timeline.onStateChange(({ state }) => {
      if (state === 'COMPLETED') completedFired = true;
    });

    timeline.seek(299.95);
    timeline.play();

    // Step 10 frames @ 16.67ms (~166.7ms, enough to cross 300.0s in synthetic mode)
    env.window.stepFrames(10, 16.67);

    assertEqual(timeline.currentTime, 300.0, `currentTime must halt exactly at 300.0s`);
    assertEqual(timeline.isPlaying, false, `isPlaying must become false at completion`);
    assertEqual(timeline.isCompleted, true, `isCompleted must become true at completion`);
    assertEqual(completedFired, true, `COMPLETED state change event must fire`);
    assertEqual(timeline.rafId, null, `RAF loop must be stopped`);

    // Step 50 more frames to ensure zero overshoot
    env.window.stepFrames(50, 16.67);
    assertEqual(timeline.currentTime, 300.0, `Clock must not overshoot 300.0s upon further stepping`);

    return 6;
  });

  // --------------------------------------------------------------------------
  // SUITE 4: Playback Speed Toggling & Rate Scaling (3,000 cycles)
  // --------------------------------------------------------------------------
  console.log('\n▶ [Suite 4/6] Playback Speed Toggling & Rate Scaling (3,000 cycles)...');

  await testCase('S4.1: cycleSpeed() cycles [1.0 -> 1.25 -> 1.5 -> 1.0] across 3,000 cycles', async () => {
    const { timeline, audioManager } = await bootApp();
    let assertions = 0;

    for (let i = 0; i < 3000; i++) {
      const expected = [1.25, 1.5, 1.0][i % 3];
      const newSpeed = timeline.cycleSpeed();
      assertEqual(newSpeed, expected, `cycleSpeed cycle ${i}`);
      assertEqual(timeline.speed, expected, `timeline.speed match`);
      assertEqual(audioManager.rate, expected, `audioManager.rate match`);
      assertEqual(audioManager.audio.playbackRate, expected, `audio.playbackRate match`);
      assertions += 4;
    }
    return assertions;
  });

  await testCase('S4.2: Invalid speed inputs gracefully fallback to 1.0x', async () => {
    const { timeline, audioManager } = await bootApp();
    const invalidSpeeds = [-2, 0, 0.5, 2.0, 3.0, NaN, 'fast', null, undefined, {}];
    let assertions = 0;

    for (const inv of invalidSpeeds) {
      timeline.setSpeed(inv);
      assertEqual(timeline.speed, 1.0, `Invalid speed ${inv} must default to 1.0x`);
      assertEqual(audioManager.rate, 1.0, `Audio manager rate must default to 1.0x`);
      assertions += 2;
    }
    return assertions;
  });

  await testCase('S4.3: Empirical rate progression verification in pure synthetic clock mode (1.0x, 1.25x, 1.5x)', async () => {
    const { timeline, env } = await bootApp({ withAudio: false });
    let assertions = 0;

    // Test at 1.0x: 60 frames of 16.66667ms (1.000s real time) -> 1.000s timeline advance
    timeline.seek(10.0);
    timeline.setSpeed(1.0);
    timeline.play();
    env.window.stepFrames(60, 1000.0 / 60.0);
    timeline.pause();
    assertApprox(timeline.currentTime, 11.0, 0.005, '1.0x speed advances 1.0s in 60 frames');
    assertions++;

    // Test at 1.25x: 60 frames of 16.66667ms (1.000s real time) -> 1.250s timeline advance
    timeline.seek(20.0);
    timeline.setSpeed(1.25);
    timeline.play();
    env.window.stepFrames(60, 1000.0 / 60.0);
    timeline.pause();
    assertApprox(timeline.currentTime, 21.25, 0.005, '1.25x speed advances 1.25s in 60 frames');
    assertions++;

    // Test at 1.5x: 60 frames of 16.66667ms (1.000s real time) -> 1.500s timeline advance
    timeline.seek(30.0);
    timeline.setSpeed(1.5);
    timeline.play();
    env.window.stepFrames(60, 1000.0 / 60.0);
    timeline.pause();
    assertApprox(timeline.currentTime, 31.50, 0.005, '1.5x speed advances 1.50s in 60 frames');
    assertions++;

    return assertions;
  });

  // --------------------------------------------------------------------------
  // SUITE 5: Clock Drift Measurement over Prolonged Simulation Cycles
  // --------------------------------------------------------------------------
  console.log('\n▶ [Suite 5/6] Clock Drift Measurement over Prolonged Simulation Cycles...');

  await testCase('S5.1: Prolonged Synthetic Clock: 300.0s run (18,000 RAF frames @ 60fps) drift < 0.001s', async () => {
    // Run in pure synthetic mode without attached static audio element
    const { timeline, env } = await bootApp({ withAudio: false });
    timeline.seek(0.0);
    timeline.play();

    const TOTAL_FRAMES = 18000;
    const FRAME_DELTA_MS = 1000.0 / 60.0; // 16.66666667ms

    // Step in blocks of 600 frames (10 seconds each)
    let maxDrift = 0;
    for (let block = 0; block < 30; block++) {
      env.window.stepFrames(600, FRAME_DELTA_MS);
      const expectedTime = Math.min(300.0, (block + 1) * 10.0);
      const drift = Math.abs(timeline.currentTime - expectedTime);
      if (drift > maxDrift) maxDrift = drift;
    }

    console.log(`      Synthetic Clock 18,000 Frames Max Drift: ${(maxDrift * 1000).toFixed(4)}ms`);
    assert(maxDrift < 0.0167, `Max drift ${maxDrift}s must be < 1 frame (16.67ms) across full 300s run (got ${(maxDrift * 1000).toFixed(2)}ms)`);
    assertEqual(timeline.isCompleted, true, `Must complete at 300s`);
    assertEqual(timeline.currentTime, 300.0, `currentTime must equal 300.0s`);

    return 3;
  });

  await testCase('S5.2: Dual-Mode Audio Master: Micro-drift soft sync convergence', async () => {
    const { timeline, audioManager, env } = await bootApp();
    timeline.seek(10.0);
    timeline.play();

    // Advance 60 frames smoothly with synchronized audio
    for (let f = 0; f < 60; f++) {
      audioManager.audio.currentTime += 0.01667;
      env.window.stepFrames(1, 16.67);
    }
    const baselineTime = timeline.currentTime;

    // Simulate audio clock drifting +0.15s (150ms ahead)
    audioManager.audio.currentTime = baselineTime + 0.15;
    audioManager.audio.paused = false;

    // Soft sync should pull timeline towards audio.currentTime over subsequent frames
    const drifts = [];
    for (let f = 0; f < 30; f++) {
      env.window.stepFrames(1, 16.67);
      audioManager.audio.currentTime += 0.01667; // audio advances too
      const currentDrift = Math.abs(audioManager.audio.currentTime - timeline.currentTime);
      drifts.push(currentDrift);
    }

    // Invariant: Drift must strictly decrease as exponential soft sync operates
    const initialDrift = drifts[0];
    const finalDrift = drifts[drifts.length - 1];
    console.log(`      Audio Soft Sync Convergence: ${initialDrift.toFixed(4)}s -> ${finalDrift.toFixed(4)}s`);
    assert(finalDrift < initialDrift, `Drift must decrease (started ${initialDrift}s, ended ${finalDrift}s)`);
    assert(finalDrift <= 0.045, `Final drift ${finalDrift}s must converge into micro-zone (<= 0.045s)`);

    return 2;
  });

  await testCase('S5.3: Dual-Mode Audio Master: Severe drift (>0.3s) immediate hard sync snap', async () => {
    const { timeline, audioManager, env } = await bootApp();
    timeline.seek(50.0);
    timeline.play();
    env.window.stepFrames(60, 16.67);

    // Audio hitches or buffers ahead by 1.2 seconds
    const targetAudioTime = timeline.currentTime + 1.2;
    audioManager.audio.currentTime = targetAudioTime;
    audioManager.audio.paused = false;

    // Step 1 frame: hard sync must snap immediately
    env.window.stepFrames(1, 16.67);
    assertApprox(timeline.currentTime, targetAudioTime, 0.05, `Hard sync must immediately snap to masterTime`);

    return 1;
  });

  await testCase('S5.4: Seek Settling Guard: 500ms immunity window against stale audio timestamps', async () => {
    const { timeline, audioManager, env } = await bootApp();
    timeline.seek(20.0);
    timeline.play();
    env.window.stepFrames(60, 16.67);

    // User seeks to 150.0s
    timeline.seek(150.0);

    // Audio element asynchronously still reports old timestamp (21.0s) for 300ms
    audioManager.audio.currentTime = 21.0;
    audioManager.audio.paused = false;

    // Step 18 frames @ 16.67ms (~300ms)
    env.window.stepFrames(18, 16.67);

    // Timeline must NOT have jumped back to 21.0s! It must have advanced from 150.0s!
    assert(timeline.currentTime >= 150.2, `Timeline must advance from seek point 150s, got ${timeline.currentTime}`);
    assert(timeline.currentTime < 151.0, `Timeline must stay within expected synthetic bounds, got ${timeline.currentTime}`);

    // Now audio catches up to seek destination and advances normally
    audioManager.audio.currentTime = timeline.currentTime;
    for (let f = 0; f < 20; f++) {
      audioManager.audio.currentTime += 0.01667;
      env.window.stepFrames(1, 16.67);
    }
    // Now past 500ms settling guard, timeline is locked to audio
    assertApprox(timeline.currentTime, audioManager.audio.currentTime, 0.05, `Timeline smoothly locks to audio once settled`);

    return 3;
  });

  await testCase('S5.5: Prolonged Dual-Mode Audio Master: 18,000 frames with continuous real-world audio jitter', async () => {
    const { timeline, audioManager, env } = await bootApp();
    timeline.seek(0.0);
    timeline.play();

    let maxObservedDrift = 0;
    const FRAME_SEC = 1.0 / 60.0;
    audioManager.audio.currentTime = 0.0;
    audioManager.audio.paused = false;

    // Step 18,000 frames (300 seconds of full simulated playback)
    // Every frame, audio clock advances with realistic ±5ms micro-jitter
    for (let f = 0; f < 18000; f++) {
      const jitterSec = (Math.random() - 0.5) * 0.005;
      audioManager.audio.currentTime += FRAME_SEC + jitterSec;

      env.window.stepFrames(1, 1000.0 / 60.0);

      const drift = Math.abs(timeline.currentTime - audioManager.audio.currentTime);
      if (drift > maxObservedDrift) maxObservedDrift = drift;

      if (timeline.isCompleted) break;
    }

    console.log(`      18,000 Frames Continuous Dual-Mode Max Observed Drift: ${(maxObservedDrift * 1000).toFixed(2)}ms`);
    assert(maxObservedDrift < 0.08, `Dual-mode drift ${maxObservedDrift}s must remain under 80ms (ITU-R BT.1359 standard) across full playback`);
    assertApprox(timeline.currentTime, 300.0, 0.5, `Timeline reaches completion near 300.0s`);

    return 2;
  });

  // --------------------------------------------------------------------------
  // SUITE 6: Stage Breadcrumbs & Full UI Consistency Stress
  // --------------------------------------------------------------------------
  console.log('\n▶ [Suite 6/6] Stage Breadcrumbs & Full UI Consistency Stress (1,000 seeks)...');

  await testCase('S6.1: 1,000 random seeks across stages maintain perfect breadcrumb & drawer consistency', async () => {
    const env = createMockEnvironment();
    if (!env.window.HTMLElement.prototype.remove) {
      env.window.HTMLElement.prototype.remove = function() {
        if (this.parentElement) this.parentElement.removeChild(this);
      };
    }

    const dataMod = await loadPlayerModule('js/presentationData.js', env);
    const audioMod = await loadPlayerModule('js/audioManager.js', env);
    const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
    const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);

    const doc = env.document;
    const stages = env.window.PEOPLEPULSE_PRESENTATION_DATA.stages;

    // Create Scrubber Jump Buttons
    const jumpButtons = [];
    stages.forEach((s) => {
      const btn = doc.createElement('button');
      btn.className = 'stage-jump-btn';
      btn.dataset.stageId = String(s.id);
      doc.body.appendChild(btn);
      jumpButtons.push(btn);
    });

    // Create Drawer Rubric Breadcrumbs
    const rubricCrumbs = [];
    stages.forEach((s) => {
      const crumb = doc.createElement('div');
      crumb.className = 'rubric-crumb';
      crumb.dataset.stageId = String(s.id);
      doc.body.appendChild(crumb);
      rubricCrumbs.push(crumb);
    });

    // Create Drawer element & event stream
    const drawerEl = doc.createElement('aside');
    drawerEl.id = 'pulseagent-drawer';
    doc.body.appendChild(drawerEl);

    const eventStreamEl = doc.createElement('div');
    eventStreamEl.id = 'agent-event-stream';
    doc.body.appendChild(eventStreamEl);

    const audioManager = new env.window.AudioManager();
    const timeline = new env.window.TimelineEngine({
      duration: 300.0,
      audioManager: audioManager
    });

    const simulator = new env.window.SceneSimulator({
      drawerEl: drawerEl,
      eventStreamEl: eventStreamEl,
      audioManager: audioManager
    });

    // Wire listeners like app.js
    timeline.onTick((tick) => {
      simulator.update(tick.currentTime, tick.stage);
    });

    timeline.onStageChange(({ stageIndex }) => {
      jumpButtons.forEach((btn, idx) => {
        if (idx === stageIndex) btn.classList.add('active-stage-btn');
        else btn.classList.remove('active-stage-btn');
      });
    });

    let assertions = 0;
    const ITERATIONS = 1000;

    for (let i = 0; i < ITERATIONS; i++) {
      const targetSec = Math.random() * 300.0;
      timeline.seek(targetSec);

      const activeStageId = timeline.currentStageIndex + 1;

      // 1. Check scrubber buttons
      let activeBtnCount = 0;
      jumpButtons.forEach((btn, idx) => {
        if (idx === timeline.currentStageIndex) {
          assert(btn.classList.contains('active-stage-btn'), `Button ${idx+1} must be active at t=${targetSec}`);
          activeBtnCount++;
        } else {
          assert(!btn.classList.contains('active-stage-btn'), `Button ${idx+1} must NOT be active at t=${targetSec}`);
        }
      });
      assertEqual(activeBtnCount, 1, `Exactly 1 scrubber button must be active`);

      // 2. Check rubric crumbs
      rubricCrumbs.forEach((crumb) => {
        const cId = parseInt(crumb.dataset.stageId, 10);
        if (cId === activeStageId) {
          assert(crumb.classList.contains('active-crumb'), `Crumb ${cId} must have active-crumb`);
          assert(!crumb.classList.contains('completed-crumb'), `Crumb ${cId} must NOT have completed-crumb`);
        } else if (cId < activeStageId) {
          assert(crumb.classList.contains('completed-crumb'), `Crumb ${cId} must have completed-crumb`);
          assert(!crumb.classList.contains('active-crumb'), `Crumb ${cId} must NOT have active-crumb`);
        } else {
          assert(!crumb.classList.contains('active-crumb'), `Future crumb ${cId} must not have active-crumb`);
          assert(!crumb.classList.contains('completed-crumb'), `Future crumb ${cId} must not have completed-crumb`);
        }
      });

      // 3. Check drawer open/close (drawer-visible class)
      if (targetSec >= 44.0) {
        assert(drawerEl.classList.contains('drawer-visible'), `Drawer must have drawer-visible at t=${targetSec}`);
      } else {
        assert(!drawerEl.classList.contains('drawer-visible'), `Drawer must NOT have drawer-visible at t=${targetSec}`);
      }

      // 4. Check ODAEA card streaming consistency
      const renderedCardCount = simulator.renderedEventIds.size;
      const expectedEvents = (env.window.PEOPLEPULSE_PRESENTATION_DATA.eventStream || [])
        .filter(e => targetSec >= e.time);
      assertEqual(renderedCardCount, expectedEvents.length, `Rendered event cards count at t=${targetSec}`);

      assertions += 15;
    }

    return assertions;
  });

  await testCase('S6.2: Backward seeking cleans up future cards without leaving orphaned DOM nodes', async () => {
    const env = createMockEnvironment();
    if (!env.window.HTMLElement.prototype.remove) {
      env.window.HTMLElement.prototype.remove = function() {
        if (this.parentElement) this.parentElement.removeChild(this);
      };
    }

    await loadPlayerModule('js/presentationData.js', env);
    await loadPlayerModule('js/audioManager.js', env);
    await loadPlayerModule('js/timelineEngine.js', env);
    await loadPlayerModule('js/sceneSimulator.js', env);

    const doc = env.document;
    const drawerEl = doc.createElement('aside');
    const eventStreamEl = doc.createElement('div');
    doc.body.appendChild(drawerEl);
    doc.body.appendChild(eventStreamEl);

    const audioManager = new env.window.AudioManager();
    const timeline = new env.window.TimelineEngine({ duration: 300.0, audioManager });
    const simulator = new env.window.SceneSimulator({ drawerEl, eventStreamEl, audioManager });

    timeline.onTick((tick) => {
      simulator.update(tick.currentTime, tick.stage);
    });

    // Seek to 280s (Outcome, all 13 cards rendered)
    timeline.seek(280.0);
    const totalEvents = env.window.PEOPLEPULSE_PRESENTATION_DATA.eventStream.length;
    assertEqual(simulator.renderedEventIds.size, totalEvents, `All ${totalEvents} cards rendered at 280s`);

    // Seek backwards to 50s (Stage 2: only events with time <= 50s should remain)
    timeline.seek(50.0);
    const expectedRemaining = env.window.PEOPLEPULSE_PRESENTATION_DATA.eventStream.filter(e => e.time <= 50.0).length;
    assertEqual(simulator.renderedEventIds.size, expectedRemaining, `Only ${expectedRemaining} cards remain at 50s`);

    // Seek backwards to 0.0s (No cards should remain)
    timeline.seek(0.0);
    assertEqual(simulator.renderedEventIds.size, 0, `0 cards remain at 0s`);

    return 3;
  });

  // --------------------------------------------------------------------------
  // Summary Reporting
  // --------------------------------------------------------------------------
  console.log('\n========================================================================');
  console.log(' STRESS VERIFICATION EXECUTION SUMMARY');
  console.log('========================================================================');
  const passedCount = results.filter(r => r.passed).length;
  const failedCount = results.filter(r => !r.passed).length;
  console.log(` Total Test Cases Executed: ${results.length}`);
  console.log(` Passed:                   ${passedCount}`);
  console.log(` Failed:                   ${failedCount}`);
  console.log(` Total Assertions Evaluated: ${totalAssertions}`);
  console.log('========================================================================\n');

  if (failedCount > 0) {
    throw new Error(`${failedCount} stress test cases failed!`);
  }

  return { passedCount, failedCount, totalAssertions, results };
}

// Direct execution support
if (process.argv[1] && process.argv[1].includes('stress_timeline_transport.mjs')) {
  runTimelineTransportStressTests().catch(err => {
    console.error('Fatal execution error:', err);
    process.exit(1);
  });
}
