// Tier 1: Feature Coverage Test Suite (F01 - F24)
// Minimum 5 test cases per feature = 120 test cases total
// Verifies primary behaviors, happy paths, and interface contracts.

import path from 'node:path';
import fs from 'node:fs';
import {
  assert,
  assertEqual,
  assertNotEqual,
  assertDeepEqual,
  assertApprox,
  assertIncludes,
  assertMatch,
  assertThrows,
  SPEC_CONSTANTS,
  createMockEnvironment,
  loadPlayerModule,
  readPlayerFile,
  fileExistsInPlayer,
  PLAYER_ROOT
} from './harness.mjs';

export function registerTier1Tests(runner) {
  runner.describe('Tier 1: Feature Coverage (F01 - F24)', ({ test, beforeEach }) => {
    let env;

    beforeEach(() => {
      env = createMockEnvironment();
    });

    // ========================================================================
    // F01: 300s Timeline Engine
    // ========================================================================
    test('T1.F01.1 - Total duration is configured to exactly 300.0 seconds', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(data, 'Presentation data must load');
      assert(Engine, 'TimelineEngine module must load');

      assertEqual(data.meta?.duration || data.totalDuration || 300.0, 300.0, 'Presentation dataset duration must be 300.0s');
      const engine = new Engine();
      assertEqual(engine.duration, 300.0, 'TimelineEngine duration must be 300.0s');
      assertEqual(SPEC_CONSTANTS.TOTAL_DURATION, 300.0);
    });

    test('T1.F01.2 - Six continuous stages span from 0.0s to 300.0s without time gaps', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const stages = data?.stages || SPEC_CONSTANTS.STAGES;
      assertEqual(stages.length, 6, 'There must be exactly 6 stages');
      assertEqual(stages[0].start, 0.0, 'Stage 1 starts at 0.0s');
      for (let i = 0; i < stages.length - 1; i++) {
        const currentEnd = stages[i].end;
        const nextStart = stages[i + 1].start;
        assertApprox(currentEnd, nextStart, 0.01, `Stage ${i + 1} end equals Stage ${i + 2} start`);
      }
      const finalEnd = stages[stages.length - 1].end;
      assertEqual(finalEnd, 300.0, 'Final stage ends at 300.0s');
    });

    test('T1.F01.3 - Monotonic advancement of currentTime during playback', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine({ mode: 'synthetic' });
      engine.seek(10.0);
      const t1 = engine.currentTime;
      engine.isPlaying = true;
      const now = performance.now();
      engine.syntheticClock.lastPerfTime = now - 50;
      engine._onAnimationFrame(now);
      const t2 = engine.currentTime;
      assert(t2 > t1, 'Time must advance monotonically during playback');
    });

    test('T1.F01.4 - Tick callback fires with state { currentTime, duration, stage, isPaused, speed }', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine({ mode: 'synthetic' });
      let tickReceived = null;
      engine.onTick((state) => {
        tickReceived = state;
      });
      engine.seek(50.0);
      assert(tickReceived !== null, 'onTick callback must be called on seek');
      assertEqual(typeof tickReceived.currentTime, 'number', 'Tick state must include currentTime');
      assertEqual(typeof tickReceived.duration, 'number', 'Tick state must include duration');
      assert(tickReceived.stage !== undefined, 'Tick state must include active stage');
    });

    test('T1.F01.5 - Stage lookup correctly maps timestamps to the 6 stages', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      const s1 = engine.getStageForTime(20.0).stage;
      const s2 = engine.getStageForTime(60.0).stage;
      const s3 = engine.getStageForTime(100.0).stage;
      const s4 = engine.getStageForTime(140.0).stage;
      const s5 = engine.getStageForTime(180.0).stage;
      const s6 = engine.getStageForTime(250.0).stage;

      assertIncludes(s1.name.toLowerCase(), 'goal', '20s is Goal');
      assertIncludes(s2.name.toLowerCase(), 'decision', '60s is Decision');
      assertIncludes(s3.name.toLowerCase(), 'action', '100s is Action');
      assertIncludes(s4.name.toLowerCase(), 'evaluation', '140s is Evaluation');
      assertIncludes(s5.name.toLowerCase(), 'adapt', '180s is Adaptation');
      assertIncludes(s6.name.toLowerCase(), 'outcome', '250s is Outcome');
    });

    // ========================================================================
    // F02: Transport Controls (Play/Pause/Seek)
    // ========================================================================
    test('T1.F02.1 - play() switches state from paused to playing (isPaused === false)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.pause();
      assertEqual(engine.isPlaying, false, 'Initial state paused');
      engine.play();
      assertEqual(engine.isPlaying, true, 'play() sets isPlaying to true');
    });

    test('T1.F02.2 - pause() halts time progression (isPaused === true)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.play();
      assertEqual(engine.isPlaying, true, 'Engine playing');
      engine.pause();
      assertEqual(engine.isPlaying, false, 'pause() sets isPlaying to false');
    });

    test('T1.F02.3 - Scrubber seek moves currentTime to designated second', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(142.5);
      assertEqual(engine.currentTime, 142.5, 'seek(142.5) updates currentTime exactly');
    });

    test('T1.F02.4 - Resuming after pause starts from the exact paused timestamp', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(175.4);
      engine.pause();
      const pausedTime = engine.currentTime;
      engine.play();
      const resumedTime = engine.currentTime;
      assertEqual(resumedTime, pausedTime, 'Resume must not jump timestamp');
    });

    test('T1.F02.5 - Restart button resets presentation to 0.0s and begins playback', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(280.0);
      engine.restart();
      assertEqual(engine.currentTime, 0.0, 'restart() resets currentTime to 0');
      assertEqual(engine.isPlaying, true, 'restart() begins playback');
    });

    // ========================================================================
    // F03: Speed Multiplier (1.0x, 1.25x, 1.5x)
    // ========================================================================
    test('T1.F03.1 - Default playback speed is 1.0x', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      assertEqual(engine.speed, 1.0, 'Default speed must be 1.0x');
    });

    test('T1.F03.2 - Setting speed to 1.25x updates speed state and audio playbackRate', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioMgr, 'Modules must load');

      const audio = new AudioMgr();
      const engine = new Engine({ audioManager: audio });
      engine.setSpeed(1.25);
      assertEqual(engine.speed, 1.25, 'Engine speed updated to 1.25');
      assertEqual(audio.audioElement.playbackRate, 1.25, 'Audio playbackRate matches 1.25');
    });

    test('T1.F03.3 - Setting speed to 1.5x updates speed state and audio playbackRate', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioMgr, 'Modules must load');

      const audio = new AudioMgr();
      const engine = new Engine({ audioManager: audio });
      engine.setSpeed(1.5);
      assertEqual(engine.speed, 1.5, 'Engine speed updated to 1.5');
      assertEqual(audio.audioElement.playbackRate, 1.5, 'Audio playbackRate matches 1.5');
    });

    test('T1.F03.4 - preservesPitch remains true on audio element across all speed toggles', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const audio = new AudioMgr();
      audio.setRate(1.25);
      assertEqual(audio.audioElement.preservesPitch, true, 'preservesPitch true at 1.25x');
      audio.setRate(1.5);
      assertEqual(audio.audioElement.preservesPitch, true, 'preservesPitch true at 1.5x');
      audio.setRate(1.0);
      assertEqual(audio.audioElement.preservesPitch, true, 'preservesPitch true at 1.0x');
    });

    test('T1.F03.5 - Speed cycling (1.0x -> 1.25x -> 1.5x -> 1.0x) toggles through all rates', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      assertEqual(engine.speed, 1.0);
      engine.cycleSpeed();
      assertEqual(engine.speed, 1.25, 'First cycle to 1.25');
      engine.cycleSpeed();
      assertEqual(engine.speed, 1.5, 'Second cycle to 1.5');
      engine.cycleSpeed();
      assertEqual(engine.speed, 1.0, 'Third cycle back to 1.0');
    });

    // ========================================================================
    // F04: Stage Jump Markers
    // ========================================================================
    test('T1.F04.1 - Six stage jump markers exist matching stage start timestamps', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data, 'Presentation data must load');

      const stages = data.stages;
      assertEqual(stages.length, 6, 'Must have 6 stages');
      assertEqual(stages[0].start, 0.0);
      assertEqual(stages[1].start, 45.0);
      assertEqual(stages[2].start, 90.0);
      assertEqual(stages[3].start, 134.0);
      assertEqual(stages[4].start, 160.0);
      assertEqual(stages[5].start, 225.0);
    });

    test('T1.F04.2 - Clicking Stage 2 jump marker seeks to 45.0s (Decision Framework)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.jumpToStage(1); // Index 1 is Stage 2
      assertApprox(engine.currentTime, 45.05, 0.1, 'Jumped to Stage 2 start');
    });

    test('T1.F04.3 - Clicking Stage 4 jump marker seeks to 134.0s (Dynamic Evaluation)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.jumpToStage(3); // Index 3 is Stage 4
      assertApprox(engine.currentTime, 134.05, 0.1, 'Jumped to Stage 4 start');
    });

    test('T1.F04.4 - Clicking Stage 5 jump marker seeks to 160.0s (Adaptation)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.jumpToStage(4); // Index 4 is Stage 5
      assertApprox(engine.currentTime, 160.05, 0.1, 'Jumped to Stage 5 start');
    });

    test('T1.F04.5 - Clicking Stage 6 jump marker seeks to 225.0s (Outcome & Synthesis)', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.jumpToStage(5); // Index 5 is Stage 6
      assertApprox(engine.currentTime, 225.05, 0.1, 'Jumped to Stage 6 start');
    });

    // ========================================================================
    // F05: Auto-Advance & Stage Highlighting
    // ========================================================================
    test('T1.F05.1 - Stage transitions automatically when timeline crosses stage boundary', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(44.0);
      assertEqual(engine.getStageForTime(engine.currentTime).stage.id, 1);
      engine.seek(46.0);
      assertEqual(engine.getStageForTime(engine.currentTime).stage.id, 2);
    });

    test('T1.F05.2 - Active stage breadcrumb receives active styling class', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.updateStageBreadcrumbs(2);
      const activeCrumb = env.document.querySelector('.rubric-crumb.active-crumb');
      assert(activeCrumb !== null, 'Active breadcrumb exists');
      assertEqual(activeCrumb.dataset.stageId, '2', 'Stage 2 is active crumb');
    });

    test('T1.F05.3 - Preceding stages receive completed styling class', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.updateStageBreadcrumbs(3);
      const completedCrumbs = env.document.querySelectorAll('.rubric-crumb.completed-crumb');
      assert(completedCrumbs.length >= 2, 'Stages 1 and 2 marked completed when on stage 3');
    });

    test('T1.F05.4 - Stage change listener fires when crossing boundary', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      let changedStage = null;
      engine.onStageChange((stage) => {
        changedStage = stage;
      });
      engine.seek(44.0);
      engine.seek(46.0);
      assert(changedStage !== null, 'Stage change listener must be triggered');
      assertEqual(changedStage.id, 2, 'Stage 2 reported by listener');
    });

    test('T1.F05.5 - Presentation halts and marks completion state at 300.0s', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.play();
      engine.seek(300.0);
      assertEqual(engine.isCompleted, true, 'isCompleted marked true at 300.0s');
      assertEqual(engine.isPlaying, false, 'isPlaying halted at 300.0s');
    });

    // ========================================================================
    // F06: Continuous Voiceover Narration
    // ========================================================================
    test('T1.F06.1 - Narration audio file assets/audio/narration_full.mp3 exists', () => {
      assert(fileExistsInPlayer('assets/audio/narration_full.mp3'), 'narration_full.mp3 must exist');
    });

    test('T1.F06.2 - Pitch script covers all 6 blocks (~680 total spoken words)', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.cues && data.cues.length >= 20, 'Cues must exist in presentation data');

      const totalWords = data.cues.reduce((sum, c) => sum + (c.text?.split(/\s+/).filter(Boolean).length || 0), 0);
      assert(totalWords >= 500, `Total spoken words in pitch script should be >= 500, got ${totalWords}`);
    });

    test('T1.F06.3 - Audio playback starts when presentation play begins', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      await mgr.play();
      assertEqual(mgr.audioElement.paused, false, 'Audio playback starts on play()');
    });

    test('T1.F06.4 - Audio playback pauses when presentation pauses', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      await mgr.play();
      mgr.pause();
      assertEqual(mgr.audioElement.paused, true, 'Audio playback pauses on pause()');
    });

    test('T1.F06.5 - Seeking presentation seeks audio element synchronously', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      mgr.seek(125.0);
      assertEqual(mgr.audioElement.currentTime, 125.0, 'Audio element currentTime matches seek target');
    });

    // ========================================================================
    // F07: Audio Controls (Mute/Volume/Rate)
    // ========================================================================
    test('T1.F07.1 - Initial volume is set to 1.0 (100%)', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      assertEqual(mgr.volume, 1.0, 'Initial volume must be 1.0');
    });

    test('T1.F07.2 - setVolume(v) clamps values between 0.0 and 1.0', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      mgr.setVolume(1.5);
      assertEqual(mgr.volume, 1.0, 'Clamped at 1.0');
      mgr.setVolume(-0.5);
      assertEqual(mgr.volume, 0.0, 'Clamped at 0.0');
      mgr.setVolume(0.7);
      assertEqual(mgr.volume, 0.7, 'Set to 0.7');
    });

    test('T1.F07.3 - toggleMute() switches muted state between true and false', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      assertEqual(mgr.muted, false, 'Initially unmuted');
      mgr.toggleMute();
      assertEqual(mgr.muted, true, 'Muted after first toggle');
      mgr.toggleMute();
      assertEqual(mgr.muted, false, 'Unmuted after second toggle');
    });

    test('T1.F07.4 - Muting preserves current volume level for unmuting restoration', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      mgr.setVolume(0.65);
      mgr.toggleMute();
      assertEqual(mgr.muted, true, 'Muted');
      assertEqual(mgr.volume, 0.65, 'Volume preserved while muted');
      mgr.toggleMute();
      assertEqual(mgr.muted, false, 'Unmuted');
      assertEqual(mgr.volume, 0.65, 'Volume intact upon unmuting');
    });

    test('T1.F07.5 - Audio controls UI reflects volume and mute changes', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      mgr.setVolume(0.8);
      assertEqual(mgr.audioElement.volume, 0.8, 'Audio element volume updated');
      mgr.toggleMute();
      assertEqual(mgr.audioElement.muted, true, 'Audio element muted state updated');
    });

    // ========================================================================
    // F08: High-Contrast Live Subtitles
    // ========================================================================
    test('T1.F08.1 - Subtitle overlay container exists with high contrast styling', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const textEl = env.document.getElementById('subtitle-text');
      const containerEl = env.document.getElementById('subtitle-overlay');
      assert(textEl !== null && containerEl !== null, 'Subtitle DOM containers must exist');
      const renderer = new SubRenderer({ containerEl, textEl });
      assert(renderer !== null, 'Renderer instance created');
    });

    test('T1.F08.2 - Displays active sentence text matching spoken script for current timestamp', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');
      assert(data?.cues && data.cues.length >= 20, 'Cues must be bundled in presentation data');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl, cues: data.cues });
      const cue = renderer.getActiveCue(5.0);
      assert(cue !== null, 'Cue at 5s must exist');
      assert(cue.text.length > 0, 'Cue text must not be empty');
      renderer.update(5.0);
      assert(textEl.textContent.length > 0, 'Subtitle text element populated');
    });

    test('T1.F08.3 - Stage indicator tag is rendered alongside subtitle text', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.cues && data.cues.length >= 20, 'Cues must be bundled in presentation data');

      assert(data.cues[0].stageName || data.cues[0].stageId, 'Cues must include stage tag information');
      assertEqual(data.cues[0].stageId, 1, 'First cue is Stage 1');
    });

    test('T1.F08.4 - Subtitle visibility toggle (hide/show) functions correctly', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const container = env.document.getElementById('subtitle-overlay');
      const renderer = new SubRenderer({ containerEl: container });
      renderer.toggleVisibility(false);
      assertEqual(renderer.isVisible, false, 'Visibility toggled off');
      renderer.toggleVisibility(true);
      assertEqual(renderer.isVisible, true, 'Visibility toggled on');
    });

    test('T1.F08.5 - Interactive transcript drawer contains complete pitch script', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');
      assert(data?.cues, 'Cues must exist in presentationData');
      assertEqual(data.cues.length, 27, 'Pitch script contains exactly 27 cues');

      const transcriptListEl = env.document.getElementById('transcript-list');
      const renderer = new SubRenderer({ transcriptListEl, cues: data.cues });
      const items = transcriptListEl.querySelectorAll('.transcript-item');
      assertEqual(items.length, 27, 'Transcript drawer renders all 27 cue rows');
    });

    // ========================================================================
    // F09: Word/Phrase Synchronization
    // ========================================================================
    test('T1.F09.1 - Word tokens contain millisecond start and end timestamps', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.cues && data.cues.length >= 20, 'Cues must exist in presentation data');

      for (const cue of data.cues) {
        assert(Array.isArray(cue.tokens) && cue.tokens.length > 0, `Cue ${cue.id} must have tokens`);
        for (const tok of cue.tokens) {
          assertEqual(typeof tok.start, 'number', `Token "${tok.text}" start is number`);
          assertEqual(typeof tok.end, 'number', `Token "${tok.text}" end is number`);
          assert(tok.end > tok.start, `Token "${tok.text}" in ${cue.id} has end (${tok.end}) > start (${tok.start})`);
        }
      }
    });

    test('T1.F09.2 - Active spoken word receives .token-active styling', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl });
      renderer.loadCues([
        {
          id: 'c1',
          start: 0,
          end: 5,
          text: 'Hello world test',
          tokens: [
            { text: 'Hello', start: 0, end: 1 },
            { text: 'world', start: 1, end: 2 },
            { text: 'test', start: 2, end: 3 }
          ]
        }
      ]);
      renderer.update(1.5);
      const activeWord = textEl.querySelector('.token-active');
      assert(activeWord !== null, 'Active word token element exists with .token-active');
      assertIncludes(activeWord.textContent, 'world', 'Active word is world');
    });

    test('T1.F09.3 - Past spoken words receive muted styling', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl });
      renderer.loadCues([
        {
          id: 'c1',
          start: 0,
          end: 5,
          text: 'Hello world',
          tokens: [
            { text: 'Hello', start: 0, end: 1 },
            { text: 'world', start: 1, end: 2 }
          ]
        }
      ]);
      renderer.update(1.5);
      const spokenWord = textEl.querySelector('.token-spoken');
      assert(spokenWord !== null, 'Past spoken word element exists with .token-spoken');
      assertIncludes(spokenWord.textContent, 'Hello', 'Past spoken word is Hello');
    });

    test('T1.F09.4 - Future spoken words receive default/unhighlighted styling', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl });
      renderer.loadCues([
        {
          id: 'c1',
          start: 0,
          end: 5,
          text: 'Hello world future',
          tokens: [
            { text: 'Hello', start: 0, end: 1 },
            { text: 'world', start: 1, end: 2 },
            { text: 'future', start: 2, end: 3 }
          ]
        }
      ]);
      renderer.update(1.5);
      const upcomingWord = textEl.querySelector('.token-upcoming');
      assert(upcomingWord !== null, 'Future word element exists with .token-upcoming');
      assertIncludes(upcomingWord.textContent, 'future', 'Future word is future');
    });

    test('T1.F09.5 - Key technical terms have highlight accents', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.cues && data.cues.length >= 20, 'Cues must exist in presentation data');

      const hasHighlights = data.cues.some((c) => c.tokens?.some((t) => t.highlight) || c.key_terms?.length > 0);
      assert(hasHighlights, 'Key technical terms have highlight accents');
    });

    // ========================================================================
    // F10: Dual-Mode Clock Fallback
    // ========================================================================
    test('T1.F10.1 - Audio master clock mode is active when audio element is playing', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioManager = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioManager, 'Modules must load');

      const audio = new AudioManager();
      const engine = new Engine({ audioManager: audio });
      engine.play();
      assertEqual(engine.isPlaying, true, 'Engine playing with audio manager');
    });

    test('T1.F10.2 - Synthetic clock fallback is active when audio is unavailable or muted', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine({ mode: 'synthetic' });
      engine.play();
      assertEqual(engine.isPlaying, true, 'Engine running in synthetic mode');
    });

    test('T1.F10.3 - Clock synchronization loop runs via requestAnimationFrame', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.play();
      assert(engine.rafId !== null, 'rafId assigned on play()');
      engine.pause();
      assertEqual(engine.rafId, null, 'rafId cancelled on pause()');
    });

    test('T1.F10.4 - Audio time updates clamp visual clock when drift exceeds threshold', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioManager = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioManager, 'Modules must load');

      const audio = new AudioManager();
      const engine = new Engine({ audioManager: audio });
      engine.isPlaying = true;
      engine.currentTime = 50.0;
      engine._lastSeekPerf = 0;
      audio.audio.currentTime = 51.5; // > 0.3s drift
      audio.audio.paused = false;

      const now = performance.now() + 1000;
      engine.syntheticClock.lastPerfTime = now;
      engine._onAnimationFrame(now + 16.67);
      assertEqual(engine.currentTime, 51.5, 'Clamped visual clock to audio currentTime on large drift');
    });

    test('T1.F10.5 - Audio ended event triggers presentation completion', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(300.0);
      assertEqual(engine.isCompleted, true, 'isCompleted true at 300s');
    });

    // ========================================================================
    // F11: Admin Dashboard Mockup
    // ========================================================================
    test('T1.F11.1 - Dashboard view renders 4 primary KPI metric cards', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      const kpis = env.document.querySelectorAll('.kpi-card');
      assertEqual(kpis.length, 4, '4 KPI cards rendered in dashboard');
    });

    test('T1.F11.2 - Renders Total Employees metric: 248', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.dashboard?.kpis, 'Dashboard KPIs must exist');

      const emp = data.dashboard.kpis.find((k) => k.id === 'total_employees');
      assert(emp !== undefined, 'Total Employees KPI found');
      assertEqual(emp.value, '248', 'Total Employees is 248');
    });

    test('T1.F11.3 - Renders Overall Wellbeing / Avg Engagement: 68%', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.dashboard?.kpis, 'Dashboard KPIs must exist');

      const well = data.dashboard.kpis.find((k) => k.id === 'avg_engagement');
      assert(well !== undefined, 'Wellbeing KPI found');
      assertEqual(well.value, '68%', 'Wellbeing is 68%');
    });

    test('T1.F11.4 - Renders Weekly Participation Rate: 84.2%', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.dashboard?.kpis, 'Dashboard KPIs must exist');

      const part = data.dashboard.kpis.find((k) => k.id === 'weekly_participation');
      assert(part !== undefined, 'Weekly participation KPI found');
      assertEqual(part.value, '84.2%', 'Participation rate is 84.2%');
    });

    test('T1.F11.5 - Renders 5 active teams with health status chips (Customer Support 42% High Risk)', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.dashboard?.teams, 'Teams list must exist in dashboard');

      assertEqual(data.dashboard.teams.length, 5, 'Must have 5 active teams');
      const cs = data.dashboard.teams.find((t) => t.name === 'Customer Support');
      assert(cs !== undefined, 'Customer Support team exists');
      assertEqual(cs.score, 42, 'Customer Support score is 42');
      assertEqual(cs.status, 'Critical', 'Customer Support status is Critical');
    });

    // ========================================================================
    // F12: Sliding PulseAgent Drawer
    // ========================================================================
    test('T1.F12.1 - Floating PulseAgent trigger button exists', async () => {
      const btn = env.document.getElementById('floating-copilot-btn');
      assert(btn !== null, 'Floating trigger button #floating-copilot-btn must exist');
    });

    test('T1.F12.2 - Drawer slides open at Stage 2 (t = 45s)', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(50.0, SPEC_CONSTANTS.STAGES[1]);
      assertEqual(sim.isDrawerOpen, true, 'Drawer should be open in Stage 2');
    });

    test('T1.F12.3 - Drawer header renders PulseAgent, ReAct AI Agent, and Gemini Live badges', async () => {
      const drawer = env.document.getElementById('pulseagent-drawer');
      assert(drawer !== null, 'Drawer element must exist');
      const html = readPlayerFile('index.html');
      assertIncludes(html, 'PulseAgent', 'Drawer contains PulseAgent brand');
      assertIncludes(html, 'ReAct', 'Drawer contains ReAct badge');
      assertIncludes(html, 'Gemini', 'Drawer contains Gemini badge');
    });

    test('T1.F12.4 - 6-stage lifecycle breadcrumb bar rendered in drawer header', async () => {
      assertEqual(SPEC_CONSTANTS.STAGES.length, 6, 'Must have 6 stages');
      const crumbs = env.document.querySelectorAll('.rubric-crumb');
      assertEqual(crumbs.length, 6, 'Drawer header renders exactly 6 rubric stage breadcrumbs');
    });

    test('T1.F12.5 - Navigation tabs visible: ReAct Copilot, Audit Trail, Tools', async () => {
      const tabs = Array.from(env.document.querySelectorAll('.agent-tab-btn')).map((b) => b.dataset.tab);
      assertIncludes(tabs, 'react', 'ReAct tab button exists');
      assertIncludes(tabs, 'audit', 'Audit tab button exists');
      assertIncludes(tabs, 'tools', 'Tools tab button exists');
    });

    // ========================================================================
    // F13: Streaming ODAEA Event Cards
    // ========================================================================
    test('T1.F13.1 - Stage 1 Goal card renders at ~95s with goal description', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const goalCard = data.eventStream.find((c) => c.id === 'ev_goal');
      assert(goalCard !== undefined, 'Goal event card exists');
      assertEqual(goalCard.type, 'goal', 'Card type is goal');
      assertEqual(goalCard.time, 95.0, 'Goal card time is 95.0s');
      assertIncludes(goalCard.title.toLowerCase(), 'goal', 'Card title mentions Goal');
    });

    test('T1.F13.2 - Stage 2 Decision card renders at ~105s with tool get_organization_metrics', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const decCard = data.eventStream.find((c) => c.id === 'ev_dec_1');
      assert(decCard !== undefined, 'Decision event card exists');
      assertEqual(decCard.details?.selected_tool, 'get_organization_metrics', 'Tool is get_organization_metrics');
    });

    test('T1.F13.3 - Stage 3 Action card renders at ~118s with executed status', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const actCard = data.eventStream.find((c) => c.id === 'ev_act_1');
      assert(actCard !== undefined, 'Action event card exists');
      assertEqual(actCard.details?.returned_payload?.status, 'success', 'Status is success');
      assertEqual(actCard.badge, '✓ Done', 'Badge indicates Done');
    });

    test('T1.F13.4 - Observation card renders at ~135s with 68% org and 42% Support metrics', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const obsCard = data.eventStream.find((c) => c.id === 'ev_obs_1');
      assert(obsCard !== undefined, 'Observation event card exists');
      const sigStr = obsCard.signals.join(' ');
      assertIncludes(sigStr, '68', 'Signals include 68%');
      assertIncludes(sigStr, '42', 'Signals include 42%');
    });

    test('T1.F13.5 - Stage 4 Evaluation card renders at ~150s with evaluation reasoning', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const evalCard = data.eventStream.find((c) => c.id === 'ev_eval_1');
      assert(evalCard !== undefined, 'Evaluation event card exists');
      assertEqual(evalCard.details?.severity, 'HIGH', 'Evaluation severity is HIGH');
      assert(evalCard.details?.recommended_actions?.length >= 2, 'Recommended actions defined');
    });

    // ========================================================================
    // F14: Orange HTTP 503 Interception
    // ========================================================================
    test('T1.F14.1 - Webhook attempt card triggers in Stage 5 (~165s)', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must exist');

      const dec2 = data.eventStream.find((c) => c.id === 'ev_dec_2');
      assert(dec2 !== undefined, 'Webhook decision event exists');
      assertEqual(dec2.time, 165.0, 'Webhook attempt triggers at 165s');
    });

    test('T1.F14.2 - Webhook attempt shows target https://httpstat.us/503?sleep=1000 and HTTP 503 status', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const dec2 = data?.eventStream?.find((c) => c.id === 'ev_dec_2');
      assert(dec2 !== undefined, 'Decision event card exists');
      assertEqual(dec2.details?.endpoint, 'https://httpstat.us/503?sleep=1000', 'Target endpoint is 503 URL');
      assertEqual(SPEC_CONSTANTS.RESILIENCE.ERROR_CODE, 503);
    });

    test('T1.F14.3 - Orange Adaptation card renders with radiant orange border/gradient', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(180.0, SPEC_CONSTANTS.STAGES[4]);
      const card = env.document.getElementById('card-ev_fail_1');
      assert(card !== null, 'Failure adaptation card rendered in DOM');
      assert(card.classList.contains('card-adaptation-hero'), 'Has card-adaptation-hero class');
      assert(card.classList.contains('pulse-orange-border'), 'Has pulse-orange-border class');
    });

    test('T1.F14.4 - Adaptation card displays Self-Corrected badge', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const failCard = data?.eventStream?.find((c) => c.id === 'ev_fail_1');
      assert(failCard !== undefined, 'Failure adaptation event exists');
      assertEqual(failCard.badge, 'SELF-CORRECTED', 'Badge is SELF-CORRECTED');
    });

    test('T1.F14.5 - Procedural alert warning chime method exists and can be triggered', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      assertEqual(typeof mgr.playAlertChime, 'function', 'playAlertChime method exists');
      mgr.playAlertChime(); // Should not throw
    });

    // ========================================================================
    // F15: Emergency Queue Reroute Card
    // ========================================================================
    test('T1.F15.1 - Fallback Action card appears following HTTP 503 failure (~205s)', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(210.0, SPEC_CONSTANTS.STAGES[4]);
      const card = env.document.getElementById('card-ev_act_2');
      assert(card !== null, 'Emergency queue fallback card rendered following 503');
    });

    test('T1.F15.2 - Identifies tool send_emergency_notification routing to backup queue', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act2 = data?.eventStream?.find((c) => c.id === 'ev_act_2');
      assert(act2 !== undefined, 'Fallback event exists');
      assertEqual(act2.details?.tool, 'send_emergency_notification', 'Tool is send_emergency_notification');
      assertEqual(SPEC_CONSTANTS.RESILIENCE.FALLBACK_TOOL, 'send_emergency_notification');
    });

    test('T1.F15.3 - Status indicates DELIVERED with zero message loss guarantee', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act2 = data?.eventStream?.find((c) => c.id === 'ev_act_2');
      assert(act2 !== undefined, 'Fallback event exists');
      assertEqual(act2.details?.status, 'DELIVERED', 'Status is DELIVERED');
      assertEqual(SPEC_CONSTANTS.RESILIENCE.MESSAGE_LOSS, 0);
    });

    test('T1.F15.4 - Resilience telemetry shows 0% message loss, 100% self-healing autonomy', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act2 = data?.eventStream?.find((c) => c.id === 'ev_act_2');
      assert(act2 !== undefined, 'Fallback event exists');
      assertEqual(act2.details?.message_loss, '0%', 'Message loss is 0%');
      assertEqual(act2.details?.human_intervention_required, 0, 'Zero human intervention');
    });

    test('T1.F15.5 - Fallback card specifies channel emergency_in_app_queue and priority high', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act2 = data?.eventStream?.find((c) => c.id === 'ev_act_2');
      assert(act2 !== undefined, 'Fallback event exists');
      assertEqual(act2.details?.delivery_channel, 'emergency_in_app_queue', 'Channel is emergency_in_app_queue');
      assertEqual(SPEC_CONSTANTS.RESILIENCE.FALLBACK_QUEUE, 'emergency_in_app_queue');
    });

    // ========================================================================
    // F16: Q&A and Rubric Visual Views
    // ========================================================================
    test('T1.F16.1 - Technical Defense Sheet provides 5 judge Q&A defense answers', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.qaDefense, 'qaDefense must exist in presentationData');
      assertEqual(data.qaDefense.length, 5, 'Exactly 5 defense answers');
    });

    test('T1.F16.2 - Defense Answer 1 details ReAct loop vs scripted if-else', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.qaDefense?.[0], 'Defense answer 1 exists');
      assertIncludes(data.qaDefense[0].answer, 'ReAct', 'Answer 1 explains true ReAct loop');
    });

    test('T1.F16.3 - Defense Answer 2 details multi-tenant isolation and context stripping', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.qaDefense?.[1], 'Defense answer 2 exists');
      assertIncludes(data.qaDefense[1].answer.toLowerCase(), 'tenant', 'Answer 2 explains tenant isolation');
    });

    test('T1.F16.4 - Defense Answer 3 details n >= 3 differential privacy threshold', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.qaDefense?.[2], 'Defense answer 3 exists');
      assertIncludes(data.qaDefense[2].answer, '3', 'Answer 3 mentions n >= 3 differential privacy');
      assertEqual(SPEC_CONSTANTS.GOVERNANCE.DIFF_PRIVACY_N, 3);
    });

    test('T1.F16.5 - Defense Answer 4 details dual-key failover and offline deterministic planner', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.qaDefense?.[3], 'Defense answer 4 exists');
      assertIncludes(data.qaDefense[3].answer.toLowerCase(), 'failover', 'Answer 4 details failover architecture');
    });

    // ========================================================================
    // F17: Interactive Live-Pause Sandbox
    // ========================================================================
    test('T1.F17.1 - Pausing presentation activates sandbox mode (isUserInteracting enabled)', async () => {
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Controller, 'InteractiveController must load');

      const ctrl = new Controller({});
      ctrl.onPause();
      assertEqual(ctrl.isSandboxActive, true, 'Sandbox mode enabled on pause');
    });

    test('T1.F17.2 - Playback state is decoupled from sandbox exploration state', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Engine && SceneSim && Controller, 'Modules must load');

      const engine = new Engine();
      const scene = new SceneSim();
      const ctrl = new Controller({ timelineEngine: engine, sceneSimulator: scene });

      engine.seek(100.0);
      engine.pause();
      ctrl.onPause();
      assertEqual(ctrl.isSandboxActive, true, 'Sandbox active');

      scene.switchTab('audit', true);
      assertEqual(engine.currentTime, 100.0, 'Playback time untouched by tab change');
      assertEqual(engine.isPlaying, false, 'Playback still paused');
    });

    test('T1.F17.3 - DOM elements in drawer become clickable/interactive during pause', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const scene = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: scene });
      ctrl.onPause();

      const auditTabBtn = env.document.querySelector('.agent-tab-btn[data-tab="audit"]');
      assert(auditTabBtn !== null, 'Audit tab button exists');
      auditTabBtn.click();
      assertEqual(scene.activeTab, 'audit', 'Tab switched to audit via DOM click');
    });

    test('T1.F17.4 - Timeline clock and audio remain frozen during sandbox exploration', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(150.0);
      engine.pause();
      const t1 = engine.currentTime;
      // Simulate frame ticks while paused
      engine._onAnimationFrame(performance.now() + 1000);
      const t2 = engine.currentTime;
      assertEqual(t1, t2, 'Paused engine time must remain frozen');
    });

    test('T1.F17.5 - Visual indicator shows Interactive Live-Pause Mode is active', async () => {
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Controller, 'InteractiveController must load');

      const ctrl = new Controller({});
      ctrl.onPause();
      const ind = env.document.getElementById('sandbox-mode-indicator');
      assert(ind.classList.contains('visible'), 'Indicator visible on pause');
      ctrl.onResume();
      assertEqual(ind.classList.contains('visible'), false, 'Indicator hidden on resume');
    });

    // ========================================================================
    // F18: JSON Payload Inspector
    // ========================================================================
    test('T1.F18.1 - Expandable/collapsible details elements exist on Action cards', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const scene = new SceneSim();
      scene.update(125.0, SPEC_CONSTANTS.STAGES[2]);
      const card = env.document.getElementById('card-ev_act_1');
      assert(card !== null, 'Action card rendered in DOM');
      const details = card.querySelector('.card-payload-details');
      assert(details !== null, 'Details element exists on Action card');
    });

    test('T1.F18.2 - Clicking payload toggle expands raw JSON view', async () => {
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Controller, 'InteractiveController must load');

      const ctrl = new Controller({});
      ctrl.togglePayload('card-1');
      assert(ctrl.expandedCardDetails.has('card-1'), 'Card added to expanded set');
    });

    test('T1.F18.3 - Action 1 payload reveals organization_id and time_window_days: 30', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act1 = data?.eventStream?.find((c) => c.id === 'ev_act_1');
      assert(act1?.details?.injected_parameters, 'injected_parameters must exist');
      assertEqual(act1.details.injected_parameters.organization_id, 'org_acme_enterprise_9921', 'organization_id verified');
      assertEqual(act1.details.injected_parameters.time_window_days, 30, 'time_window_days is 30');
    });

    test('T1.F18.4 - Visual callout banner proves organization_id was server-injected from session', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const act1 = data?.eventStream?.find((c) => c.id === 'ev_act_1');
      assert(act1?.callout, 'callout banner must exist');
      assertIncludes(act1.callout, 'organization_id server-injected', 'Callout proves server injection');
    });

    test('T1.F18.5 - Clicking payload toggle again collapses JSON view', async () => {
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Controller, 'InteractiveController must load');

      const ctrl = new Controller({});
      ctrl.togglePayload('card-1');
      assert(ctrl.expandedCardDetails.has('card-1'), 'Card expanded');
      ctrl.togglePayload('card-1');
      assertEqual(ctrl.expandedCardDetails.has('card-1'), false, 'Card collapsed on second toggle');
    });

    // ========================================================================
    // F19: PulseAgent Drawer Tabs
    // ========================================================================
    test('T1.F19.1 - Drawer provides tabs: ReAct Copilot, Audit Trail, and Tools Registry', async () => {
      const tabs = Array.from(env.document.querySelectorAll('.agent-tab-btn')).map((b) => b.dataset.tab);
      assertIncludes(tabs, 'react', 'ReAct tab exists');
      assertIncludes(tabs, 'audit', 'Audit tab exists');
      assertIncludes(tabs, 'tools', 'Tools tab exists');
    });

    test('T1.F19.2 - Default tab is ReAct Copilot (react)', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      assertEqual(sim.activeTab, 'react', 'Default tab is react');
    });

    test('T1.F19.3 - Switching to Audit Trail tab updates active tab state and view', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit', 'Active tab is audit');
    });

    test('T1.F19.4 - Switching to Tools Registry tab displays registered tools', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.switchTab('tools');
      assertEqual(sim.activeTab, 'tools', 'Active tab is tools');
      const list = env.document.getElementById('tools-registry-list');
      assert(list !== null, 'Tools list element exists');
    });

    test('T1.F19.5 - Active tab button receives highlighted active styling', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.switchTab('audit', true);
      const auditBtn = env.document.querySelector('.agent-tab-btn[data-tab="audit"]');
      assert(auditBtn.classList.contains('active-tab'), 'Audit button has active-tab styling');
    });

    // ========================================================================
    // F20: Postgres Audit Trail Inspection
    // ========================================================================
    test('T1.F20.1 - Audit Trail table renders agent_activity_logs records', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.auditTrail, 'auditTrail must exist in presentationData');
      assert(data.auditTrail.length >= 5, 'Audit trail contains at least 5 logged records');
    });

    test('T1.F20.2 - Columns include Timestamp, Goal, Tool Invoked, Status, Sanitized Input, Outcome', async () => {
      const ths = Array.from(env.document.querySelectorAll('.audit-table th')).map((t) => t.textContent.trim());
      assert(ths.length >= 5, 'Audit table has >= 5 columns');
      assertIncludes(ths, 'Time', 'Time column exists');
      assertIncludes(ths, 'Tool', 'Tool column exists');
      assertIncludes(ths, 'Status', 'Status column exists');
    });

    test('T1.F20.3 - Credential masking redacts sensitive tokens (e.g. api_key: [REDACTED])', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.auditTrail?.[0], 'Audit trail row exists');
      const input = data.auditTrail[0].sanitizedInput;
      assert(input.includes('[MASKED]') || input.includes('[INJECTED]') || input.includes('[REDACTED]'), 'Sensitive inputs masked');
    });

    test('T1.F20.4 - Human-in-the-Loop modal mockup demonstrated for sensitive actions (broadcast_alert)', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(245.0, SPEC_CONSTANTS.STAGES[5]);
      const modal = env.document.getElementById('hitl-confirmation-modal');
      assert(modal !== null && modal.classList.contains('modal-visible'), 'HITL modal visible at 245s');
    });

    test('T1.F20.5 - HITL modal contains Approve Action and Deny Action buttons', async () => {
      const approve = env.document.getElementById('hitl-approve-btn');
      const deny = env.document.getElementById('hitl-deny-btn');
      assert(approve !== null, 'Approve button exists');
      assert(deny !== null, 'Deny button exists');
    });

    // ========================================================================
    // F21: Seamless Playback Resumption
    // ========================================================================
    test('T1.F21.1 - Resuming playback from pause restores timeline clock at exact paused timestamp', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(180.0);
      engine.pause();
      engine.play();
      assertApprox(engine.currentTime, 180.0, 0.05, 'Preserved timestamp on play()');
    });

    test('T1.F21.2 - Audio playback resumes synchronously from paused timestamp', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const mgr = new AudioMgr();
      mgr.seek(180.0);
      mgr.pause();
      await mgr.play();
      assertApprox(mgr.getCurrentTime(), 180.0, 0.1, 'Audio resumes synchronously from 180s');
    });

    test('T1.F21.3 - Resuming resets sandbox drawer tab back to active timeline stage tab', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && TimelineEngine && Controller, 'Modules must load');

      const sim = new SceneSim();
      const engine = new TimelineEngine();
      engine.currentTime = 120.0;
      const ctrl = new Controller({ sceneSimulator: sim, timelineEngine: engine });

      ctrl.onPause();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit');
      ctrl.onResume();
      assertEqual(sim.activeTab, 'react', 'Restored to react tab');
    });

    test('T1.F21.4 - Resuming re-anchors event card stream scroll position to current step', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && TimelineEngine && Controller, 'Modules must load');

      const sim = new SceneSim();
      const engine = new TimelineEngine();
      const ctrl = new Controller({ sceneSimulator: sim, timelineEngine: engine });

      sim.update(120.0, SPEC_CONSTANTS.STAGES[2]);
      ctrl.onPause();
      ctrl.onResume();
      assertEqual(ctrl.isSandboxActive, false, 'Sandbox deactivated on resume');
      assertEqual(sim.isPausedByUser, false, 'Scene pause flag reset');
    });

    test('T1.F21.5 - Resumption feedback/toast notice informs viewer of automated continuation', async () => {
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(Controller, 'InteractiveController must load');

      const ctrl = new Controller({});
      ctrl._showToast('Test Toast', 'info');
      const toast = env.document.getElementById('player-toast');
      assert(toast !== null, 'Player toast element exists');
      assert(toast.classList.contains('toast-show'), 'Toast has toast-show class');
    });

    // ========================================================================
    // F22: Standalone Local Bundle
    // ========================================================================
    test('T1.F22.1 - index.html exists and contains valid HTML5 structure and UTF-8 charset', () => {
      assert(fileExistsInPlayer('index.html'), 'index.html must exist');
      const html = readPlayerFile('index.html');
      assertIncludes(html.toLowerCase(), '<!doctype html>', 'Has doctype html');
      assertIncludes(html.toLowerCase(), 'utf-8', 'Has UTF-8 charset');
    });

    test('T1.F22.2 - CSS stylesheets (base.css, simulator.css, player_controls.css) exist and contain styles', () => {
      ['css/base.css', 'css/simulator.css', 'css/player_controls.css'].forEach((p) => {
        assert(fileExistsInPlayer(p), `${p} must exist`);
        const css = readPlayerFile(p);
        assert(css.length > 0, `${p} should not be empty`);
      });
    });

    test('T1.F22.3 - Zero external cloud/CDN dependencies in script/link tags', () => {
      assert(fileExistsInPlayer('index.html'), 'index.html must exist');
      const html = readPlayerFile('index.html');
      assert(!html.includes('https://cdn.'), 'No external CDN links in index.html');
      assert(!html.includes('https://unpkg.com'), 'No unpkg links in index.html');
      assert(!html.includes('https://cdnjs.'), 'No cdnjs links in index.html');
    });

    test('T1.F22.4 - presentationData.js defines embedded PEOPLEPULSE_PRESENTATION_DATA for file:/// support', async () => {
      assert(fileExistsInPlayer('js/presentationData.js'), 'presentationData.js must exist');
      const code = readPlayerFile('js/presentationData.js');
      assertIncludes(code, 'PEOPLEPULSE_PRESENTATION_DATA', 'Bundles PEOPLEPULSE_PRESENTATION_DATA directly');
    });

    test('T1.F22.5 - Local asset references use relative paths', () => {
      assert(fileExistsInPlayer('index.html'), 'index.html must exist');
      const html = readPlayerFile('index.html');
      assert(!html.includes('http://'), 'No hardcoded http:// paths in index.html');
    });

    // ========================================================================
    // F23: Narration Audio Generator Scripts
    // ========================================================================
    test('T1.F23.1 - Python Edge-TTS script scripts/generate_audio_edgetts.py exists', () => {
      assert(fileExistsInPlayer('scripts/generate_audio_edgetts.py'), 'generate_audio_edgetts.py must exist');
    });

    test('T1.F23.2 - PowerShell SAPI script scripts/generate_audio_sapi.ps1 exists', () => {
      assert(fileExistsInPlayer('scripts/generate_audio_sapi.ps1'), 'generate_audio_sapi.ps1 must exist');
    });

    test('T1.F23.3 - Edge-TTS script specifies en-US-ChristopherNeural voice and target rate/pitch', () => {
      const code = readPlayerFile('scripts/generate_audio_edgetts.py');
      assertIncludes(code, 'en-US-ChristopherNeural', 'Specifies Christopher voice');
    });

    test('T1.F23.4 - Generator script generates both audio and subtitle cues (subtitles.json)', () => {
      const code = readPlayerFile('scripts/generate_audio_edgetts.py');
      assertIncludes(code, 'subtitles.json', 'Generates subtitles.json');
      assertIncludes(code, 'narration_full.mp3', 'Generates narration_full.mp3');
    });

    test('T1.F23.5 - SAPI script contains fallback speech synthesis logic using System.Speech.Synthesis', () => {
      const code = readPlayerFile('scripts/generate_audio_sapi.ps1');
      assertIncludes(code, 'System.Speech.Synthesis', 'Uses System.Speech.Synthesis');
    });

    // ========================================================================
    // F24: Headless Verification Harness
    // ========================================================================
    test('T1.F24.1 - Verification script scripts/verify_player.mjs exists', () => {
      assert(fileExistsInPlayer('scripts/verify_player.mjs'), 'verify_player.mjs must exist');
      const code = readPlayerFile('scripts/verify_player.mjs');
      assert(code.length > 0, 'verify_player.mjs must not be empty');
    });

    test('T1.F24.2 - Harness validates DOM readyState === complete and index.html loading', () => {
      const indexPath = path.resolve(PLAYER_ROOT, 'index.html');
      assert(fs.existsSync(indexPath), 'index.html exists');
      const content = fs.readFileSync(indexPath, 'utf8');
      assert(content.length > 5000, 'index.html is complete and substantial');
    });

    test('T1.F24.3 - Harness checks for zero runtime console errors and zero uncaught exceptions', () => {
      const verifyScript = fs.readFileSync(path.resolve(PLAYER_ROOT, 'scripts/verify_player.mjs'), 'utf8');
      assertIncludes(verifyScript, 'pageErrors', 'verify_player checks page errors');
    });

    test('T1.F24.4 - Harness validates timeline progression across all 6 stage checkpoints', () => {
      const verifyScript = fs.readFileSync(path.resolve(PLAYER_ROOT, 'scripts/verify_player.mjs'), 'utf8');
      assertIncludes(verifyScript, 'checkpoints', 'verify_player validates stage checkpoints');
    });

    test('T1.F24.5 - Harness returns exit code 0 on complete pass, non-zero on failure', () => {
      const runScript = fs.readFileSync(path.resolve(PLAYER_ROOT, 'scripts/run_tests.mjs'), 'utf8');
      assertIncludes(runScript, 'process.exit', 'run_tests sets exit code');
    });
  });
}
