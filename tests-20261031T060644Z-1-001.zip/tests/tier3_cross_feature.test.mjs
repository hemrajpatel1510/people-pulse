// Tier 3: Cross-Feature Combinations Test Suite
// 24 pairwise interaction test cases with genuine assertion logic
// Verifies pairwise integration and state synchronization across player subsystems.

import {
  assert,
  assertEqual,
  assertDeepEqual,
  assertApprox,
  assertIncludes,
  SPEC_CONSTANTS,
  createMockEnvironment,
  loadPlayerModule,
  readPlayerFile,
  fileExistsInPlayer
} from './harness.mjs';

export function registerTier3Tests(runner) {
  runner.describe('Tier 3: Cross-Feature Combinations (Pairwise)', ({ test, beforeEach }) => {
    let env;

    beforeEach(() => {
      env = createMockEnvironment();
    });

    // ------------------------------------------------------------------------
    // T3.01: F01 (Timeline) + F03 (Speed Multiplier)
    // ------------------------------------------------------------------------
    test('T3.01: F01+F03 - 1.5x speed during Stage 1 accelerates clock tick proportionally', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine module must load');

      const engine = new Engine({ mode: 'synthetic' });
      engine.setSpeed(1.5);
      assertEqual(engine.speed, 1.5, 'Speed must be set to 1.5x');

      // Simulate a tick of 100ms at 1.5x speed
      const deltaSec = (100 / 1000.0) * engine.speed;
      assertApprox(deltaSec, 0.15, 0.001, '100ms delta at 1.5x must advance by 0.15s');
    });

    // ------------------------------------------------------------------------
    // T3.02: F01 (Timeline) + F04 (Stage Jump Markers)
    // ------------------------------------------------------------------------
    test('T3.02: F01+F04 - Seeking via jump marker to Stage 3 correctly updates stage index, cards, and time', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine module must load');

      const engine = new Engine();
      engine.jumpToStage(2); // Stage 3: Action Execution (starts at 90.0s)
      assertApprox(engine.getCurrentTime(), 90.05, 0.1, 'Current time must jump to Stage 3 start');
      const stage = engine.getStageForTime(engine.currentTime).stage;
      assertEqual(stage.id, 3, 'Stage id must be 3 (Action)');
      assertIncludes(stage.name.toLowerCase(), 'action', 'Stage name must be Action');
    });

    // ------------------------------------------------------------------------
    // T3.03: F01 (Timeline) + F07 (Audio Controls)
    // ------------------------------------------------------------------------
    test('T3.03: F01+F07 - Muting audio does not halt monotonic timeline advancement', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioMgr, 'TimelineEngine and AudioManager must load');

      const audio = new AudioMgr();
      const engine = new Engine({ audioManager: audio });
      audio.toggleMute();
      assert(audio.isMuted(), 'Audio should be muted');

      engine.play();
      assert(engine.isPlaying, 'Timeline must be playing even when audio is muted');
      engine.seek(15.0);
      assertApprox(engine.getCurrentTime(), 15.0, 0.05, 'Seeking must work while muted');
    });

    // ------------------------------------------------------------------------
    // T3.04: F01 (Timeline) + F08 (High-Contrast Live Subtitles)
    // ------------------------------------------------------------------------
    test('T3.04: F01+F08 - Advancing timeline keeps subtitle cue and stage indicator in exact synchronization', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');
      assert(data?.cues && data.cues.length >= 20, 'Presentation cues must be bundled');

      const textEl = env.document.getElementById('subtitle-text');
      const stageTagEl = env.document.getElementById('subtitle-stage-tag');
      const renderer = new SubRenderer({ textEl, stageTagEl });
      renderer.loadCues(data.cues);

      renderer.update(50.0); // Inside Stage 2 Decision
      const cue = renderer.getActiveCue(50.0);
      assert(cue !== null, 'Active cue at 50s must exist');
      assert(cue.stageId === 2 || cue.stageName?.toLowerCase().includes('decision'), 'Stage indicator matches Decision');
      assert(textEl.textContent.length > 0, 'Subtitle text is rendered');
      assertIncludes(textEl.innerHTML, 'caption-token', 'Caption tokens must be rendered');
    });

    // ------------------------------------------------------------------------
    // T3.05: F01 (Timeline) + F11 (Admin Dashboard Mockup)
    // ------------------------------------------------------------------------
    test('T3.05: F01+F11 - Stage 1 timeline rendering synchronizes dashboard KPI cards', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(20.0, SPEC_CONSTANTS.STAGES[0]);

      const kpiContainer = env.document.getElementById('dashboard-kpi-grid');
      assert(kpiContainer !== null, 'KPI grid container exists');
      const kpiCards = env.document.querySelectorAll('.kpi-card');
      assert(kpiCards.length >= 4, 'At least 4 KPI metric cards rendered');
      assertIncludes(kpiContainer.innerHTML, '248', 'Total Employees KPI rendered');
      assertIncludes(kpiContainer.innerHTML, '68%', 'Wellbeing score rendered');
    });

    // ------------------------------------------------------------------------
    // T3.06: F01 (Timeline) + F12 (Sliding PulseAgent Drawer)
    // ------------------------------------------------------------------------
    test('T3.06: F01+F12 - Crossing 45s threshold triggers drawer slide-in animation', async () => {
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(30.0, SPEC_CONSTANTS.STAGES[0]);
      assertEqual(sim.isDrawerOpen, false, 'Drawer closed in Stage 1 (< 45s)');

      sim.update(46.0, SPEC_CONSTANTS.STAGES[1]);
      assertEqual(sim.isDrawerOpen, true, 'Drawer opens when entering Stage 2 (>= 45s)');
    });

    // ------------------------------------------------------------------------
    // T3.07: F01 (Timeline) + F13 (Streaming ODAEA Event Cards)
    // ------------------------------------------------------------------------
    test('T3.07: F01+F13 - Event cards appear sequentially as timeline crosses respective timestamps', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(96.0, SPEC_CONSTANTS.STAGES[2]); // Goal card renders at 95s
      const cardsEarly = env.document.querySelectorAll('.event-card');

      sim.update(135.0, SPEC_CONSTANTS.STAGES[2]); // Additional cards render
      const cardsLate = env.document.querySelectorAll('.event-card');
      assert(cardsLate.length > cardsEarly.length, 'Card count must grow monotonically over timeline');
    });

    // ------------------------------------------------------------------------
    // T3.08: F01 (Timeline) + F14 (Orange HTTP 503 Interception)
    // ------------------------------------------------------------------------
    test('T3.08: F01+F14 - Crossing 160s-175s triggers orange failure card and adaptation state', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(SceneSim, 'SceneSimulator must load');

      const sim = new SceneSim();
      sim.update(180.0, SPEC_CONSTANTS.STAGES[4]); // Stage 5: Adaptation (ev_fail_1 at 175s)

      const failureCard = env.document.getElementById('card-ev_fail_1');
      assert(failureCard !== null, 'Failure adaptation card rendered in Stage 5');
      assert(failureCard.classList.contains('card-adaptation-hero'), 'Has card-adaptation-hero class');
      assert(failureCard.classList.contains('pulse-orange-border'), 'Has pulse-orange-border class');
    });

    // ------------------------------------------------------------------------
    // T3.09: F02 (Transport) + F06 (Voiceover Narration)
    // ------------------------------------------------------------------------
    test('T3.09: F02+F06 - Pausing playback pauses audio narration without resetting audio currentTime', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const audio = new AudioMgr();
      audio.seek(75.0);
      assertApprox(audio.getCurrentTime(), 75.0, 0.1, 'Seek sets audio timestamp');
      audio.pause();
      assertApprox(audio.getCurrentTime(), 75.0, 0.1, 'Pause preserves audio timestamp');
      assertEqual(audio.audioElement.paused, true, 'Audio element must be paused');
    });

    // ------------------------------------------------------------------------
    // T3.10: F02 (Transport) + F17 (Live-Pause Sandbox)
    // ------------------------------------------------------------------------
    test('T3.10: F02+F17 - Pause enables sandbox clickability; play restores automation', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(TimelineEngine && SceneSim && Controller, 'All modules must load');

      const engine = new TimelineEngine();
      const scene = new SceneSim();
      const ctrl = new Controller({ timelineEngine: engine, sceneSimulator: scene });

      engine.seek(100.0);
      engine.pause();
      ctrl.onPause();
      assertEqual(ctrl.isSandboxActive, true, 'Sandbox active on pause');

      ctrl.onResume();
      engine.play();
      assertEqual(ctrl.isSandboxActive, false, 'Sandbox disabled on play');
    });

    // ------------------------------------------------------------------------
    // T3.11: F02 (Transport) + F21 (Seamless Playback Resumption)
    // ------------------------------------------------------------------------
    test('T3.11: F02+F21 - Play -> Pause -> User clicks around -> Play resumes from exact paused second', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(TimelineEngine && SceneSim && Controller, 'Modules must load');

      const engine = new TimelineEngine();
      const scene = new SceneSim();
      const ctrl = new Controller({ timelineEngine: engine, sceneSimulator: scene });

      engine.seek(112.5);
      engine.pause();
      ctrl.onPause();
      const pauseT = engine.getCurrentTime();

      // User interacts in sandbox
      scene.switchTab('audit', true);

      // Resuming presentation
      ctrl.onResume();
      engine.play();
      assertApprox(engine.getCurrentTime(), pauseT, 0.01, 'Current time perfectly preserved across sandbox interaction');
      assertEqual(engine.isPlaying, true, 'Engine playing');
    });

    // ------------------------------------------------------------------------
    // T3.12: F03 (Speed Multiplier) + F06 (Voiceover Narration)
    // ------------------------------------------------------------------------
    test('T3.12: F03+F06 - Switching speed to 1.25x updates audio.playbackRate and preserves pitch', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const audio = new AudioMgr();
      audio.setRate(1.25);
      assertEqual(audio.audioElement.playbackRate, 1.25, 'playbackRate updated to 1.25');
      assertEqual(audio.audioElement.preservesPitch, true, 'preservesPitch must remain true');
    });

    // ------------------------------------------------------------------------
    // T3.13: F03 (Speed Multiplier) + F09 (Word/Phrase Synchronization)
    // ------------------------------------------------------------------------
    test('T3.13: F03+F09 - 1.5x speed accelerates word-by-word karaoke highlight timing proportionally', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioManager = audioMod?.AudioManager || env.window.AudioManager;
      assert(SubRenderer && TimelineEngine && AudioManager, 'Required modules must load');

      const audio = new AudioManager();
      const engine = new TimelineEngine({ audioManager: audio });
      engine.setSpeed(1.5);
      assertEqual(engine.speed, 1.5, 'Engine speed set to 1.5x');
      assertEqual(audio.rate, 1.5, 'Audio rate matches 1.5x');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl });
      renderer.loadCues([
        {
          id: 'test_cue',
          start: 0.0,
          end: 10.0,
          text: 'Word1 Word2 Word3',
          tokens: [
            { text: 'Word1', start: 0.0, end: 1.0 },
            { text: 'Word2', start: 1.0, end: 2.0 },
            { text: 'Word3', start: 2.0, end: 3.0 }
          ]
        }
      ]);

      // At 1.5x rate, an elapsed wall-clock interval of 1.0s corresponds to 1.5s in presentation time
      const elapsedWallSec = 1.0;
      const presentationTime = elapsedWallSec * engine.speed; // 1.5s
      renderer.update(presentationTime);

      const activeToken = textEl.querySelector('.token-active');
      assert(activeToken !== null, 'Word token must be illuminated as token-active');
      assertEqual(activeToken.textContent.trim(), 'Word2', 'Word2 should be active at 1.5s');
    });

    // ------------------------------------------------------------------------
    // T3.14: F04 (Stage Jump Markers) + F08 (Live Subtitles)
    // ------------------------------------------------------------------------
    test('T3.14: F04+F08 - Jumping to Stage 5 immediately renders Stage 5 subtitle cue', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(SubRenderer && TimelineEngine, 'Modules must load');
      assert(data?.cues && data.cues.length >= 20, 'Cues must be bundled');

      const engine = new TimelineEngine();
      engine.jumpToStage(4); // Stage 5: Adaptation (starts at 160.0s)
      assertApprox(engine.getCurrentTime(), 160.05, 0.1, 'Jumped to Stage 5');

      const textEl = env.document.getElementById('subtitle-text');
      const stageTagEl = env.document.getElementById('subtitle-stage-tag');
      const renderer = new SubRenderer({ textEl, stageTagEl, cues: data.cues });
      renderer.update(engine.getCurrentTime());

      const cue = renderer.getActiveCue(engine.getCurrentTime());
      assert(cue !== null, 'Cue at Stage 5 start must exist');
      assert(cue.stageId === 5 || cue.stageName?.toLowerCase().includes('adapt'), 'Cue must belong to Adaptation stage');
    });

    // ------------------------------------------------------------------------
    // T3.15: F04 (Stage Jump Markers) + F12 (Sliding PulseAgent Drawer)
    // ------------------------------------------------------------------------
    test('T3.15: F04+F12 - Jumping from Stage 1 to Stage 4 opens drawer and sets active breadcrumb to Evaluation', async () => {
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(SceneSim && TimelineEngine, 'Modules must load');

      const engine = new TimelineEngine();
      const sim = new SceneSim();

      // Start in Stage 1
      sim.update(20.0, SPEC_CONSTANTS.STAGES[0]);
      assertEqual(sim.isDrawerOpen, false, 'Drawer closed in Stage 1');

      // Jump to Stage 4 (Dynamic Evaluation, starts at 134.0s)
      engine.jumpToStage(3);
      sim.update(engine.getCurrentTime(), SPEC_CONSTANTS.STAGES[3]);
      assertEqual(sim.isDrawerOpen, true, 'Drawer opened upon jumping to Stage 4');
    });

    // ------------------------------------------------------------------------
    // T3.16: F06 (Voiceover Narration) + F07 (Audio Controls)
    // ------------------------------------------------------------------------
    test('T3.16: F06+F07 - Adjusting volume slider changes audio element volume without stopping narration', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const audio = new AudioMgr();
      await audio.play();
      audio.setVolume(0.4);
      assertApprox(audio.getVolume(), 0.4, 0.05, 'Volume set to 0.4');
      assertEqual(audio.audioElement.paused, false, 'Narration must not stop when adjusting volume');
    });

    // ------------------------------------------------------------------------
    // T3.17: F06 (Voiceover) + F10 (Dual-Mode Clock Fallback)
    // ------------------------------------------------------------------------
    test('T3.17: F06+F10 - Audio master clock drift correction continuously nudges visual clock to audio currentTime', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioManager = audioMod?.AudioManager || env.window.AudioManager;
      assert(TimelineEngine && AudioManager, 'Modules must load');

      const audio = new AudioManager();
      const engine = new TimelineEngine({ audioManager: audio });

      // Setup playing state and audio master clock
      engine.isPlaying = true;
      engine.currentTime = 50.0;
      engine._lastSeekPerf = 0; // Past seek settling window (> 500ms)
      audio.audio.currentTime = 50.15; // 150ms drift ahead
      audio.audio.paused = false;

      // Soft sync drift correction
      const now = performance.now() + 1000;
      engine.syntheticClock.lastPerfTime = now - 16.67;
      engine._onAnimationFrame(now);

      // Verify visual clock moved forward by frame delta plus fractional drift nudge
      assert(engine.currentTime > 50.0 + 0.016, 'Visual clock nudged forward by drift compensation');

      // Hard sync on large frame hitch (> 0.3s)
      audio.audio.currentTime = 52.0; // 1.9s drift
      engine.syntheticClock.lastPerfTime = now;
      engine._onAnimationFrame(now + 16.67);
      assertEqual(engine.currentTime, 52.0, 'Hard sync snaps visual clock directly to master audio time on large drift');
    });

    // ------------------------------------------------------------------------
    // T3.18: F08 (Live Subtitles) + F09 (Word/Phrase Synchronization)
    // ------------------------------------------------------------------------
    test('T3.18: F08+F09 - Active sentence displays active word token with .token-active class', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl });
      renderer.loadCues([
        {
          id: 'cue_01',
          start: 0.0,
          end: 6.0,
          text: 'Tech Zephyr Hackathon Presentation',
          tokens: [
            { text: 'Tech', start: 0.0, end: 1.0 },
            { text: 'Zephyr', start: 1.0, end: 2.5 },
            { text: 'Hackathon', start: 2.5, end: 4.5 },
            { text: 'Presentation', start: 4.5, end: 6.0 }
          ]
        }
      ]);

      renderer.update(2.0); // Inside "Zephyr" token
      assertIncludes(textEl.innerHTML, 'token-active', 'Must include token-active class');
      const activeEl = textEl.querySelector('.token-active');
      assert(activeEl !== null, 'Active word token element exists in DOM');
      assertEqual(activeEl.textContent.trim(), 'Zephyr', 'Active word is Zephyr');

      renderer.update(3.0); // Inside "Hackathon" token
      const nextActive = textEl.querySelector('.token-active');
      assert(nextActive !== null, 'New active word exists');
      assertEqual(nextActive.textContent.trim(), 'Hackathon', 'Active word transitioned to Hackathon');
    });

    // ------------------------------------------------------------------------
    // T3.19: F12 (Sliding Drawer) + F19 (PulseAgent Drawer Tabs)
    // ------------------------------------------------------------------------
    test('T3.19: F12+F19 - In open drawer, switching to Tools Registry renders registered schema tools', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const sim = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: sim });

      sim.update(60.0, SPEC_CONSTANTS.STAGES[1]); // Drawer open in Stage 2
      assertEqual(sim.isDrawerOpen, true, 'Drawer is open');

      ctrl.sceneSimulator.switchTab('tools');
      assertEqual(sim.activeTab, 'tools', 'Tab switched to tools');
      const toolsList = env.document.getElementById('tools-registry-list');
      assert(toolsList !== null, 'Tools list element exists');
      assertIncludes(toolsList.innerHTML, 'tool-card', 'Tools list rendered tool cards');
    });

    // ------------------------------------------------------------------------
    // T3.20: F13 (ODAEA Event Cards) + F18 (JSON Payload Inspector)
    // ------------------------------------------------------------------------
    test('T3.20: F13+F18 - Clicking JSON details on Stage 3 Action card reveals server-injected organization_id', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must be present');

      const actionCard = data.eventStream.find((c) => c.stage === 3 || c.type === 'action');
      assert(actionCard !== undefined, 'Stage 3 Action event card must exist');
      assert(actionCard.details !== undefined, 'Action card must have details');
      const params = actionCard.details.injected_parameters;
      assert(params !== undefined, 'injected_parameters must exist on action card');
      assertEqual(params.organization_id, 'org_acme_enterprise_9921', 'Payload contains verified tenant org_acme_enterprise_9921');
      assertEqual(params.time_window_days, 30, 'Payload contains time_window_days: 30');
    });

    // ------------------------------------------------------------------------
    // T3.21: F14 (Orange 503) + F15 (Emergency Queue Reroute Card)
    // ------------------------------------------------------------------------
    test('T3.21: F14+F15 - Following HTTP 503 failure card, emergency fallback card renders at ~205s with zero message loss', async () => {
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      assert(data?.eventStream, 'eventStream must be defined');

      const failCard = data.eventStream.find((c) => c.id === 'ev_fail_1');
      const adaptCard = data.eventStream.find((c) => c.id === 'ev_act_2');
      assert(failCard !== undefined, 'Failure event card must exist');
      assert(adaptCard !== undefined, 'Adaptation fallback card must exist');

      assertEqual(failCard.details?.error_code, 503, 'Error code 503 in failure details');
      assertEqual(adaptCard.details?.tool, 'send_emergency_notification', 'Fallback tool matches');
      assertEqual(adaptCard.details?.delivery_channel, 'emergency_in_app_queue', 'Fallback channel matches');
      assertEqual(adaptCard.details?.message_loss, '0%', 'Message loss is guaranteed 0%');
    });

    // ------------------------------------------------------------------------
    // T3.22: F17 (Live-Pause Sandbox) + F19 (PulseAgent Drawer Tabs)
    // ------------------------------------------------------------------------
    test('T3.22: F17+F19 - Switching to Audit Trail tab during live pause displays credential-masked logs', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const sim = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: sim });

      ctrl.onPause();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit', 'Audit tab is active');
      const tableBody = env.document.getElementById('audit-table-body');
      assert(tableBody !== null, 'Audit table body exists');
      assertIncludes(tableBody.innerHTML, '[MASKED]', 'Audit logs mask credentials');
    });

    // ------------------------------------------------------------------------
    // T3.23: F17+F20 - Clicking Approve Action or Deny Action in sandbox executes governance handler
    // ------------------------------------------------------------------------
    test('T3.23: F17+F20 - Clicking Approve Action or Deny Action in sandbox executes governance handler', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const sim = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: sim });

      // Trigger modal at 245s
      ctrl.onPause();
      sim.update(245.0, SPEC_CONSTANTS.STAGES[5]);
      const modal = env.document.getElementById('hitl-confirmation-modal');
      assert(modal !== null, 'HITL modal element exists');
      assert(modal.classList.contains('modal-visible'), 'Modal is visible at 245s');

      // Click Approve Action
      const approveBtn = env.document.getElementById('hitl-approve-btn');
      assert(approveBtn !== null, 'Approve button exists');
      approveBtn.click();
      assertEqual(modal.classList.contains('modal-visible'), false, 'Modal closed after approval');
    });

    // ------------------------------------------------------------------------
    // T3.24: F21 (Resumption) + F19 (PulseAgent Drawer Tabs)
    // ------------------------------------------------------------------------
    test('T3.24: F21+F19 - Resuming playback after viewing Audit tab switches active tab back to ReAct Copilot trace', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const TimelineEngine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && TimelineEngine && Controller, 'Modules must load');

      const sim = new SceneSim();
      const engine = new TimelineEngine();
      engine.currentTime = 120.0; // Stage 3 Action
      const ctrl = new Controller({ sceneSimulator: sim, timelineEngine: engine });

      ctrl.onPause();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit', 'Switched to audit');

      ctrl.onResume();
      assertEqual(sim.activeTab, 'react', 'Restored to react on resume');
    });
  });
}
