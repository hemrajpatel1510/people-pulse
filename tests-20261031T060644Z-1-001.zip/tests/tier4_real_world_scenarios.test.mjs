// Tier 4: Real-World Application Scenarios Test Suite
// Minimum 12 end-to-end integration scenarios
// Verifies full realistic user journeys, judge interactions, and complex flows.

import {
  assert,
  assertEqual,
  assertDeepEqual,
  assertApprox,
  assertIncludes,
  SPEC_CONSTANTS,
  createMockEnvironment,
  loadPlayerModule,
  readPlayerFile,
  fileExistsInPlayer
} from './harness.mjs';

export function registerTier4Tests(runner) {
  runner.describe('Tier 4: Real-World Application Scenarios', ({ test, beforeEach }) => {
    let env;

    beforeEach(() => {
      env = createMockEnvironment();
    });

    // ------------------------------------------------------------------------
    // Scenario 1: Full 5-Minute Uninterrupted Playback Run
    // ------------------------------------------------------------------------
    test('Scenario 1: Full 5-Minute Uninterrupted Playback Run from 0s to 300s', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine({ mode: 'synthetic' });
      engine.play();
      assertEqual(engine.isPlaying, true, 'Engine must be playing');

      // Sample checkpoints across all 6 stages
      const checkpoints = [15.0, 60.0, 110.0, 145.0, 190.0, 260.0, 300.0];
      for (const t of checkpoints) {
        engine.seek(t);
        assertApprox(engine.getCurrentTime(), t, 0.1, `Current time at checkpoint ${t}s`);
      }
      assertEqual(engine.isCompleted, true, 'Engine completed at 300s');
    });

    // ------------------------------------------------------------------------
    // Scenario 2: Judge Scrubbing & Stage Jump Exploration
    // ------------------------------------------------------------------------
    test('Scenario 2: Judge Scrubbing & Stage Jump Exploration across stages', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      // Jump to Adaptation (Stage 5)
      engine.jumpToStage(4);
      assertApprox(engine.getCurrentTime(), 160.0, 0.1, 'Jump to Adaptation');

      // Jump back to Goal (Stage 1)
      engine.jumpToStage(0);
      assertApprox(engine.getCurrentTime(), 0.0, 0.1, 'Jump back to Goal');

      // Jump to Outcome (Stage 6)
      engine.jumpToStage(5);
      assertApprox(engine.getCurrentTime(), 225.0, 0.1, 'Jump to Outcome');
    });

    // ------------------------------------------------------------------------
    // Scenario 3: Live-Pause at HTTP 503 Failure & JSON Inspection
    // ------------------------------------------------------------------------
    test('Scenario 3: Live-Pause at HTTP 503 Failure & Deep JSON Inspection', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      assert(Engine && Controller && SceneSim, 'Modules must load');

      const engine = new Engine();
      const scene = new SceneSim();
      const ctrl = new Controller({ timelineEngine: engine, sceneSimulator: scene });

      // Seek to failure event at 175s
      engine.seek(175.0);
      engine.pause();
      ctrl.onPause();
      assertEqual(ctrl.isSandboxActive, true, 'Sandbox mode active');

      // Inspect payload details
      ctrl.togglePayload('ev_fail_1');
      assert(ctrl.expandedCardDetails.has('ev_fail_1'), 'Failure payload expanded in sandbox');

      // Resume presentation
      ctrl.onResume();
      engine.play();
      assertApprox(engine.getCurrentTime(), 175.0, 0.1, 'Preserved timestamp on resume');
      assertEqual(ctrl.isSandboxActive, false, 'Sandbox mode deactivated on resume');
    });

    // ------------------------------------------------------------------------
    // Scenario 4: Rapid Speed Toggling (1x -> 1.5x -> 1.25x -> 1x) with Audio
    // ------------------------------------------------------------------------
    test('Scenario 4: Rapid Speed Toggling (1x -> 1.5x -> 1.25x -> 1x) with audio synchronization', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(Engine && AudioMgr, 'Modules must load');

      const audio = new AudioMgr();
      const engine = new Engine({ audioManager: audio });

      const speeds = [1.5, 1.25, 1.0];
      for (const spd of speeds) {
        engine.setSpeed(spd);
        assertEqual(engine.speed, spd, `Engine speed matches ${spd}`);
        assertEqual(audio.audioElement.playbackRate, spd, `Audio playbackRate matches ${spd}`);
      }
    });

    // ------------------------------------------------------------------------
    // Scenario 5: Audit Trail & HITL Modal Interaction During Pause
    // ------------------------------------------------------------------------
    test('Scenario 5: Audit Trail & HITL Confirmation Governance Flow during pause', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const sim = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: sim });

      ctrl.onPause();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit', 'Switched to audit tab in pause');

      // Check modal trigger and dismissal
      sim.update(245.0, SPEC_CONSTANTS.STAGES[5]);
      const modal = env.document.getElementById('hitl-confirmation-modal');
      assert(modal !== null && modal.classList.contains('modal-visible'), 'HITL modal visible at 245s');

      const denyBtn = env.document.getElementById('hitl-deny-btn');
      assert(denyBtn !== null, 'Deny button exists');
      denyBtn.click();
      assertEqual(modal.classList.contains('modal-visible'), false, 'Modal closed after denial');
    });

    // ------------------------------------------------------------------------
    // Scenario 6: Subtitle Highlighting & Speech-Text Synchronization Check
    // ------------------------------------------------------------------------
    test('Scenario 6: Word-by-Word Karaoke Subtitle Alignment Verification across 6 checkpoints', async () => {
      const subMod = await loadPlayerModule('js/subtitleRenderer.js', env);
      const dataMod = await loadPlayerModule('js/presentationData.js', env);
      const data = dataMod?.PEOPLEPULSE_PRESENTATION_DATA || env.window.PEOPLEPULSE_PRESENTATION_DATA;
      const SubRenderer = subMod?.SubtitleRenderer || env.window.SubtitleRenderer;
      assert(SubRenderer, 'SubtitleRenderer must load');
      assert(data?.cues && data.cues.length >= 20, 'Pitch script cues must exist');

      const textEl = env.document.getElementById('subtitle-text');
      const renderer = new SubRenderer({ textEl, cues: data.cues });

      const sampleTimes = [4.0, 50.0, 100.0, 140.0, 180.0, 250.0];
      for (const t of sampleTimes) {
        const cue = renderer.getActiveCue(t);
        assert(cue !== null, `Active cue at ${t}s must exist`);
        assert(cue.text.length > 0, `Cue at ${t}s must have non-empty text`);
        renderer.update(t);
        assert(textEl.textContent.length > 0, `Rendered text at ${t}s`);
      }
    });

    // ------------------------------------------------------------------------
    // Scenario 7: Offline / Silent Fallback Clock Mode Verification
    // ------------------------------------------------------------------------
    test('Scenario 7: Offline / Silent Fallback Synthetic Clock Mode Verification', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine({ mode: 'synthetic' });
      engine.play();
      engine.seek(50.0);
      assertApprox(engine.getCurrentTime(), 50.0, 0.05, 'Seek in synthetic clock mode');
      assertEqual(engine.isPlaying, true, 'Engine playing in synthetic mode');
    });

    // ------------------------------------------------------------------------
    // Scenario 8: Drawer Tab Switching and Payload Collapsing in Pause
    // ------------------------------------------------------------------------
    test('Scenario 8: Drawer Tab Switching (Copilot -> Audit -> Tools -> Copilot) during pause', async () => {
      await loadPlayerModule('js/presentationData.js', env);
      const sceneMod = await loadPlayerModule('js/sceneSimulator.js', env);
      const ctrlMod = await loadPlayerModule('js/interactiveController.js', env);
      const SceneSim = sceneMod?.SceneSimulator || env.window.SceneSimulator;
      const Controller = ctrlMod?.InteractiveController || env.window.InteractiveController;
      assert(SceneSim && Controller, 'Modules must load');

      const sim = new SceneSim();
      const ctrl = new Controller({ sceneSimulator: sim });

      ctrl.onPause();
      sim.switchTab('audit');
      assertEqual(sim.activeTab, 'audit', 'Switched to audit');

      sim.switchTab('tools');
      assertEqual(sim.activeTab, 'tools', 'Switched to tools');

      sim.switchTab('react');
      assertEqual(sim.activeTab, 'react', 'Switched back to react');
    });

    // ------------------------------------------------------------------------
    // Scenario 9: Audio Controls (Mute / Unmute & Volume) Across Stages
    // ------------------------------------------------------------------------
    test('Scenario 9: Audio Controls (Mute / Unmute & Volume) operations across stages', async () => {
      const audioMod = await loadPlayerModule('js/audioManager.js', env);
      const AudioMgr = audioMod?.AudioManager || env.window.AudioManager;
      assert(AudioMgr, 'AudioManager must load');

      const audio = new AudioMgr();
      audio.setVolume(0.5);
      audio.seek(45.0); // Stage 2
      audio.toggleMute(); // Mute in Stage 2
      assertEqual(audio.isMuted(), true, 'Muted in Stage 2');

      audio.seek(140.0); // Stage 4
      audio.toggleMute(); // Unmute in Stage 4
      assertEqual(audio.isMuted(), false, 'Unmuted in Stage 4');
      assertApprox(audio.getVolume(), 0.5, 0.05, 'Volume preserved');
    });

    // ------------------------------------------------------------------------
    // Scenario 10: Standalone Local Bundle Execution (file:/// & Offline)
    // ------------------------------------------------------------------------
    test('Scenario 10: Standalone Local Bundle Execution (file:/// and offline zero-CDN check)', () => {
      assert(fileExistsInPlayer('index.html'), 'index.html must exist');
      const html = readPlayerFile('index.html');
      assert(!html.includes('https://cdn.'), 'Zero external CDN dependencies');
      assert(!html.includes('https://fonts.googleapis.com'), 'Zero external Google Fonts');
    });

    // ------------------------------------------------------------------------
    // Scenario 11: Stage Boundary Transition Consistency & Breadcrumb Sync
    // ------------------------------------------------------------------------
    test('Scenario 11: Stage Boundary Transition Consistency & Breadcrumb Lifecycle', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      const boundaries = [0, 45, 90, 134, 160, 225, 300];
      for (let i = 0; i < boundaries.length - 1; i++) {
        const midPoint = (boundaries[i] + boundaries[i + 1]) / 2;
        engine.seek(midPoint);
        const { stage, index } = engine.getStageForTime(midPoint);
        assertEqual(index, i, `Stage index at ${midPoint}s matches stage ${i}`);
        assertEqual(stage.id, i + 1, `Stage id matches ${i + 1}`);
      }
    });

    // ------------------------------------------------------------------------
    // Scenario 12: End-of-Timeline Replay and State Reset Verification
    // ------------------------------------------------------------------------
    test('Scenario 12: End-of-Timeline Replay and Full State Reset', async () => {
      const timelineMod = await loadPlayerModule('js/timelineEngine.js', env);
      const Engine = timelineMod?.TimelineEngine || env.window.TimelineEngine;
      assert(Engine, 'TimelineEngine must load');

      const engine = new Engine();
      engine.seek(300.0);
      assertEqual(engine.isCompleted, true, 'Engine marked completed at 300s');

      engine.restart();
      assertEqual(engine.getCurrentTime(), 0.0, 'restart resets to 0s');
      assertEqual(engine.isPlaying, true, 'restart restarts playback');
    });
  });
}
