// Empirical Stress Test Harness: Live-Pause Sandbox & Scene Simulator
// Challenger 2 (Live-Pause & Sandbox Interactive Verifier)
// Tech Zephyr 4.0 Hackathon Verification Suite

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

console.log('================================================================');
console.log(' CHALLENGER 2: LIVE-PAUSE SANDBOX & SCENE SIMULATOR STRESS TEST ');
console.log('================================================================\n');

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;
const findings = [];

function check(title, condition, detail = '') {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${title} ${detail ? '(' + detail + ')' : ''}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${title} ${detail ? '(' + detail + ')' : ''}`);
    findings.push({ title, detail, failed: true });
  }
}

// Minimal, robust DOM tree implementation for pure Node unit stress testing
class TestDOMElement {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase();
    this.id = '';
    this.className = '';
    this.style = {};
    this.dataset = {};
    this.children = [];
    this.parentElement = null;
    this.listeners = new Map();
    this.innerHTML = '';
    this.textContent = '';
    this.open = false;
  }

  get classList() {
    return {
      add: (...cls) => {
        const set = new Set(this.className.split(/\s+/).filter(Boolean));
        cls.forEach(c => c && set.add(c));
        this.className = Array.from(set).join(' ');
      },
      remove: (...cls) => {
        const set = new Set(this.className.split(/\s+/).filter(Boolean));
        cls.forEach(c => set.delete(c));
        this.className = Array.from(set).join(' ');
      },
      contains: (c) => new Set(this.className.split(/\s+/).filter(Boolean)).has(c)
    };
  }

  appendChild(child) {
    if (child.parentElement) {
      child.parentElement.removeChild(child);
    }
    child.parentElement = this;
    this.children.push(child);
    return child;
  }

  removeChild(child) {
    const idx = this.children.indexOf(child);
    if (idx !== -1) {
      this.children.splice(idx, 1);
      child.parentElement = null;
    }
    return child;
  }

  remove() {
    if (this.parentElement) {
      this.parentElement.removeChild(this);
    }
  }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }

  dispatchEvent(evt) {
    evt.target = this;
    const list = this.listeners.get(evt.type) || [];
    list.forEach(fn => fn.call(this, evt));
  }

  click() {
    this.dispatchEvent({ type: 'click' });
  }

  querySelector(sel) {
    const res = this.querySelectorAll(sel);
    return res.length > 0 ? res[0] : null;
  }

  querySelectorAll(sel) {
    const res = [];
    const traverse = (node) => {
      for (const child of node.children) {
        if (matches(child, sel)) res.push(child);
        traverse(child);
      }
    };
    traverse(this);
    return res;
  }
}

function matches(el, sel) {
  if (sel.startsWith('#')) return el.id === sel.slice(1);
  if (sel.startsWith('.')) {
    const classes = sel.slice(1).split('.');
    return classes.every(c => el.classList.contains(c));
  }
  if (sel.includes('[data-tab=')) {
    const m = sel.match(/\[data-tab=["']?([^"']+)["']?\]/);
    if (m) return el.dataset.tab === m[1];
  }
  return el.tagName.toLowerCase() === sel.toLowerCase();
}

function createDOMTree() {
  const root = new TestDOMElement('html');
  const body = new TestDOMElement('body');
  root.appendChild(body);

  const elementsById = new Map();

  function register(id, tag = 'div', parent = body) {
    const el = new TestDOMElement(tag);
    el.id = id;
    parent.appendChild(el);
    elementsById.set(id, el);
    return el;
  }

  const canvas = register('scene-canvas');
  const drawer = register('pulseagent-drawer', 'aside', canvas);
  const breadcrumbs = register('drawer-breadcrumbs-bar', 'div', drawer);
  for (let i = 1; i <= 6; i++) {
    const crumb = new TestDOMElement('div');
    crumb.className = 'rubric-crumb';
    crumb.dataset.stageId = String(i);
    breadcrumbs.appendChild(crumb);
  }

  const tabsHeader = register('drawer-tabs-header', 'div', drawer);
  ['react', 'audit', 'tools'].forEach(tab => {
    const btn = new TestDOMElement('button');
    btn.className = 'agent-tab-btn' + (tab === 'react' ? ' active-tab' : '');
    btn.dataset.tab = tab;
    tabsHeader.appendChild(btn);
  });

  const drawerBody = register('drawer-body', 'div', drawer);
  const paneReact = register('tab-pane-react', 'div', drawerBody);
  paneReact.className = 'drawer-tab-pane active-pane';
  register('agent-event-stream', 'div', paneReact);

  const paneAudit = register('tab-pane-audit', 'div', drawerBody);
  paneAudit.className = 'drawer-tab-pane';
  const table = new TestDOMElement('table');
  paneAudit.appendChild(table);
  register('audit-table-body', 'tbody', table);

  const paneTools = register('tab-pane-tools', 'div', drawerBody);
  paneTools.className = 'drawer-tab-pane';
  register('tools-registry-list', 'div', paneTools);

  register('sandbox-mode-indicator', 'div', canvas);
  register('floating-copilot-btn', 'button', canvas);
  register('close-drawer-btn', 'button', drawer);

  const hitlModal = register('hitl-confirmation-modal', 'div', canvas);
  register('hitl-approve-btn', 'button', hitlModal);
  register('hitl-deny-btn', 'button', hitlModal);

  register('developer-terminal-overlay', 'div', canvas);
  register('grand-finale-overlay', 'div', canvas);
  register('subtitle-overlay', 'div', canvas);
  register('subtitle-text', 'div', canvas);
  register('subtitle-stage-tag', 'span', canvas);
  register('player-toast', 'div', body);

  const document = {
    body,
    documentElement: root,
    createElement: (tag) => new TestDOMElement(tag),
    getElementById: (id) => elementsById.get(id) || root.querySelector('#' + id) || null,
    querySelector: (sel) => root.querySelector(sel),
    querySelectorAll: (sel) => root.querySelectorAll(sel)
  };

  return { root, body, document, elementsById };
}

async function runPureStress() {
  const { root, document, elementsById } = createDOMTree();

  // Load scripts into global context
  globalThis.document = document;
  globalThis.window = globalThis;
  globalThis.requestAnimationFrame = (fn) => setTimeout(fn, 16);
  globalThis.cancelAnimationFrame = (id) => clearTimeout(id);
  globalThis.performance = {
    _offset: 0,
    now: () => Date.now() + globalThis.performance._offset
  };

  // Mock Audio element
  class TestAudio {
    constructor() {
      this.src = '';
      this.currentTime = 0;
      this.duration = 300.0;
      this.paused = true;
      this.playbackRate = 1.0;
      this.preservesPitch = true;
      this.volume = 1.0;
      this.muted = false;
      this.seeking = false;
    }
    play() { this.paused = false; return Promise.resolve(); }
    pause() { this.paused = true; }
    addEventListener() {}
    removeEventListener() {}
  }
  globalThis.Audio = TestAudio;

  // Import application modules
  const dataPath = path.join(ROOT_DIR, 'js', 'presentationData.js');
  const audioPath = path.join(ROOT_DIR, 'js', 'audioManager.js');
  const timePath = path.join(ROOT_DIR, 'js', 'timelineEngine.js');
  const subPath = path.join(ROOT_DIR, 'js', 'subtitleRenderer.js');
  const scenePath = path.join(ROOT_DIR, 'js', 'sceneSimulator.js');
  const ctrlPath = path.join(ROOT_DIR, 'js', 'interactiveController.js');

  new Function(fs.readFileSync(dataPath, 'utf8'))();
  new Function(fs.readFileSync(audioPath, 'utf8'))();
  new Function(fs.readFileSync(timePath, 'utf8'))();
  new Function(fs.readFileSync(subPath, 'utf8'))();
  new Function(fs.readFileSync(scenePath, 'utf8'))();
  new Function(fs.readFileSync(ctrlPath, 'utf8'))();

  const AudioManager = globalThis.AudioManager;
  const TimelineEngine = globalThis.TimelineEngine;
  const SubtitleRenderer = globalThis.SubtitleRenderer;
  const SceneSimulator = globalThis.SceneSimulator;
  const InteractiveController = globalThis.InteractiveController;

  const audio = new AudioManager();
  const timeline = new TimelineEngine({ duration: 300.0, audioManager: audio });
  const subtitles = new SubtitleRenderer({
    containerEl: document.getElementById('subtitle-overlay'),
    textEl: document.getElementById('subtitle-text'),
    stageTagEl: document.getElementById('subtitle-stage-tag'),
    timelineEngine: timeline
  });
  const simulator = new SceneSimulator({
    containerEl: document.getElementById('scene-canvas'),
    drawerEl: document.getElementById('pulseagent-drawer'),
    eventStreamEl: document.getElementById('agent-event-stream'),
    audioManager: audio
  });
  const interactive = new InteractiveController({
    timelineEngine: timeline,
    sceneSimulator: simulator,
    audioManager: audio,
    subtitleRenderer: subtitles
  });

  // Wire events
  timeline.onTick((tick) => {
    subtitles.update(tick.currentTime);
    simulator.update(tick.currentTime, tick.stage);
  });

  timeline.onStateChange(({ state }) => {
    if (state === 'PAUSED' || state === 'COMPLETED') {
      interactive.onPause();
    } else if (state === 'PLAYING') {
      interactive.onResume();
    }
  });

  // ==========================================================================
  // [Suite 1] Stage 5 Adaptation & ODAEA Cards
  // ==========================================================================
  console.log('[Suite 1] Stage 5 Adaptation & ODAEA Cards Verification...');
  timeline.seek(160.0);
  check('Stage 5 boundary activated at 160.0s', timeline.currentStageIndex === 4);
  check('Drawer opened at t=160.0s', simulator.isDrawerOpen === true);

  timeline.seek(165.0);
  const cardDec2 = document.getElementById('card-ev_dec_2');
  check('Decision Step 2 card renders at 165s', cardDec2 !== null);

  timeline.seek(175.0);
  const heroCard = document.getElementById('card-ev_fail_1');
  check('Hero HTTP 503 Failure Adaptation card renders at 175s', heroCard !== null);
  check('Hero card has card-adaptation-hero class', heroCard?.classList.contains('card-adaptation-hero'));
  check('Hero card has pulse-orange-border class', heroCard?.classList.contains('pulse-orange-border'));
  check('Hero card contains HTTP 503 trigger', heroCard?.innerHTML.includes('HTTP 503'));
  check('Hero card contains SELF-CORRECTED badge', heroCard?.innerHTML.includes('SELF-CORRECTED'));

  timeline.seek(205.0);
  const rerouteCard = document.getElementById('card-ev_act_2');
  check('Emergency Queue Reroute card renders at 205s', rerouteCard !== null);
  check('Reroute card displays DELIVERED badge and channel',
    rerouteCard?.innerHTML.includes('DELIVERED') && rerouteCard?.innerHTML.includes('emergency_in_app_queue'));

  // ==========================================================================
  // [Suite 2] Live-Pause Sandbox Activation
  // ==========================================================================
  console.log('\n[Suite 2] Live-Pause Sandbox Mode Activation...');
  timeline.seek(175.0);
  timeline.play();
  timeline.pause();
  check('Timeline is paused', timeline.isPlaying === false);
  check('InteractiveController marked sandbox active', interactive.isSandboxActive === true);
  check('SceneSimulator marked isPausedByUser true', simulator.isPausedByUser === true);
  const badge = document.getElementById('sandbox-mode-indicator');
  check('Sandbox indicator has visible class', badge?.classList.contains('visible'));

  // ==========================================================================
  // [Suite 3] Drawer Tab Switching (react, audit, tools)
  // ==========================================================================
  console.log('\n[Suite 3] Drawer Tab Switching & Content Isolation...');
  check('Initial active tab is react', simulator.activeTab === 'react');

  simulator.switchTab('audit', true);
  check('Active tab is audit', simulator.activeTab === 'audit');
  check('Audit tab pane is active-pane', document.getElementById('tab-pane-audit')?.classList.contains('active-pane'));
  check('ReAct tab pane is deactivated', !document.getElementById('tab-pane-react')?.classList.contains('active-pane'));

  simulator.switchTab('tools', true);
  check('Active tab is tools', simulator.activeTab === 'tools');
  check('Tools tab pane is active-pane', document.getElementById('tab-pane-tools')?.classList.contains('active-pane'));

  simulator.switchTab('react', true);
  check('Active tab restored to react', simulator.activeTab === 'react');
  check('ReAct tab pane restored to active-pane', document.getElementById('tab-pane-react')?.classList.contains('active-pane'));

  // ==========================================================================
  // [Suite 4] Postgres Audit Trail Credential Redaction Check
  // ==========================================================================
  console.log('\n[Suite 4] Postgres Audit Trail Credential Redaction...');
  const auditHtml = document.getElementById('audit-table-body')?.innerHTML || '';
  check('Audit table has entries', auditHtml.length > 50);

  const secretPatterns = [
    /AIza[0-9A-Za-z-_]{35}/,
    /sk-[a-zA-Z0-9]{20,}/,
    /Bearer\s+[a-zA-Z0-9_\-\.]{20,}/,
    /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i
  ];

  let leaked = false;
  secretPatterns.forEach(pat => {
    if (pat.test(auditHtml)) leaked = true;
  });
  check('Audit table contains zero unredacted credential patterns', !leaked);
  check('Audit table contains [INJECTED] placeholder', auditHtml.includes('[INJECTED]'));
  check('Audit table contains [MASKED] placeholder', auditHtml.includes('[MASKED]'));
  check('Audit table contains [REDACTED] placeholder', auditHtml.includes('[REDACTED]'));

  // ==========================================================================
  // [Suite 5] HITL Modal Dialog
  // ==========================================================================
  console.log('\n[Suite 5] Human-In-The-Loop Governance Modal...');
  timeline.seek(245.0);
  const hitlModal = document.getElementById('hitl-confirmation-modal');
  check('HITL modal is displayed at t=245.0s', hitlModal?.classList.contains('modal-visible'));

  const approveBtn = document.getElementById('hitl-approve-btn');
  approveBtn.click();
  check('Clicking Approve removes modal-visible class', !hitlModal?.classList.contains('modal-visible'));

  const toast = document.getElementById('player-toast');
  check('Confirmation toast shown', toast?.classList.contains('toast-show') && toast?.textContent.includes('APPROVED'));

  // ==========================================================================
  // [Suite 6] Playback Resumption Timeline Continuity
  // ==========================================================================
  console.log('\n[Suite 6] Playback Resumption Timeline Continuity...');
  timeline.seek(180.0);
  timeline.pause();
  const pauseT = timeline.currentTime;

  // Do sandbox tab changes
  simulator.switchTab('audit', true);
  simulator.switchTab('tools', true);
  simulator.switchTab('react', true);

  check('Time did not drift while paused', timeline.currentTime === pauseT, `${timeline.currentTime}s`);

  // Resume
  timeline.play();
  check('Playback resumed (isPlaying === true)', timeline.isPlaying === true);
  check('Sandbox indicator hidden on resumption', !document.getElementById('sandbox-mode-indicator')?.classList.contains('visible'));

  console.log('\n================================================================');
  console.log(` PURE STRESS TEST SUITE: ${passedTests} / ${totalTests} CHECKS PASSED`);
  console.log(` Status: ${failedTests === 0 ? '✅ 100% PASSED' : '❌ FAILURES DETECTED'}`);
  console.log('================================================================\n');

  if (failedTests > 0) process.exit(1);
  else process.exit(0);
}

runPureStress().catch(err => {
  console.error('Fatal pure stress error:', err);
  process.exit(1);
});
