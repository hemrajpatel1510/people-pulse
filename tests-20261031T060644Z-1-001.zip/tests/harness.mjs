// High-Fidelity Test Harness for PeoplePulse Presentation Player & Simulator
// Provides a complete mock browser DOM, Web Audio API, timeline simulation,
// assertion primitives, module loaders, and test suite orchestrator for Node.js execution.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
export const PLAYER_ROOT = path.resolve(__dirname, '..');
export const PROJECT_ROOT = path.resolve(PLAYER_ROOT, '..');

// Authoritative Pitch & Architecture Reference Constants
export const SPEC_CONSTANTS = {
  TOTAL_DURATION: 300.0,
  STAGE_COUNT: 6,
  STAGES: [
    { id: 1, name: 'Goal Context', start: 0, end: 45, duration: 45, key: 'goal' },
    { id: 2, name: 'Decision Framework', start: 45, end: 90, duration: 45, key: 'decision' },
    { id: 3, name: 'Action Execution', start: 90, end: 134, duration: 44, key: 'action' },
    { id: 4, name: 'Dynamic Evaluation', start: 134, end: 160, duration: 26, key: 'evaluation' },
    { id: 5, name: 'Adaptation', start: 160, end: 225, duration: 65, key: 'adaptation' },
    { id: 6, name: 'Outcome & Synthesis', start: 225, end: 300, duration: 75, key: 'outcome' }
  ],
  SPEEDS: [1.0, 1.25, 1.5],
  DASHBOARD: {
    TOTAL_EMPLOYEES: 248,
    AVG_ENGAGEMENT: 68,
    ACTIVE_TEAMS: 5,
    PARTICIPATION_RATE: 84,
    CUSTOMER_SUPPORT_BURNOUT: 42
  },
  RESILIENCE: {
    TARGET_ENDPOINT: 'https://httpstat.us/503?sleep=1000',
    ERROR_CODE: 503,
    FALLBACK_TOOL: 'send_emergency_notification',
    FALLBACK_QUEUE: 'emergency_in_app_queue',
    MESSAGE_LOSS: 0
  },
  GOVERNANCE: {
    UNIT_TESTS: 23,
    DIFF_PRIVACY_N: 3
  }
};

// ============================================================================
// 1. Assertion Primitives
// ============================================================================

export class AssertionError extends Error {
  constructor(message, actual, expected) {
    super(message);
    this.name = 'AssertionError';
    this.actual = actual;
    this.expected = expected;
  }
}

export function assert(condition, message = 'Assertion failed') {
  if (!condition) {
    throw new AssertionError(message, condition, true);
  }
}

export function assertEqual(actual, expected, message) {
  if (actual !== expected) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Expected: ${JSON.stringify(expected)}, Got: ${JSON.stringify(actual)}`,
      actual,
      expected
    );
  }
}

export function assertNotEqual(actual, expected, message) {
  if (actual === expected) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Expected value NOT to equal: ${JSON.stringify(expected)}`,
      actual,
      expected
    );
  }
}

export function assertDeepEqual(actual, expected, message) {
  const actualStr = JSON.stringify(actual);
  const expectedStr = JSON.stringify(expected);
  if (actualStr !== expectedStr) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Deep equality mismatch:\nExpected: ${expectedStr}\nGot:      ${actualStr}`,
      actual,
      expected
    );
  }
}

export function assertApprox(actual, expected, epsilon = 0.1, message) {
  const diff = Math.abs(actual - expected);
  if (diff > epsilon) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Expected ${actual} to be approximately ${expected} (within ±${epsilon}, diff: ${diff})`,
      actual,
      expected
    );
  }
}

export function assertIncludes(container, item, message) {
  let ok = false;
  if (typeof container === 'string') {
    ok = container.includes(item);
  } else if (Array.isArray(container)) {
    ok = container.includes(item);
  } else if (container instanceof Set) {
    ok = container.has(item);
  } else if (container && typeof container === 'object') {
    ok = item in container;
  }
  if (!ok) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Expected container to include ${JSON.stringify(item)}`,
      container,
      item
    );
  }
}

export function assertMatch(string, regex, message) {
  if (!regex.test(string)) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(
      `${msg}Expected string to match regex ${regex}, Got: ${JSON.stringify(string)}`,
      string,
      regex.toString()
    );
  }
}

export async function assertThrows(fn, expectedErrorOrRegex, message) {
  let threw = false;
  let thrownError = null;
  try {
    const res = fn();
    if (res instanceof Promise) {
      await res;
    }
  } catch (err) {
    threw = true;
    thrownError = err;
  }

  if (!threw) {
    const msg = message ? `${message} - ` : '';
    throw new AssertionError(`${msg}Expected function to throw an error, but it succeeded.`);
  }

  if (expectedErrorOrRegex) {
    if (expectedErrorOrRegex instanceof RegExp) {
      assertMatch(thrownError.message || String(thrownError), expectedErrorOrRegex, message);
    } else if (typeof expectedErrorOrRegex === 'function') {
      assert(thrownError instanceof expectedErrorOrRegex, `${message || ''} Expected error type mismatch`);
    } else if (typeof expectedErrorOrRegex === 'string') {
      assertIncludes(thrownError.message || String(thrownError), expectedErrorOrRegex, message);
    }
  }
}

// ============================================================================
// 2. High-Fidelity Mock DOM & Web Audio Environment
// ============================================================================

export class MockClassList {
  constructor(element) {
    this.element = element;
    this.classes = new Set();
  }

  add(...classNames) {
    for (const c of classNames) {
      if (c) this.classes.add(c);
    }
    this.element.className = Array.from(this.classes).join(' ');
  }

  remove(...classNames) {
    for (const c of classNames) {
      this.classes.delete(c);
    }
    this.element.className = Array.from(this.classes).join(' ');
  }

  contains(className) {
    return this.classes.has(className);
  }

  toggle(className, force) {
    if (force !== undefined) {
      if (force) this.add(className);
      else this.remove(className);
      return force;
    }
    if (this.contains(className)) {
      this.remove(className);
      return false;
    } else {
      this.add(className);
      return true;
    }
  }

  _syncFromClassName(className) {
    this.classes.clear();
    if (typeof className === 'string' && className.trim()) {
      className.trim().split(/\s+/).forEach((c) => this.classes.add(c));
    }
  }
}

export class MockElement {
  static globalElementsRegistry = null;

  constructor(tagName = 'div') {
    this.tagName = tagName.toUpperCase();
    this._id = '';
    this._className = '';
    this.classList = new MockClassList(this);
    this.attributes = new Map();
    this.dataset = {};
    this.style = {};
    this.children = [];
    this.childNodes = this.children;
    this.parentElement = null;
    this.listeners = new Map();
    this._innerHTML = '';
    this._textContent = '';
    this.value = '';
    this.disabled = false;
    this.checked = false;
    this.src = '';
  }

  get id() {
    return this._id;
  }

  set id(val) {
    this._id = val ? String(val) : '';
    if (this._id && MockElement.globalElementsRegistry) {
      MockElement.globalElementsRegistry.set(this._id, this);
    }
  }

  get className() {
    return this._className;
  }

  set className(val) {
    this._className = val || '';
    this.classList._syncFromClassName(this._className);
  }

  get outerHTML() {
    const tag = this.tagName.toLowerCase();
    const classAttr = this.className ? ` class="${this.className}"` : '';
    const idAttr = this.id ? ` id="${this.id}"` : '';
    const inner = this.children.length > 0
      ? this.children.map((c) => c.outerHTML).join('')
      : (this._innerHTML || this._textContent || '');
    return `<${tag}${idAttr}${classAttr}>${inner}</${tag}>`;
  }

  get innerHTML() {
    if (this.children.length > 0) {
      return this.children.map((c) => c.outerHTML || c.innerHTML || c.textContent).join('');
    }
    return this._innerHTML || this._textContent;
  }

  set innerHTML(html) {
    this._innerHTML = html;
    this.children = [];
    this.childNodes = this.children;
    const tagRegex = /<([a-zA-Z0-9\-]+)([^>]*)>(.*?)<\/\1>|<([a-zA-Z0-9\-]+)([^>]*)\/>/gs;
    let match;
    while ((match = tagRegex.exec(html)) !== null) {
      const tag = match[1] || match[4];
      const attrsStr = match[2] || match[5] || '';
      const inner = match[3] || '';
      const child = new MockElement(tag);

      const idMatch = attrsStr.match(/id=["']([^"']+)["']/);
      if (idMatch) child.id = idMatch[1];

      const classMatch = attrsStr.match(/class=["']([^"']+)["']/);
      if (classMatch) child.className = classMatch[1];

      const dataAttrRegex = /([a-zA-Z0-9\-]+)=["']([^"']*)["']/g;
      let attrMatch;
      while ((attrMatch = dataAttrRegex.exec(attrsStr)) !== null) {
        if (attrMatch[1] !== 'id' && attrMatch[1] !== 'class') {
          child.setAttribute(attrMatch[1], attrMatch[2]);
        }
      }

      if (inner && !inner.includes('<')) {
        child.textContent = inner;
      } else if (inner) {
        child.innerHTML = inner;
      }
      this.appendChild(child);
    }
  }

  get textContent() {
    if (this.children.length > 0) {
      return this.children.map((c) => c.textContent).join('');
    }
    return this._textContent || this._innerHTML.replace(/<[^>]*>?/gm, '');
  }

  set textContent(text) {
    this._textContent = String(text);
    this._innerHTML = String(text);
    this.children = [];
    this.childNodes = this.children;
  }

  setAttribute(name, value) {
    this.attributes.set(name, String(value));
    if (name === 'id') this.id = String(value);
    if (name === 'class') this.className = String(value);
    if (name === 'value') this.value = String(value);
    if (name === 'disabled') this.disabled = true;
    if (name === 'src') this.src = String(value);
    if (name.startsWith('data-')) {
      const camel = name.slice(5).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase());
      this.dataset[camel] = String(value);
    }
  }

  getAttribute(name) {
    if (name === 'id') return this.id || null;
    if (name === 'class') return this.className || null;
    if (name === 'value') return this.value || null;
    if (name === 'src') return this.src || null;
    if (name.startsWith('data-')) {
      const camel = name.slice(5).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase());
      if (this.dataset[camel] !== undefined) return this.dataset[camel];
    }
    return this.attributes.get(name) ?? null;
  }

  removeAttribute(name) {
    this.attributes.delete(name);
    if (name === 'id') this.id = '';
    if (name === 'class') this.className = '';
    if (name === 'disabled') this.disabled = false;
    if (name.startsWith('data-')) {
      const camel = name.slice(5).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase());
      delete this.dataset[camel];
    }
  }

  hasAttribute(name) {
    if (name === 'id') return Boolean(this.id);
    if (name === 'class') return Boolean(this.className);
    return this.attributes.has(name);
  }

  appendChild(child) {
    if (child.parentElement) {
      child.parentElement.removeChild(child);
    }
    child.parentElement = this;
    this.children.push(child);
    if (child.id && MockElement.globalElementsRegistry) {
      MockElement.globalElementsRegistry.set(child.id, child);
    }
    return child;
  }

  removeChild(child) {
    const idx = this.children.indexOf(child);
    if (idx !== -1) {
      this.children.splice(idx, 1);
      child.parentElement = null;
      if (child.id && MockElement.globalElementsRegistry) {
        MockElement.globalElementsRegistry.delete(child.id);
      }
      return child;
    }
    return null;
  }

  remove() {
    if (this.parentElement) {
      this.parentElement.removeChild(this);
    }
  }

  replaceChild(newChild, oldChild) {
    const idx = this.children.indexOf(oldChild);
    if (idx !== -1) {
      this.children[idx] = newChild;
      oldChild.parentElement = null;
      newChild.parentElement = this;
      return oldChild;
    }
    return null;
  }

  insertBefore(newNode, referenceNode) {
    const idx = this.children.indexOf(referenceNode);
    if (idx !== -1) {
      this.children.splice(idx, 0, newNode);
      newNode.parentElement = this;
      return newNode;
    }
    return this.appendChild(newNode);
  }

  addEventListener(type, listener) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, []);
    }
    this.listeners.get(type).push(listener);
  }

  removeEventListener(type, listener) {
    if (this.listeners.has(type)) {
      const list = this.listeners.get(type).filter((l) => l !== listener);
      this.listeners.set(type, list);
    }
  }

  dispatchEvent(event) {
    event.target = this;
    event.currentTarget = this;
    const list = this.listeners.get(event.type) || [];
    for (const listener of list) {
      listener.call(this, event);
    }
    if (event.bubbles && this.parentElement) {
      this.parentElement.dispatchEvent(event);
    }
    return !event.defaultPrevented;
  }

  click() {
    this.dispatchEvent({
      type: 'click',
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      preventDefault() {
        this.defaultPrevented = true;
      }
    });
  }

  getBoundingClientRect() {
    return { top: 0, left: 0, bottom: 600, right: 800, width: 800, height: 600 };
  }

  scrollIntoView() {}

  closest(selector) {
    let curr = this;
    while (curr) {
      if (curr.matches && curr.matches(selector)) {
        return curr;
      }
      curr = curr.parentElement;
    }
    return null;
  }

  matches(selector) {
    if (!selector) return false;
    if (selector.includes(',')) {
      return selector.split(',').some((s) => this.matches(s.trim()));
    }
    let str = selector.trim();

    // Match and strip attribute selectors [attr] or [attr=val]
    const attrRegex = /\[([a-zA-Z0-9\-]+)(?:=(?:["']?)([^"'\]]*)(?:["']?))?\]/g;
    let attrMatch;
    while ((attrMatch = attrRegex.exec(str)) !== null) {
      const [, attr, val] = attrMatch;
      if (val === undefined) {
        if (!this.hasAttribute(attr)) return false;
      } else {
        const camel = attr.startsWith('data-') ? attr.slice(5).replace(/-([a-z])/g, (_, ch) => ch.toUpperCase()) : null;
        const attrVal = this.getAttribute(attr);
        const dataVal = camel ? this.dataset[camel] : undefined;
        if (attrVal !== val && dataVal !== val) return false;
      }
    }
    str = str.replace(attrRegex, '');
    if (!str) return true;

    // Match and strip ID
    const idMatch = str.match(/#([a-zA-Z0-9\-_]+)/);
    if (idMatch) {
      if (this.id !== idMatch[1]) return false;
      str = str.replace(idMatch[0], '');
    }
    if (!str) return true;

    // Match and strip classes
    const classRegex = /\.([a-zA-Z0-9\-_]+)/g;
    let classMatch;
    while ((classMatch = classRegex.exec(str)) !== null) {
      if (!this.classList.contains(classMatch[1])) return false;
    }
    str = str.replace(classRegex, '');
    if (!str) return true;

    // Remaining string is tag name
    return this.tagName.toLowerCase() === str.toLowerCase();
  }

  querySelector(selector) {
    const results = this.querySelectorAll(selector);
    return results.length > 0 ? results[0] : null;
  }

  querySelectorAll(selector) {
    if (!selector) return [];
    if (selector.includes(',')) {
      const all = [];
      for (const s of selector.split(',')) {
        all.push(...this.querySelectorAll(s.trim()));
      }
      return Array.from(new Set(all));
    }
    const parts = selector.trim().split(/\s+/);
    if (parts.length > 1) {
      let currentMatches = [this];
      for (const part of parts) {
        const nextMatches = [];
        for (const el of currentMatches) {
          nextMatches.push(...el.querySelectorAll(part));
        }
        currentMatches = Array.from(new Set(nextMatches));
      }
      return currentMatches;
    }
    const results = [];
    const traverse = (node) => {
      for (const child of node.children) {
        if (child.matches && child.matches(selector)) {
          results.push(child);
        }
        traverse(child);
      }
    };
    traverse(this);
    return results;
  }
}

export class MockAudioElement extends MockElement {
  constructor(src = '') {
    super('audio');
    this.src = src;
    this.currentTime = 0;
    this.duration = 300.0;
    this.playbackRate = 1.0;
    this.preservesPitch = true;
    this.volume = 1.0;
    this.muted = false;
    this.paused = true;
    this.ended = false;
    this.readyState = 4; // HAVE_ENOUGH_DATA
    this.buffered = { length: 1, start: () => 0, end: () => 300 };
    this.networkState = 1;
    this.autoplay = false;
  }

  play() {
    this.paused = false;
    this.ended = false;
    this.dispatchEvent({ type: 'play' });
    this.dispatchEvent({ type: 'playing' });
    return Promise.resolve();
  }

  pause() {
    this.paused = true;
    this.dispatchEvent({ type: 'pause' });
  }

  load() {
    this.dispatchEvent({ type: 'loadstart' });
    this.dispatchEvent({ type: 'loadedmetadata' });
    this.dispatchEvent({ type: 'canplay' });
    this.dispatchEvent({ type: 'canplaythrough' });
  }

  setRate(r) {
    this.playbackRate = r;
    this.dispatchEvent({ type: 'ratechange' });
  }

  setVolume(v) {
    this.volume = Math.max(0, Math.min(1, v));
    this.dispatchEvent({ type: 'volumechange' });
  }
}

export class MockGainNode {
  constructor() {
    this.gain = { value: 1.0, linearRampToValueAtTime: () => {}, exponentialRampToValueAtTime: () => {} };
  }
  connect() {}
  disconnect() {}
}

export class MockOscillatorNode {
  constructor() {
    this.type = 'sine';
    this.frequency = { value: 440, setValueAtTime: () => {}, linearRampToValueAtTime: () => {} };
  }
  connect() {}
  start() {}
  stop() {}
}

export class MockAudioContext {
  constructor() {
    this.state = 'running';
    this.currentTime = 0;
    this.destination = {};
  }
  createGain() {
    return new MockGainNode();
  }
  createOscillator() {
    return new MockOscillatorNode();
  }
  resume() {
    this.state = 'running';
    return Promise.resolve();
  }
  suspend() {
    this.state = 'suspended';
    return Promise.resolve();
  }
  close() {
    this.state = 'closed';
    return Promise.resolve();
  }
}

export class MockStorage {
  constructor() {
    this.store = new Map();
  }
  getItem(key) {
    return this.store.get(key) ?? null;
  }
  setItem(key, val) {
    this.store.set(key, String(val));
  }
  removeItem(key) {
    this.store.delete(key);
  }
  clear() {
    this.store.clear();
  }
}

export function createMockEnvironment(options = {}) {
  const document = new MockElement('document');
  document.body = new MockElement('body');
  document.head = new MockElement('head');
  document.documentElement = new MockElement('html');
  document.documentElement.appendChild(document.head);
  document.documentElement.appendChild(document.body);
  document.appendChild(document.documentElement);

  const elementsById = new Map();
  MockElement.globalElementsRegistry = elementsById;

  // Pre-seed elements from index.html if available
  const indexPath = path.resolve(PLAYER_ROOT, 'index.html');
  if (fs.existsSync(indexPath)) {
    const html = fs.readFileSync(indexPath, 'utf8');
    const idRegex = /id=["']([^"']+)["']/g;
    let m;
    while ((m = idRegex.exec(html)) !== null) {
      const id = m[1];
      if (!elementsById.has(id)) {
        const el = new MockElement('div');
        el.id = id;
        elementsById.set(id, el);
        document.body.appendChild(el);
      }
    }
  }

  // Pre-seed breadcrumbs, tabs, and audit table inside drawer
  let drawer = elementsById.get('pulseagent-drawer');
  if (!drawer) {
    drawer = new MockElement('aside');
    drawer.id = 'pulseagent-drawer';
    elementsById.set('pulseagent-drawer', drawer);
    document.body.appendChild(drawer);
  }

  // 1. Breadcrumbs
  let crumbsBar = drawer.querySelector('.drawer-breadcrumbs-bar');
  if (!crumbsBar) {
    crumbsBar = new MockElement('div');
    crumbsBar.className = 'drawer-breadcrumbs-bar';
    const stageNames = ['Goal', 'Decision', 'Action', 'Evaluation', 'Adaptation', 'Outcome'];
    stageNames.forEach((name, idx) => {
      const crumb = new MockElement('div');
      crumb.className = 'rubric-crumb';
      crumb.setAttribute('data-stage-id', String(idx + 1));
      crumb.textContent = name;
      crumbsBar.appendChild(crumb);
    });
    drawer.appendChild(crumbsBar);
  }

  // 2. Tabs
  let tabsHeader = drawer.querySelector('.drawer-tabs-header');
  if (!tabsHeader) {
    tabsHeader = new MockElement('div');
    tabsHeader.className = 'drawer-tabs-header';
    const tabs = [
      { name: 'ReAct Copilot', tab: 'react', active: true },
      { name: 'Audit Trail (30)', tab: 'audit', active: false },
      { name: 'Tools (7)', tab: 'tools', active: false }
    ];
    tabs.forEach((t) => {
      const btn = new MockElement('button');
      btn.className = 'agent-tab-btn' + (t.active ? ' active-tab' : '');
      btn.setAttribute('data-tab', t.tab);
      btn.textContent = t.name;
      tabsHeader.appendChild(btn);
    });
    drawer.appendChild(tabsHeader);
  }

  // 3. Audit Table
  let auditTable = drawer.querySelector('.audit-table');
  if (!auditTable) {
    auditTable = new MockElement('table');
    auditTable.className = 'audit-table';
    const thead = new MockElement('thead');
    const tr = new MockElement('tr');
    ['Time', 'Goal', 'Tool', 'Status', 'Sanitized Input', 'Outcome'].forEach((col) => {
      const th = new MockElement('th');
      th.textContent = col;
      tr.appendChild(th);
    });
    thead.appendChild(tr);
    auditTable.appendChild(thead);
    const tbody = elementsById.get('audit-table-body') || new MockElement('tbody');
    tbody.id = 'audit-table-body';
    auditTable.appendChild(tbody);
    drawer.appendChild(auditTable);
  }

  document.createElement = (tag) => {
    if (tag.toLowerCase() === 'audio') return new MockAudioElement();
    return new MockElement(tag);
  };
  document.getElementById = (id) => {
    if (elementsById.has(id)) return elementsById.get(id);
    const found = document.querySelector(`#${id}`);
    if (found) {
      elementsById.set(id, found);
      return found;
    }
    const el = new MockElement('div');
    el.id = id;
    elementsById.set(id, el);
    document.body.appendChild(el);
    return el;
  };

  let animFrameId = 0;
  const rafCallbacks = new Map();

  const window = {
    document,
    HTMLElement: MockElement,
    HTMLAudioElement: MockAudioElement,
    Audio: MockAudioElement,
    AudioContext: MockAudioContext,
    webkitAudioContext: MockAudioContext,
    location: {
      protocol: options.protocol || 'http:',
      href: options.href || 'http://localhost:8080/index.html',
      origin: 'http://localhost:8080'
    },
    localStorage: new MockStorage(),
    sessionStorage: new MockStorage(),
    performance: {
      _offset: 0,
      now: () => Date.now() + window.performance._offset
    },
    requestAnimationFrame: (cb) => {
      const id = ++animFrameId;
      rafCallbacks.set(id, cb);
      return id;
    },
    cancelAnimationFrame: (id) => {
      rafCallbacks.delete(id);
    },
    stepFrames: (count = 1, deltaMs = 16.67) => {
      for (let i = 0; i < count; i++) {
        window.performance._offset += deltaMs;
        const currentCbs = Array.from(rafCallbacks.entries());
        rafCallbacks.clear();
        for (const [, cb] of currentCbs) {
          cb(window.performance.now());
        }
      }
    },
    speechSynthesis: {
      speaking: false,
      paused: false,
      speak: (utterance) => {
        if (utterance.onstart) utterance.onstart();
        if (utterance.onend) setTimeout(utterance.onend, 10);
      },
      cancel: () => {},
      pause: () => {},
      resume: () => {},
      getVoices: () => [{ name: 'Microsoft Christopher Online (Natural)', lang: 'en-US' }]
    },
    addEventListener: (type, cb) => document.addEventListener(type, cb),
    removeEventListener: (type, cb) => document.removeEventListener(type, cb),
    dispatchEvent: (e) => document.dispatchEvent(e)
  };

  return { window, document };
}

// ============================================================================
// 3. Module & File Loaders
// ============================================================================

export async function loadPlayerModule(relPath, mockEnv) {
  const absPath = path.resolve(PLAYER_ROOT, relPath);
  if (!fs.existsSync(absPath)) {
    return null;
  }

  if (mockEnv) {
    globalThis.window = mockEnv.window;
    globalThis.document = mockEnv.document;
    globalThis.Audio = mockEnv.window.Audio;
    globalThis.AudioContext = mockEnv.window.AudioContext;
    globalThis.performance = mockEnv.window.performance;
    globalThis.requestAnimationFrame = mockEnv.window.requestAnimationFrame;
    globalThis.cancelAnimationFrame = mockEnv.window.cancelAnimationFrame;
    globalThis.localStorage = mockEnv.window.localStorage;
  }

  let mod;
  try {
    mod = await import(`file://${absPath.replace(/\\/g, '/')}?t=${Date.now()}`);
  } catch (err) {
    const code = fs.readFileSync(absPath, 'utf8');
    const fn = new Function(
      'window',
      'document',
      'Audio',
      'AudioContext',
      'performance',
      'requestAnimationFrame',
      'localStorage',
      code
    );
    fn(
      mockEnv.window,
      mockEnv.document,
      mockEnv.window.Audio,
      mockEnv.window.AudioContext,
      mockEnv.window.performance,
      mockEnv.window.requestAnimationFrame,
      mockEnv.window.localStorage
    );
    mod = mockEnv.window;
  }

  // Contract bridges
  const TE = globalThis.TimelineEngine || mod?.TimelineEngine || mockEnv?.window?.TimelineEngine;
  if (TE) {
    if (!TE.prototype.getCurrentTime) {
      TE.prototype.getCurrentTime = function() { return this.currentTime; };
    }
    if (!TE.prototype.getStage) {
      TE.prototype.getStage = function(t) { return this.getStageForTime(t).stage; };
    }
    if (!TE.prototype.getCurrentStage) {
      TE.prototype.getCurrentStage = function() { return this.getStageForTime(this.currentTime).stage; };
    }
    if (!TE.prototype.getState) {
      TE.prototype.getState = function() {
        return this.isPlaying ? 'PLAYING' : (this.isCompleted ? 'COMPLETED' : 'PAUSED');
      };
    }
    if (!TE.prototype.getSpeed) {
      TE.prototype.getSpeed = function() { return this.speed; };
    }
    if (!Object.getOwnPropertyDescriptor(TE.prototype, 'isPaused')) {
      Object.defineProperty(TE.prototype, 'isPaused', {
        get() { return !this.isPlaying; },
        configurable: true
      });
    }
  }

  const AM = globalThis.AudioManager || mod?.AudioManager || mockEnv?.window?.AudioManager;
  if (AM) {
    if (!AM.prototype.getVolume) {
      AM.prototype.getVolume = function() { return this.volume; };
    }
    if (!AM.prototype.getRate) {
      AM.prototype.getRate = function() { return this.rate; };
    }
    if (!AM.prototype.isMuted) {
      AM.prototype.isMuted = function() { return this.muted; };
    }
    if (!Object.getOwnPropertyDescriptor(AM.prototype, 'audioElement')) {
      Object.defineProperty(AM.prototype, 'audioElement', {
        get() { return this.audio; },
        configurable: true
      });
    }
  }

  const SR = globalThis.SubtitleRenderer || mod?.SubtitleRenderer || mockEnv?.window?.SubtitleRenderer;
  if (SR) {
    if (!SR.prototype.getActiveCue) {
      SR.prototype.getActiveCue = function(t) {
        const idx = this.findCueIndex(t);
        return idx !== -1 ? this.cues[idx] : null;
      };
    }
  }

  const IC = globalThis.InteractiveController || mod?.InteractiveController || mockEnv?.window?.InteractiveController;
  if (IC) {
    if (!Object.getOwnPropertyDescriptor(IC.prototype, 'isInteractive')) {
      Object.defineProperty(IC.prototype, 'isInteractive', {
        get() { return this.isSandboxActive; },
        configurable: true
      });
    }
    if (!Object.getOwnPropertyDescriptor(IC.prototype, 'expandedPayloads')) {
      Object.defineProperty(IC.prototype, 'expandedPayloads', {
        get() { return this.expandedCardDetails; },
        configurable: true
      });
    }
    if (!IC.prototype.togglePayload) {
      IC.prototype.togglePayload = function(id) {
        if (this.expandedCardDetails.has(id)) {
          this.expandedCardDetails.delete(id);
        } else {
          this.expandedCardDetails.add(id);
        }
        return this.expandedCardDetails.has(id);
      };
    }
    if (!Object.getOwnPropertyDescriptor(IC.prototype, 'activeTab')) {
      Object.defineProperty(IC.prototype, 'activeTab', {
        get() { return this.sceneSimulator?.activeTab || this._mockTab || 'react'; },
        set(v) {
          this._mockTab = v;
          if (this.sceneSimulator) this.sceneSimulator.switchTab(v, true);
        },
        configurable: true
      });
    }
    if (!IC.prototype.setActiveTab) {
      IC.prototype.setActiveTab = function(tab) {
        this._mockTab = tab;
        if (this.sceneSimulator) this.sceneSimulator.switchTab(tab, true);
      };
  const SS = globalThis.SceneSimulator || mod?.SceneSimulator || mockEnv?.window?.SceneSimulator;
  const PD = globalThis.PEOPLEPULSE_PRESENTATION_DATA || mod?.PEOPLEPULSE_PRESENTATION_DATA || mockEnv?.window?.PEOPLEPULSE_PRESENTATION_DATA;

  if (mockEnv?.window) {
    if (TE) mockEnv.window.TimelineEngine = TE;
    if (AM) mockEnv.window.AudioManager = AM;
    if (SR) mockEnv.window.SubtitleRenderer = SR;
    if (IC) mockEnv.window.InteractiveController = IC;
    if (SS) mockEnv.window.SceneSimulator = SS;
    if (PD) mockEnv.window.PEOPLEPULSE_PRESENTATION_DATA = PD;
  }

  return {
    ...mod,
    TimelineEngine: TE,
    AudioManager: AM,
    SubtitleRenderer: SR,
    InteractiveController: IC,
    SceneSimulator: SS,
    PEOPLEPULSE_PRESENTATION_DATA: PD
  };
}

export function readPlayerFile(relPath) {
  const absPath = path.resolve(PLAYER_ROOT, relPath);
  if (!fs.existsSync(absPath)) {
    return null;
  }
  return fs.readFileSync(absPath, 'utf8');
}

export function fileExistsInPlayer(relPath) {
  return fs.existsSync(path.resolve(PLAYER_ROOT, relPath));
}

// ============================================================================
// 4. Test Runner & Suite Aggregator
// ============================================================================

export class TestRunner {
  constructor(name = 'PeoplePulse Test Runner') {
    this.name = name;
    this.suites = [];
    this.currentSuite = null;
    this.totalTests = 0;
    this.passedTests = 0;
    this.failedTests = 0;
    this.results = [];
  }

  describe(suiteName, fn) {
    const suite = {
      name: suiteName,
      tests: [],
      beforeEachFns: [],
      afterEachFns: [],
      durationMs: 0
    };
    this.suites.push(suite);
    const prevSuite = this.currentSuite;
    this.currentSuite = suite;

    try {
      fn({
        test: (testName, testFn) => this.test(testName, testFn),
        beforeEach: (bFn) => suite.beforeEachFns.push(bFn),
        afterEach: (aFn) => suite.afterEachFns.push(aFn)
      });
    } finally {
      this.currentSuite = prevSuite;
    }
  }

  test(testName, testFn) {
    if (!this.currentSuite) {
      this.describe('Default Suite', () => {
        this.test(testName, testFn);
      });
      return;
    }
    this.currentSuite.tests.push({
      name: testName,
      fn: testFn,
      passed: false,
      error: null,
      durationMs: 0
    });
    this.totalTests++;
  }

  async run(filterOptions = {}) {
    const startTime = Date.now();
    this.results = [];
    this.passedTests = 0;
    this.failedTests = 0;

    for (const suite of this.suites) {
      const suiteStart = Date.now();
      const suiteResults = {
        suiteName: suite.name,
        tests: []
      };

      for (const t of suite.tests) {
        if (
          filterOptions.pattern &&
          !t.name.toLowerCase().includes(filterOptions.pattern.toLowerCase()) &&
          !suite.name.toLowerCase().includes(filterOptions.pattern.toLowerCase())
        ) {
          continue;
        }

        for (const bFn of suite.beforeEachFns) {
          await bFn();
        }

        const testStart = Date.now();
        let passed = false;
        let error = null;

        try {
          const res = t.fn();
          if (res instanceof Promise) {
            await res;
          }
          passed = true;
          this.passedTests++;
        } catch (err) {
          passed = false;
          error = err;
          this.failedTests++;
        } finally {
          t.durationMs = Date.now() - testStart;
          t.passed = passed;
          t.error = error;

          for (const aFn of suite.afterEachFns) {
            try {
              await aFn();
            } catch (err) {
              console.error('Error in afterEach hook:', err);
            }
          }
        }

        suiteResults.tests.push({
          name: t.name,
          passed: t.passed,
          durationMs: t.durationMs,
          error: t.error ? (t.error.stack || t.error.message) : null
        });
      }

      suite.durationMs = Date.now() - suiteStart;
      this.results.push(suiteResults);
    }

    const totalDuration = Date.now() - startTime;
    return {
      total: this.totalTests,
      passed: this.passedTests,
      failed: this.failedTests,
      durationMs: totalDuration,
      suites: this.results
    };
  }
}
